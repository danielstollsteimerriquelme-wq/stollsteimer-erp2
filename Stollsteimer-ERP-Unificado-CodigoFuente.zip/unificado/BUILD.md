# Stollsteimer-ERP (unificado) — Código fuente

Un solo programa con dos módulos, seleccionables en la barra superior
(también con Alt+1 / Alt+2):

- **🖥 Dispositivos e Infraestructura** — el ERP original (tabla, Gantt, campos, respaldo CSV/JSON, PDF).
- **🔐 Accesos · DIFF · TUI** — Gestión de Accesos, Registro DIFF y Registro TUI.

Ambos módulos tienen **✉ Copiar a correo** y **⚙ Columnas del correo**
(seleccionas filas → copiar → pegar con Ctrl+V en el correo).

## Compilar el EXE portable (Windows, Node.js 18+)
    npm install
    npm run dist

Resultado: `release/Stollsteimer-ERP-Portable.exe`

## Datos
Cada módulo conserva su carpeta de datos junto al .exe, así que los datos
existentes siguen funcionando sin migrar nada:
- `Stollsteimer-ERP-Data/`      (dispositivos, esquema, imágenes, Backups)
- `Stollsteimer-Accesos-Data/`  (datos.json, Backups)

Para usar tus datos actuales, copia esas carpetas junto al nuevo .exe.

## Estructura
- `src/main.js` — proceso principal (ventana única, ERP, respaldo, portapapeles)
- `src/accesos/main-accesos.js` — IPC y archivos del módulo Accesos
- `src/accesos/fileio.js` — lectura/escritura de Excel y CSV (Accesos)
- `src/preload.js` — expone `window.api` (ERP) y `window.accesosApi` (Accesos)
- `src/store.js`, `importer.js`, `exporter.js` — datos, importación y exportación del ERP
- `src/renderer/shell.*` — ventana principal con el selector de módulos
- `src/renderer/erp/` — interfaz del ERP
- `src/renderer/accesos/` — interfaz de Accesos
- `data/devices.seed.json` — datos iniciales del ERP
