const fs = require('fs');
const ExcelJS = require('exceljs');

const pad = (n) => String(n).padStart(2, '0');

// ---------- CSV ----------
function csvEscape(v, sep) {
  const s = v == null ? '' : String(v);
  return (s.includes(sep) || s.includes('"') || s.includes('\n') || s.includes('\r')) ? '"' + s.replace(/"/g, '""') + '"' : s;
}

// Punto y coma + BOM UTF-8: Excel en español lo abre directo con tildes correctas
function writeCsv(file, sheet) {
  const sep = ';';
  const lines = [sheet.headers.map(h => csvEscape(h, sep)).join(sep)];
  sheet.rows.forEach(r => lines.push(r.map(c => csvEscape(c, sep)).join(sep)));
  fs.writeFileSync(file, '﻿' + lines.join('\r\n') + '\r\n', 'utf-8');
}

function parseCsv(text) {
  if (text.charCodeAt(0) === 0xFEFF) text = text.slice(1);
  // autodetectar delimitador con la primera línea
  const first = text.split(/\r?\n/)[0] || '';
  const cand = [';', ',', '\t'];
  let sep = ';', best = -1;
  cand.forEach(c => { const n = first.split(c).length; if (n > best) { best = n; sep = c; } });
  const rows = [];
  let row = [], cur = '', q = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (q) {
      if (ch === '"') { if (text[i + 1] === '"') { cur += '"'; i++; } else q = false; }
      else cur += ch;
    } else if (ch === '"') q = true;
    else if (ch === sep) { row.push(cur); cur = ''; }
    else if (ch === '\n') { row.push(cur); rows.push(row); row = []; cur = ''; }
    else if (ch === '\r') { /* ignorar */ }
    else cur += ch;
  }
  if (cur !== '' || row.length) { row.push(cur); rows.push(row); }
  return rows.filter(r => r.some(c => String(c).trim() !== ''));
}

// ---------- XLSX ----------
function cellToText(v) {
  if (v == null) return '';
  if (v instanceof Date) {
    // Excel no maneja zona horaria: usar componentes UTC (hora "de pared")
    const d = `${pad(v.getUTCDate())}-${pad(v.getUTCMonth() + 1)}-${v.getUTCFullYear()}`;
    const hasTime = v.getUTCHours() || v.getUTCMinutes();
    return hasTime ? `${d} ${pad(v.getUTCHours())}:${pad(v.getUTCMinutes())}` : d;
  }
  if (typeof v === 'object') {
    if (v.richText) return v.richText.map(t => t.text).join('');
    if (v.result !== undefined) return cellToText(v.result);
    if (v.text !== undefined) return String(v.text);
    if (v.hyperlink) return String(v.text || v.hyperlink);
    return String(v);
  }
  return String(v);
}

async function readTable(file) {
  const ext = file.toLowerCase().split('.').pop();
  if (ext === 'xlsx') {
    const wb = new ExcelJS.Workbook();
    await wb.xlsx.readFile(file);
    const ws = wb.worksheets[0];
    if (!ws) return [];
    const out = [];
    const maxCol = ws.actualColumnCount || ws.columnCount;
    ws.eachRow({ includeEmpty: false }, (row) => {
      const arr = [];
      for (let c = 1; c <= maxCol; c++) arr.push(cellToText(row.getCell(c).value));
      if (arr.some(x => x.trim() !== '')) out.push(arr);
    });
    return out;
  }
  return parseCsv(fs.readFileSync(file, 'utf-8'));
}

function argb(hex) {
  const h = String(hex || '').replace('#', '');
  return h.length === 6 ? 'FF' + h.toUpperCase() : null;
}

async function writeXlsx(file, sheets) {
  const wb = new ExcelJS.Workbook();
  wb.creator = 'Stollsteimer-Accesos';
  wb.created = new Date();
  sheets.forEach((s) => {
    const ws = wb.addWorksheet(String(s.name).replace(/[\\/?*[\]:]/g, '-').slice(0, 31));
    ws.addRow(s.headers);
    const hr = ws.getRow(1);
    hr.font = { bold: true, color: { argb: 'FFFFFFFF' } };
    hr.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF0A3D62' } };
    hr.alignment = { vertical: 'middle' };
    s.rows.forEach((r, ri) => {
      const row = ws.addRow(r.map(v => (typeof v === 'number' ? v : v == null ? '' : String(v))));
      const colors = s.colors && s.colors[ri];
      if (colors) colors.forEach((c, ci) => {
        if (!c) return;
        const cell = row.getCell(ci + 1);
        const bg = argb(c.bg), fg = argb(c.color);
        if (bg) cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: bg } };
        if (fg) cell.font = { bold: true, color: { argb: fg } };
      });
    });
    s.headers.forEach((h, i) => {
      let w = String(h).length;
      s.rows.forEach(r => { w = Math.max(w, String(r[i] == null ? '' : r[i]).length); });
      ws.getColumn(i + 1).width = Math.min(Math.max(w + 2, 10), 50);
    });
    ws.views = [{ state: 'frozen', ySplit: 1 }];
    if (s.headers.length) ws.autoFilter = { from: { row: 1, column: 1 }, to: { row: 1, column: s.headers.length } };
  });
  await wb.xlsx.writeFile(file);
}

module.exports = { writeCsv, writeXlsx, readTable, parseCsv };
