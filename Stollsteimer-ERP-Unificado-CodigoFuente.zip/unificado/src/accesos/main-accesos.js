// Módulo "Accesos" (Gestión de Accesos, Registro DIFF y Registro TUI)
// dentro del programa unificado. Conserva su propia carpeta de datos
// (Stollsteimer-Accesos-Data) para no tocar los datos ya existentes.
const { ipcMain, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const io = require('./fileio');

let DATA_DIR, DB_FILE, BACKUP_DIR;
let getWindow = () => null;

function init(baseDir) {
  DATA_DIR = path.join(baseDir, 'Stollsteimer-Accesos-Data');
  BACKUP_DIR = path.join(DATA_DIR, 'Backups');
  fs.mkdirSync(BACKUP_DIR, { recursive: true });
  DB_FILE = path.join(DATA_DIR, 'datos.json');
}

function readDb() {
  for (const f of [DB_FILE, DB_FILE + '.bak']) {
    try {
      if (fs.existsSync(f)) return JSON.parse(fs.readFileSync(f, 'utf-8'));
    } catch (err) { console.error('Error leyendo', f, err); }
  }
  return null;
}

function writeDb(db) {
  // Escritura atómica + copia .bak del estado anterior
  const tmp = DB_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db), 'utf-8');
  if (fs.existsSync(DB_FILE)) {
    try { fs.copyFileSync(DB_FILE, DB_FILE + '.bak'); } catch (e) { /* no-op */ }
  }
  fs.renameSync(tmp, DB_FILE);
}

function registerIpc(windowGetter) {
  getWindow = windowGetter;

  // ---------- base de datos ----------
  ipcMain.handle('acc:db:load', () => ({ db: readDb(), dataDir: DATA_DIR, backupDir: BACKUP_DIR }));
  ipcMain.handle('acc:db:save', (e, db) => {
    try { writeDb(db); return { ok: true }; } catch (err) { return { ok: false, error: err.message }; }
  });

  // ---------- exportar ----------
  // payload: { format:'xlsx'|'csv', defaultName, sheets:[{name, headers, rows:[[...]], colors?}] }
  ipcMain.handle('acc:export:save', async (e, payload) => {
    const isX = payload.format === 'xlsx';
    const r = await dialog.showSaveDialog(getWindow(), {
      title: isX ? 'Exportar a Excel' : 'Exportar a CSV',
      defaultPath: payload.defaultName,
      filters: isX ? [{ name: 'Excel', extensions: ['xlsx'] }] : [{ name: 'CSV', extensions: ['csv'] }]
    });
    if (r.canceled) return { ok: false };
    try {
      if (isX) await io.writeXlsx(r.filePath, payload.sheets);
      else io.writeCsv(r.filePath, payload.sheets[0]);
      return { ok: true, path: r.filePath };
    } catch (err) { return { ok: false, error: err.message }; }
  });

  // ---------- importar (devuelve matriz de texto) ----------
  ipcMain.handle('acc:import:pick', async () => {
    const r = await dialog.showOpenDialog(getWindow(), {
      title: 'Importar CSV o Excel',
      properties: ['openFile'],
      filters: [{ name: 'Excel o CSV', extensions: ['xlsx', 'csv', 'txt'] }]
    });
    if (r.canceled) return null;
    try {
      const matrix = await io.readTable(r.filePaths[0]);
      return { ok: true, file: path.basename(r.filePaths[0]), matrix };
    } catch (err) { return { ok: false, error: err.message }; }
  });

  // ---------- respaldo ----------
  ipcMain.handle('acc:backup:write', async (e, stamp, dbJson, sheets) => {
    try {
      const base = path.join(BACKUP_DIR, `Respaldo-${stamp}`);
      fs.writeFileSync(base + '.json', dbJson, 'utf-8');
      await io.writeXlsx(base + '.xlsx', sheets);
      // conservar solo los últimos 60 respaldos (30 pares)
      const files = fs.readdirSync(BACKUP_DIR).filter(f => f.startsWith('Respaldo-')).sort();
      const extra = files.length - 60;
      for (let i = 0; i < extra; i++) { try { fs.unlinkSync(path.join(BACKUP_DIR, files[i])); } catch (x) { /* no-op */ } }
      return { ok: true, path: base + '.json' };
    } catch (err) { return { ok: false, error: err.message }; }
  });
  ipcMain.handle('acc:backup:pickRestore', async () => {
    const r = await dialog.showOpenDialog(getWindow(), {
      title: 'Restaurar desde respaldo', properties: ['openFile'], defaultPath: BACKUP_DIR,
      filters: [{ name: 'Respaldo (.json)', extensions: ['json'] }]
    });
    if (r.canceled) return null;
    try { return { ok: true, file: path.basename(r.filePaths[0]), db: JSON.parse(fs.readFileSync(r.filePaths[0], 'utf-8')) }; }
    catch (err) { return { ok: false, error: err.message }; }
  });
  ipcMain.handle('acc:shell:openFolder', (e, which) => shell.openPath(which === 'backup' ? BACKUP_DIR : DATA_DIR));
  ipcMain.handle('acc:shell:showItem', (e, p) => shell.showItemInFolder(p));
}

module.exports = { init, registerIpc };
