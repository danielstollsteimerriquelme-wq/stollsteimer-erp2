const fs = require('fs');
const path = require('path');
const PDFDocument = require('pdfkit');

// ---------- utilidades de fecha (siempre 24 horas, sin depender del locale del SO) ----------
function pad(n) { return String(n).padStart(2, '0'); }

function fmtDateTime(isoString) {
  const d = new Date(isoString);
  if (isNaN(d.getTime())) return '';
  return `${pad(d.getDate())}-${pad(d.getMonth() + 1)}-${d.getFullYear()}, ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}

function fmtDateOnly(dateStr) {
  // dateStr viene como 'YYYY-MM-DD' (input type=date); se interpreta en hora local
  const d = new Date(dateStr + 'T00:00:00');
  if (isNaN(d.getTime())) return '';
  return `${pad(d.getDate())}-${pad(d.getMonth() + 1)}-${d.getFullYear()}`;
}

function csvEscape(val) {
  if (val === null || val === undefined) return '';
  const s = String(val).replace(/"/g, '""');
  if (/[",\n;]/.test(s)) return `"${s}"`;
  return s;
}

// Formatea un valor segun el tipo de campo definido en el schema
function formatFieldValue(field, rawVal) {
  if (rawVal === null || rawVal === undefined || rawVal === '') return '';
  if (!field) return rawVal;
  if (field.type === 'datetime') return fmtDateTime(rawVal) || rawVal;
  if (field.type === 'date') return fmtDateOnly(rawVal) || rawVal;
  return rawVal;
}

function exportCSV(devices, schema, filePath) {
  const cols = schema.map(f => f.key);
  const headerLabels = schema.map(f => f.label);
  const lines = [headerLabels.map(csvEscape).join(';')];
  devices.forEach(d => {
    const row = cols.map((c, i) => csvEscape(formatFieldValue(schema[i], d[c])));
    lines.push(row.join(';'));
  });
  fs.writeFileSync(filePath, '\uFEFF' + lines.join('\r\n'), 'utf-8');
}

// ---------- PDF ----------
const MARGIN = 40;

// Encabezado que ajusta su alto segun el largo del titulo, para que el texto
// nunca quede cortado ni superpuesto con la linea del recuadro.
function drawHeader(doc, title) {
  doc.font('Helvetica-Bold').fontSize(16);
  const usableWidth = doc.page.width - MARGIN * 2;
  const textHeight = doc.heightOfString(title, { width: usableWidth });
  const boxHeight = Math.max(50, textHeight + 30);

  doc.fillColor('#0a3d62').rect(0, 0, doc.page.width, boxHeight).fill();
  doc.fillColor('#ffffff').font('Helvetica-Bold').fontSize(16)
    .text(title, MARGIN, 15, { width: usableWidth });
  doc.fillColor('#000000').font('Helvetica').fontSize(9);
  doc.y = boxHeight + 15;
}

async function exportPDF(devices, schema, filePath, opts = {}) {
  const { imagesDir, detailed } = opts;
  const doc = new PDFDocument({ size: 'LETTER', margin: MARGIN, bufferPages: true });
  const stream = fs.createWriteStream(filePath);
  doc.pipe(stream);

  if (!detailed) {
    // ---------- LISTADO GENERAL / SELECCION ----------
    drawHeader(doc, `Stollsteimer-ERP — Reporte de Dispositivos (${devices.length})`);
    const cols = schema;
    const usableWidth = doc.page.width - MARGIN * 2;
    const colWidth = usableWidth / cols.length;
    let y = doc.y;

    const drawRow = (values, bold) => {
      let x = MARGIN;
      doc.font(bold ? 'Helvetica-Bold' : 'Helvetica').fontSize(8);
      values.forEach((v) => {
        doc.text(String(v || ''), x, y, { width: colWidth - 4, ellipsis: true });
        x += colWidth;
      });
    };

    const drawHeadRow = () => {
      drawRow(cols.map(c => c.label), true);
      y += 16;
      doc.moveTo(MARGIN, y - 3).lineTo(doc.page.width - MARGIN, y - 3).strokeColor('#cccccc').stroke();
    };

    drawHeadRow();

    devices.forEach((d) => {
      if (y > doc.page.height - 60) {
        doc.addPage();
        drawHeader(doc, 'Stollsteimer-ERP — Reporte de Dispositivos (cont.)');
        y = doc.y;
        drawHeadRow();
      }
      drawRow(cols.map(c => formatFieldValue(c, d[c.key])), false);
      y += 14;
    });
  } else {
    // ---------- FICHA INDIVIDUAL DETALLADA POR DISPOSITIVO ----------
    const usableWidth = doc.page.width - MARGIN * 2;

    devices.forEach((d, idx) => {
      if (idx > 0) doc.addPage();
      drawHeader(doc, `Ficha de Dispositivo — ${d.codigo || d.id}`);
      let y = doc.y;

      // ----- Datos Generales: etiqueta y valor en la misma linea, ancho completo -----
      doc.fontSize(12).font('Helvetica-Bold').fillColor('#0a3d62').text('Datos Generales', MARGIN, y);
      doc.fillColor('#000000');
      y = doc.y + 8;

      schema.forEach(f => {
        const label = `${f.label}: `;
        const value = String(formatFieldValue(f, d[f.key]) || '-');
        doc.font('Helvetica-Bold').fontSize(9);
        const labelWidth = doc.widthOfString(label);
        doc.font('Helvetica').fontSize(9);
        const valueWidth = usableWidth - labelWidth;
        const lineHeight = Math.max(
          doc.heightOfString(label, { width: usableWidth }),
          doc.heightOfString(value, { width: valueWidth > 30 ? valueWidth : usableWidth })
        );

        if (y + lineHeight > doc.page.height - MARGIN) { doc.addPage(); y = MARGIN; }

        doc.font('Helvetica-Bold').fontSize(9).text(label, MARGIN, y, { continued: false, width: labelWidth + 2, lineBreak: false });
        if (valueWidth > 30) {
          doc.font('Helvetica').fontSize(9).text(value, MARGIN + labelWidth, y, { width: valueWidth });
        } else {
          // etiqueta muy larga: el valor pasa a la linea siguiente con el ancho completo
          doc.font('Helvetica').fontSize(9).text(value, MARGIN, y + lineHeight, { width: usableWidth });
        }
        y = doc.y + 4;
      });

      // ----- Imagenes (antes que el historial de mantenimiento) -----
      const imgs = d.imagenes || [];
      if (imgs.length > 0 && imagesDir) {
        y += 10;
        if (y > doc.page.height - 150) { doc.addPage(); y = MARGIN; }
        doc.fontSize(12).font('Helvetica-Bold').fillColor('#0a3d62').text('Imágenes', MARGIN, y);
        doc.fillColor('#000000');
        y = doc.y + 10;
        let x = MARGIN;
        const tileSize = 110;
        const gap = 12;
        imgs.forEach((img) => {
          const p = path.join(imagesDir, img.filename);
          if (fs.existsSync(p)) {
            try {
              if (x + tileSize > doc.page.width - MARGIN) { x = MARGIN; y += tileSize + gap; }
              if (y + tileSize > doc.page.height - MARGIN) { doc.addPage(); y = MARGIN; x = MARGIN; }
              doc.image(p, x, y, { fit: [tileSize, tileSize] });
              x += tileSize + gap;
            } catch (e) { /* imagen invalida, se omite */ }
          }
        });
        y += tileSize + 10;
      }

      // ----- Historial de Mantenimiento -----
      y += 8;
      if (y > doc.page.height - 100) { doc.addPage(); y = MARGIN; }
      doc.fontSize(12).font('Helvetica-Bold').fillColor('#0a3d62').text('Historial de Mantenimiento', MARGIN, y);
      doc.fillColor('#000000');
      y = doc.y + 10;
      doc.fontSize(9).font('Helvetica');
      const hist = d.mantenimientos || [];
      if (hist.length === 0) {
        doc.text('Sin registros de mantenimiento.', MARGIN, y);
        y = doc.y + 4;
      } else {
        hist.forEach(m => {
          if (y > doc.page.height - 100) { doc.addPage(); y = MARGIN; }
          const fecha = m.fecha ? fmtDateTime(m.fecha) : '-';
          doc.font('Helvetica-Bold').fontSize(9).text(`${fecha} — ${m.tipo || ''} (${m.estado || ''})`, MARGIN, y, { width: usableWidth });
          y = doc.y + 2;
          doc.font('Helvetica').fontSize(9).text(`Técnico: ${m.tecnico || '-'}    Costo: ${m.costo || '-'}`, MARGIN + 10, y, { width: usableWidth - 10 });
          y = doc.y + 2;
          if (m.descripcion) {
            doc.text(m.descripcion, MARGIN + 10, y, { width: usableWidth - 10 });
            y = doc.y + 2;
          }
          y += 6;
        });
      }
    });
  }

  doc.end();
  return new Promise((resolve, reject) => {
    stream.on('finish', resolve);
    stream.on('error', reject);
  });
}

module.exports = { exportCSV, exportPDF };
