// Parser CSV robusto (soporta comillas, campos con el delimitador o saltos
// de linea dentro, y escapado de comillas dobles "" )
function parseCSV(text, delimiter) {
  const rows = [];
  let field = '';
  let row = [];
  let inQuotes = false;
  const s = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
  let i = 0;
  while (i < s.length) {
    const c = s[i];
    if (inQuotes) {
      if (c === '"') {
        if (s[i + 1] === '"') { field += '"'; i += 2; continue; }
        inQuotes = false; i++; continue;
      }
      field += c; i++; continue;
    } else {
      if (c === '"') { inQuotes = true; i++; continue; }
      if (c === delimiter) { row.push(field); field = ''; i++; continue; }
      if (c === '\n') { row.push(field); rows.push(row); row = []; field = ''; i++; continue; }
      field += c; i++; continue;
    }
  }
  if (field.length > 0 || row.length > 0) { row.push(field); rows.push(row); }
  return rows.filter(r => !(r.length === 1 && r[0].trim() === ''));
}

function detectDelimiter(firstLine) {
  const semi = (firstLine.match(/;/g) || []).length;
  const comma = (firstLine.match(/,/g) || []).length;
  return semi >= comma ? ';' : ',';
}

function pad(n) { return String(n).padStart(2, '0'); }

// Convierte 'DD-MM-YYYY' (como lo genera nuestra exportacion) a 'YYYY-MM-DD'
function parseDateOnlyToISO(str) {
  if (!str) return '';
  const m = String(str).trim().match(/^(\d{2})-(\d{2})-(\d{4})$/);
  if (m) return `${m[3]}-${m[2]}-${m[1]}`;
  // tambien aceptar si ya viene en formato YYYY-MM-DD
  if (/^\d{4}-\d{2}-\d{2}$/.test(str.trim())) return str.trim();
  return '';
}

// Analiza el contenido de un CSV contra el schema actual y los dispositivos
// existentes, sin escribir nada todavia. Retorna dispositivos a crear, a
// actualizar (emparejados por "codigo"), y errores de filas.
function analyzeCSV(rawText, schema, existingDevices) {
  const text = rawText.replace(/^\uFEFF/, '');
  const firstLineEnd = text.indexOf('\n');
  const firstLine = firstLineEnd === -1 ? text : text.slice(0, firstLineEnd);
  const delimiter = detectDelimiter(firstLine);
  const rows = parseCSV(text, delimiter);

  if (rows.length === 0) {
    return { toCreate: [], toUpdate: [], errors: [{ row: 0, message: 'El archivo está vacío.' }] };
  }

  const headers = rows[0].map(h => h.trim());
  const colMap = headers.map(h => {
    const byLabel = schema.find(f => f.label.trim().toLowerCase() === h.toLowerCase());
    if (byLabel) return byLabel;
    const byKey = schema.find(f => f.key.toLowerCase() === h.toLowerCase());
    return byKey || null;
  });

  const unmatchedHeaders = headers.filter((h, i) => !colMap[i]);
  const codigoColIdx = colMap.findIndex(f => f && f.key === 'codigo');

  const toCreate = [];
  const toUpdate = [];
  const errors = [];

  if (codigoColIdx === -1) {
    errors.push({ row: 0, message: 'No se encontró la columna "Código" en el archivo. No se puede importar.' });
    return { toCreate, toUpdate, errors, unmatchedHeaders, delimiter };
  }

  for (let r = 1; r < rows.length; r++) {
    const row = rows[r];
    if (row.every(c => c.trim() === '')) continue; // fila vacia, ignorar

    const codigo = (row[codigoColIdx] || '').trim();
    if (!codigo) {
      errors.push({ row: r + 1, message: 'Fila sin "Código", se omite.' });
      continue;
    }

    const data = {};
    colMap.forEach((field, idx) => {
      if (!field) return;
      if (field.type === 'datetime') return; // campo autogestionado (Última Actualización), no se importa
      let raw = row[idx] !== undefined ? row[idx].trim() : '';
      if (field.type === 'date' && raw) raw = parseDateOnlyToISO(raw);
      data[field.key] = raw;
    });
    data.codigo = codigo;

    const existing = existingDevices.find(d => d.codigo === codigo);
    if (existing) {
      toUpdate.push({ id: existing.id, codigo, data });
    } else {
      toCreate.push(data);
    }
  }

  return { toCreate, toUpdate, errors, unmatchedHeaders, delimiter };
}

module.exports = { analyzeCSV };
