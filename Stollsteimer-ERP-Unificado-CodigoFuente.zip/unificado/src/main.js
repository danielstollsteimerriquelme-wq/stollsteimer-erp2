const { app, BrowserWindow, ipcMain, dialog, shell, clipboard } = require('electron');
const path = require('path');
const fs = require('fs');
const store = require('./store');
const { exportCSV, exportPDF } = require('./exporter');
const { analyzeCSV } = require('./importer');
const accesos = require('./accesos/main-accesos');

// Evita la pantalla en blanco que produce Electron en algunos equipos Windows
// (drivers de video antiguos, maquinas virtuales, RDP) por fallas al componer
// con aceleracion de GPU.
app.disableHardwareAcceleration();
app.commandLine.appendSwitch('disable-gpu');
app.commandLine.appendSwitch('disable-gpu-compositing');
app.commandLine.appendSwitch('disable-software-rasterizer');

let mainWindow;

// Si algo inesperado revienta en el proceso principal, mostrar un mensaje
// visible en vez de dejar la ventana en blanco sin ninguna explicacion.
process.on('uncaughtException', (err) => {
  try {
    dialog.showErrorBox('Stollsteimer-ERP — Error inesperado', String(err && err.stack || err));
  } catch (e) { /* no-op */ }
});

function sanitizeFilename(name) {
  return String(name || 'dispositivo').replace(/[\\/:*?"<>|]+/g, '-').trim() || 'dispositivo';
}

function pad(n) { return String(n).padStart(2, '0'); }

// yyyymmdd-HHMMss en hora local, 24 horas — usado en nombres de archivo
function fileTimestamp(d = new Date()) {
  return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
}

function getDataDir() {
  // Si corre como .exe portable, Electron define esta variable apuntando
  // a la carpeta donde esta el ejecutable -> los datos viajan con el .exe
  const portableDir = process.env.PORTABLE_EXECUTABLE_DIR;
  const base = portableDir || app.getPath('userData');
  const dataDir = path.join(base, 'Stollsteimer-ERP-Data');
  const imagesDir = path.join(dataDir, 'imagenes');
  if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
  if (!fs.existsSync(imagesDir)) fs.mkdirSync(imagesDir, { recursive: true });
  return { dataDir, imagesDir };
}

// ---------- Respaldo automático diario a CSV ----------
let backupDataDir = null;

function getBackupsDir() {
  const dir = path.join(backupDataDir, 'Backups');
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function todayStr(d = new Date()) {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

function runBackupNow() {
  const devices = store.getAll();
  const schema = store.getSchema();
  const stamp = fileTimestamp();
  const dir = getBackupsDir();

  // 1) CSV legible con los dispositivos (para abrir en Excel)
  const csvPath = path.join(dir, `Stollsteimer-ERP-Respaldo-${stamp}.csv`);
  exportCSV(devices, schema, csvPath);

  // 2) Respaldo COMPLETO de la configuración y los datos internos.
  // El CSV no alcanza para restaurar: no incluye el esquema de campos, los
  // colores, el orden de columnas, ni los historiales de mantenimiento /
  // N° de serie / referencias de imágenes. Este JSON sí.
  const settings = store.getSettings();
  const fullBackup = {
    generadoEl: new Date().toISOString(),
    version: app.getVersion(),
    schema,
    settings,
    devices
  };
  const jsonPath = path.join(dir, `Stollsteimer-ERP-Respaldo-${stamp}.json`);
  fs.writeFileSync(jsonPath, JSON.stringify(fullBackup, null, 2), 'utf-8');

  store.saveBackupConfig({ lastBackupDate: todayStr(), lastBackupFile: csvPath });
  return { csvPath, jsonPath };
}

function checkScheduledBackup() {
  try {
    const settings = store.getSettings();
    const backup = settings.backup || {};
    if (!backup.enabled) return;
    const now = new Date();
    const [h, m] = String(backup.time || '18:00').split(':').map(Number);
    const scheduled = new Date(now.getFullYear(), now.getMonth(), now.getDate(), h || 0, m || 0, 0);
    const alreadyDoneToday = backup.lastBackupDate === todayStr(now);
    if (!alreadyDoneToday && now >= scheduled) {
      runBackupNow();
    }
  } catch (err) {
    console.error('Error en respaldo automático:', err);
  }
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1100,
    minHeight: 700,
    backgroundColor: '#f4f5f7',
    show: false,
    icon: path.join(__dirname, '..', 'assets', 'icons', 'icon.ico'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      // Los módulos (ERP y Accesos) viven en iframes dentro de la ventana;
      // el preload debe cargarse también en ellos para exponer sus APIs.
      nodeIntegrationInSubFrames: true
    }
  });
  mainWindow.setMenuBarVisibility(false);

  // Mostrar la ventana solo cuando el contenido ya esta listo, para no
  // exponer un frame en blanco mientras carga.
  mainWindow.once('ready-to-show', () => mainWindow.show());

  mainWindow.webContents.on('did-fail-load', (e, code, desc) => {
    dialog.showErrorBox('Stollsteimer-ERP — No se pudo cargar la interfaz', `${desc} (código ${code})`);
  });
  mainWindow.webContents.on('render-process-gone', (e, details) => {
    dialog.showErrorBox('Stollsteimer-ERP — La interfaz se cerró inesperadamente', JSON.stringify(details));
  });
  mainWindow.webContents.on('unresponsive', () => {
    dialog.showErrorBox('Stollsteimer-ERP', 'La ventana dejó de responder. Puedes cerrarla y volver a abrir el programa.');
  });

  mainWindow.loadFile(path.join(__dirname, 'renderer', 'shell.html'));
}

// Una sola instancia: si se abre otra vez el programa, se enfoca la ventana existente.
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (mainWindow) { if (mainWindow.isMinimized()) mainWindow.restore(); mainWindow.focus(); }
  });

  app.whenReady().then(() => {
    // Los datos viajan junto al .exe (portable); cada módulo conserva su carpeta.
    try {
      const { dataDir, imagesDir } = getDataDir();
      store.init(dataDir, imagesDir);
      backupDataDir = dataDir;
    } catch (err) {
      dialog.showErrorBox('Stollsteimer-ERP — Error al cargar los datos', String(err && err.stack || err));
    }
    try {
      accesos.init(process.env.PORTABLE_EXECUTABLE_DIR || app.getPath('userData'));
    } catch (err) {
      dialog.showErrorBox('Stollsteimer-Accesos — Error de carpeta de datos', String(err && err.stack || err));
    }
    createWindow();

    // Respaldo automatico del ERP: revisa cada minuto si toca generar el CSV del dia.
    // Tambien revisa una vez al iniciar, por si el programa se abre despues
    // de la hora programada (la app debe estar abierta para que se dispare,
    // ya que no corre como servicio en segundo plano de Windows).
    checkScheduledBackup();
    setInterval(checkScheduledBackup, 60 * 1000);

    app.on('activate', () => {
      if (BrowserWindow.getAllWindows().length === 0) createWindow();
    });
  });
}

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

// ---------- IPC: portapapeles (tabla HTML para pegar en un correo) ----------
// Compartido por los dos módulos (ERP y Accesos).
ipcMain.handle('clipboard:writeHtml', (e, html, text) => {
  clipboard.write({ html, text });
  return true;
});

// ---------- IPC: módulo Accesos ----------
accesos.registerIpc(() => mainWindow);

// ---------- IPC: dispositivos ----------
ipcMain.handle('devices:getAll', () => store.getAll());
ipcMain.handle('devices:getSchema', () => store.getSchema());
ipcMain.handle('devices:add', (e, device) => store.addDevice(device));
ipcMain.handle('devices:update', (e, id, patch) => store.updateDevice(id, patch));
ipcMain.handle('devices:delete', (e, id) => store.deleteDevice(id));
ipcMain.handle('devices:duplicate', (e, id) => store.duplicateDevice(id));

// ---------- IPC: configuracion de columnas/campos ----------
ipcMain.handle('settings:get', () => store.getSettings());
ipcMain.handle('settings:save', (e, settings) => store.saveSettings(settings));

// ---------- IPC: campos personalizados ----------
ipcMain.handle('fields:add', (e, field) => store.addField(field));
ipcMain.handle('fields:remove', (e, key) => store.removeField(key));
ipcMain.handle('fields:rename', (e, key, newLabel) => store.renameField(key, newLabel));
ipcMain.handle('fields:addOption', (e, key, value) => store.addFieldOption(key, value));
ipcMain.handle('fields:renameOption', (e, key, oldValue, newValue) => store.renameFieldOption(key, oldValue, newValue));
ipcMain.handle('fields:deleteOption', (e, key, value) => store.deleteFieldOption(key, value));
ipcMain.handle('fields:setOptionColor', (e, key, value, bg, text) => store.setOptionColor(key, value, bg, text));
ipcMain.handle('fields:resetOptionColor', (e, key, value) => store.resetOptionColor(key, value));

// ---------- IPC: mantenimientos ----------
ipcMain.handle('maint:add', (e, deviceId, entry) => store.addMaintenance(deviceId, entry));
ipcMain.handle('maint:update', (e, deviceId, entryId, patch) => store.updateMaintenance(deviceId, entryId, patch));
ipcMain.handle('maint:delete', (e, deviceId, entryId) => store.deleteMaintenance(deviceId, entryId));

// ---------- IPC: imagenes ----------
ipcMain.handle('images:pick', async (e, deviceId) => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: 'Seleccionar imagenes',
    properties: ['openFile', 'multiSelections'],
    filters: [{ name: 'Imagenes', extensions: ['png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp'] }]
  });
  if (result.canceled) return null;
  return store.addImages(deviceId, result.filePaths);
});
ipcMain.handle('images:remove', (e, deviceId, imageId) => store.removeImage(deviceId, imageId));
ipcMain.handle('images:getPath', (e, imageFilename) => path.join(store.getImagesDir(), imageFilename));

// ---------- IPC: exportacion ----------
ipcMain.handle('export:csv', async (e, scope, ids, fieldKeys) => {
  const devices = store.getAll();
  let schema = store.getSchema();
  if (Array.isArray(fieldKeys) && fieldKeys.length > 0) {
    schema = schema.filter(f => fieldKeys.includes(f.key));
  }
  const list = scope === 'all' ? devices : devices.filter(d => ids.includes(d.id));
  const defaultName = scope === 'individual' && list.length === 1
    ? `Stollsteimer-ERP-individual-${sanitizeFilename(list[0].codigo || list[0].id)}.csv`
    : `Stollsteimer-ERP-${scope}-${fileTimestamp()}.csv`;
  const result = await dialog.showSaveDialog(mainWindow, {
    title: 'Exportar CSV',
    defaultPath: defaultName,
    filters: [{ name: 'CSV', extensions: ['csv'] }]
  });
  if (result.canceled) return { ok: false };
  exportCSV(list, schema, result.filePath);
  return { ok: true, path: result.filePath };
});

ipcMain.handle('export:pdf', async (e, scope, ids, fieldKeys) => {
  const devices = store.getAll();
  let schema = store.getSchema();
  if (Array.isArray(fieldKeys) && fieldKeys.length > 0) {
    schema = schema.filter(f => fieldKeys.includes(f.key));
  }
  const list = scope === 'all' ? devices : devices.filter(d => ids.includes(d.id));
  const defaultName = scope === 'individual' && list.length === 1
    ? `Stollsteimer-ERP-individual-${sanitizeFilename(list[0].codigo || list[0].id)}.pdf`
    : `Stollsteimer-ERP-${scope}-${fileTimestamp()}.pdf`;
  const result = await dialog.showSaveDialog(mainWindow, {
    title: 'Exportar PDF',
    defaultPath: defaultName,
    filters: [{ name: 'PDF', extensions: ['pdf'] }]
  });
  if (result.canceled) return { ok: false };
  await exportPDF(list, schema, result.filePath, { imagesDir: store.getImagesDir(), detailed: scope === 'individual' });
  return { ok: true, path: result.filePath };
});

ipcMain.handle('shell:openPath', (e, filePath) => shell.showItemInFolder(filePath));

// ---------- IPC: respaldo automático ----------
ipcMain.handle('backup:getConfig', () => store.getSettings().backup);
ipcMain.handle('backup:saveConfig', (e, patch) => store.saveBackupConfig(patch).backup);
ipcMain.handle('backup:runNow', () => {
  try {
    const { csvPath, jsonPath } = runBackupNow();
    return { ok: true, path: csvPath, jsonPath };
  } catch (err) {
    return { ok: false, error: err.message };
  }
});
ipcMain.handle('backup:getFolder', () => getBackupsDir());

// Restaurar la configuración y los datos desde un respaldo .json
ipcMain.handle('backup:restore', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: 'Restaurar desde respaldo',
    properties: ['openFile'],
    defaultPath: getBackupsDir(),
    filters: [{ name: 'Respaldo Stollsteimer-ERP', extensions: ['json'] }]
  });
  if (result.canceled) return null;
  try {
    const raw = fs.readFileSync(result.filePaths[0], 'utf-8');
    const data = JSON.parse(raw);
    if (!Array.isArray(data.devices) || !Array.isArray(data.schema)) {
      return { ok: false, error: 'El archivo no tiene el formato de un respaldo válido.' };
    }
    store.saveSchema(data.schema);
    if (data.settings) store.saveSettings(data.settings);
    store.saveAll(data.devices);
    return {
      ok: true,
      devices: data.devices.length,
      generadoEl: data.generadoEl || null,
      file: path.basename(result.filePaths[0])
    };
  } catch (err) {
    return { ok: false, error: err.message };
  }
});

// ---------- IPC: importacion CSV ----------
ipcMain.handle('import:csv:pick', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: 'Importar CSV',
    properties: ['openFile'],
    filters: [{ name: 'CSV', extensions: ['csv'] }]
  });
  if (result.canceled) return null;
  const filePath = result.filePaths[0];
  let content;
  try {
    content = fs.readFileSync(filePath, 'utf-8');
  } catch (err) {
    return { error: `No se pudo leer el archivo: ${err.message}` };
  }
  const schema = store.getSchema();
  const existingDevices = store.getAll();
  const analysis = analyzeCSV(content, schema, existingDevices);
  return { fileName: path.basename(filePath), ...analysis };
});

ipcMain.handle('import:csv:commit', async (e, toCreate, toUpdate) => {
  let created = 0, updated = 0;
  (toCreate || []).forEach(data => { store.addDevice(data); created++; });
  (toUpdate || []).forEach(({ id, data }) => { if (store.updateDevice(id, data)) updated++; });
  return { created, updated };
});
