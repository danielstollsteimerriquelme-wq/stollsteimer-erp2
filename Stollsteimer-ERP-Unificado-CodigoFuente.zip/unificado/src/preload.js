const { contextBridge, ipcRenderer } = require('electron');
const inv = (ch, ...a) => ipcRenderer.invoke(ch, ...a);

// ---- API del módulo ERP (window.api) ----
contextBridge.exposeInMainWorld('api', {
  getAll: () => inv('devices:getAll'),
  getSchema: () => inv('devices:getSchema'),
  getSettings: () => inv('settings:get'),
  saveSettings: (settings) => inv('settings:save', settings),
  addDevice: (device) => inv('devices:add', device),
  updateDevice: (id, patch) => inv('devices:update', id, patch),
  deleteDevice: (id) => inv('devices:delete', id),
  duplicateDevice: (id) => inv('devices:duplicate', id),

  addField: (field) => inv('fields:add', field),
  removeField: (key) => inv('fields:remove', key),
  renameField: (key, newLabel) => inv('fields:rename', key, newLabel),
  addFieldOption: (key, value) => inv('fields:addOption', key, value),
  renameFieldOption: (key, oldValue, newValue) => inv('fields:renameOption', key, oldValue, newValue),
  deleteFieldOption: (key, value) => inv('fields:deleteOption', key, value),
  setOptionColor: (key, value, bg, text) => inv('fields:setOptionColor', key, value, bg, text),
  resetOptionColor: (key, value) => inv('fields:resetOptionColor', key, value),

  addMaint: (deviceId, entry) => inv('maint:add', deviceId, entry),
  updateMaint: (deviceId, entryId, patch) => inv('maint:update', deviceId, entryId, patch),
  deleteMaint: (deviceId, entryId) => inv('maint:delete', deviceId, entryId),

  pickImages: (deviceId) => inv('images:pick', deviceId),
  removeImage: (deviceId, imageId) => inv('images:remove', deviceId, imageId),
  getImagePath: (filename) => inv('images:getPath', filename),

  exportCSV: (scope, ids, fields) => inv('export:csv', scope, ids, fields),
  exportPDF: (scope, ids, fields) => inv('export:pdf', scope, ids, fields),
  pickImportCSV: () => inv('import:csv:pick'),
  commitImportCSV: (toCreate, toUpdate) => inv('import:csv:commit', toCreate, toUpdate),
  openInFolder: (filePath) => inv('shell:openPath', filePath),

  getBackupConfig: () => inv('backup:getConfig'),
  saveBackupConfig: (patch) => inv('backup:saveConfig', patch),
  runBackupNow: () => inv('backup:runNow'),
  restoreBackup: () => inv('backup:restore'),
  getBackupFolder: () => inv('backup:getFolder'),

  // Copiar tabla al portapapeles para pegarla en un correo
  copyHtml: (html, text) => inv('clipboard:writeHtml', html, text)
});

// ---- API del módulo Accesos (window.accesosApi) ----
contextBridge.exposeInMainWorld('accesosApi', {
  loadDb: () => inv('acc:db:load'),
  saveDb: (db) => inv('acc:db:save', db),
  copyHtml: (html, text) => inv('clipboard:writeHtml', html, text),
  exportFile: (payload) => inv('acc:export:save', payload),
  pickImport: () => inv('acc:import:pick'),
  writeBackup: (stamp, dbJson, sheets) => inv('acc:backup:write', stamp, dbJson, sheets),
  pickRestore: () => inv('acc:backup:pickRestore'),
  openFolder: (which) => inv('acc:shell:openFolder', which),
  showItem: (p) => inv('acc:shell:showItem', p)
});
