/* Interfaz principal de Stollsteimer-Accesos */
const L = window.Logic;
const App = {
  db: null, dataDir: '', backupDir: '',
  view: 'accesos',
  ui: {
    q: { accesos: '', diff: '', tui: '' },
    sort: {}, filters: { accesos: {}, diff: {}, tui: {} },
    limit: { accesos: 300, diff: 300, tui: 300 },
    sel: { accesos: new Set(), diff: new Set(), tui: new Set() },
    lastIdx: null, viewIds: []
  }
};

// ============================ Utilidades ============================
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const clone = (o) => JSON.parse(JSON.stringify(o));
const uid = () => 'r' + Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
const isDataView = () => TAB_ORDER.includes(App.view);
const curTab = () => App.view;

let toastTimer;
function toast(msg, type = 'success', ms = 3200) {
  const t = $('#toast');
  t.textContent = msg; t.className = 'toast ' + type;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.add('hidden'), ms);
}

let saveTimer;
function persist() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(flushSave, 200);
}
async function flushSave() {
  clearTimeout(saveTimer);
  try {
    const r = await window.accesosApi.saveDb(App.db);
    if (r && !r.ok) toast('No se pudo guardar: ' + r.error, 'error', 6000);
  } catch (e) { toast('No se pudo guardar: ' + e.message, 'error', 6000); }
}
window.addEventListener('beforeunload', () => { try { window.accesosApi.saveDb(App.db); } catch (e) { /* no-op */ } });

// ============================ Modales ============================
function openModal({ title, body, footer, cls = 'modal-medium', onClose }) {
  const ov = document.createElement('div');
  ov.className = 'modal-overlay';
  ov.innerHTML = `<div class="modal ${cls}">
    <div class="modal-header"><h2>${title}</h2><button class="btn-close" data-close>✕</button></div>
    <div class="modal-body">${body}</div>${footer ? `<div class="modal-footer">${footer}</div>` : ''}</div>`;
  $('#modalRoot').appendChild(ov);
  const api = { el: ov, q: (s) => $(s, ov), close() { ov.remove(); if (onClose) onClose(); } };
  $('[data-close]', ov).addEventListener('click', () => api.close());
  return api;
}
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    const ovs = $$('#modalRoot .modal-overlay');
    if (ovs.length) { const btn = $('[data-close]', ovs[ovs.length - 1]); if (btn) btn.click(); }
  }
});
function confirmBox(text, okLabel = 'Confirmar', danger = true) {
  return new Promise(res => {
    const m = openModal({
      title: 'Confirmar', cls: 'modal-small wide',
      body: `<p style="margin:0">${esc(text).replace(/\n/g, '<br>')}</p>`,
      footer: `<span></span><div class="modal-actions"><button class="btn btn-ghost" data-no>Cancelar</button><button class="btn ${danger ? 'btn-danger' : 'btn-primary'}" data-yes>${esc(okLabel)}</button></div>`
    });
    let done = false;
    const fin = (v) => { if (done) return; done = true; m.el.remove(); res(v); };
    $('[data-no]', m.el).onclick = () => fin(false);
    $('[data-close]', m.el).onclick = () => fin(false);
    $('[data-yes]', m.el).onclick = () => fin(true);
    $('[data-yes]', m.el).focus();
  });
}
function typedConfirm(text) {
  return new Promise(res => {
    const m = openModal({
      title: '⚠ Confirmación final', cls: 'modal-small wide',
      body: `<p style="margin-top:0">${esc(text)}</p><p class="muted">Para confirmar, escribe <b>ELIMINAR</b>:</p>
             <input type="text" id="tcIn" autocomplete="off" style="width:100%;padding:8px 10px;border:1px solid var(--border);border-radius:6px">`,
      footer: `<span></span><div class="modal-actions"><button class="btn btn-ghost" data-no>Cancelar</button><button class="btn btn-danger" data-yes disabled>Eliminar definitivamente</button></div>`
    });
    let done = false;
    const fin = (v) => { if (done) return; done = true; m.el.remove(); res(v); };
    const inp = $('#tcIn', m.el), yes = $('[data-yes]', m.el);
    inp.oninput = () => { yes.disabled = inp.value.trim().toUpperCase() !== 'ELIMINAR'; };
    $('[data-no]', m.el).onclick = () => fin(false);
    $('[data-close]', m.el).onclick = () => fin(false);
    yes.onclick = () => fin(true);
    inp.focus();
  });
}
function inputBox(title, label, value = '') {
  return new Promise(res => {
    const m = openModal({
      title: esc(title), cls: 'modal-small wide',
      body: `<p class="muted" style="margin-top:0">${esc(label)}</p><input type="text" id="ibIn" value="${esc(value)}" style="width:100%;padding:8px 10px;border:1px solid var(--border);border-radius:6px">`,
      footer: `<span></span><div class="modal-actions"><button class="btn btn-ghost" data-no>Cancelar</button><button class="btn btn-primary" data-yes>Guardar</button></div>`
    });
    let done = false;
    const fin = (v) => { if (done) return; done = true; m.el.remove(); res(v); };
    const inp = $('#ibIn', m.el);
    $('[data-no]', m.el).onclick = () => fin(null);
    $('[data-close]', m.el).onclick = () => fin(null);
    $('[data-yes]', m.el).onclick = () => fin(inp.value.trim());
    inp.onkeydown = (e) => { if (e.key === 'Enter') fin(inp.value.trim()); };
    inp.focus(); inp.select();
  });
}

// ============================ Datos y campos ============================
function defaultDb() {
  return {
    version: 1,
    settings: {
      autorizaNombre: 'Raúl Segovia', gestionoDefault: 'DASR', horaInicio: '10:00',
      backup: { enabled: false, time: '18:00', lastBackupDate: '', lastBackupFile: '' },
      emailCols: {}, columns: {}, labels: {}
    },
    lists: {
      accesos: [{ value: 'Acceso a sistema' }, { value: 'Carpeta de red' }, { value: 'VPN' }, { value: 'Correo' }],
      estados: [
        { value: 'Pendiente', bg: '#fdf1d6', color: '#8a6d00' },
        { value: 'En proceso', bg: '#e3f0fc', color: '#1565a3' },
        { value: 'Gestionado', bg: '#e2f4e6', color: '#2e7d32' },
        { value: 'Rechazado', bg: '#fbe3e0', color: '#c0392b' },
        { value: 'Anulado', bg: '#e6edf3', color: '#6b7684' }
      ]
    },
    customFields: { accesos: [], diff: [], tui: [] },
    tables: { accesos: [], diff: [], tui: [] }
  };
}
function migrate(db) {
  const d = defaultDb();
  const out = Object.assign({}, d, db || {});
  out.settings = Object.assign({}, d.settings, (db && db.settings) || {});
  out.settings.backup = Object.assign({}, d.settings.backup, (db && db.settings && db.settings.backup) || {});
  ['emailCols', 'columns', 'labels'].forEach(k => { out.settings[k] = out.settings[k] || {}; });
  out.lists = Object.assign({}, d.lists, (db && db.lists) || {});
  out.customFields = Object.assign({}, d.customFields, (db && db.customFields) || {});
  out.tables = Object.assign({}, d.tables, (db && db.tables) || {});
  TAB_ORDER.forEach(t => {
    out.customFields[t] = out.customFields[t] || [];
    out.tables[t] = out.tables[t] || [];
    out.tables[t].forEach(r => { if (!r.id) r.id = uid(); });
  });
  return out;
}
const rowsOf = (tab) => App.db.tables[tab];

function allFields(tab) {
  const labels = App.db.settings.labels[tab] || {};
  const base = TABS[tab].fields.map(f => Object.assign({}, f, { label: labels[f.key] || f.label }));
  const custom = (App.db.customFields[tab] || []).map(cf => ({
    key: cf.key, label: cf.label, type: cf.type, custom: true, inline: cf.type === 'yn',
    optionsFn: () => cf.options || [], aliases: [L.normHeader(cf.label)]
  }));
  return base.concat(custom);
}
function colsFor(tab, includeHidden = false) {
  const cfg = App.db.settings.columns[tab] || { order: [], hidden: [] };
  const fields = allFields(tab);
  const byKey = Object.fromEntries(fields.map(f => [f.key, f]));
  const order = (cfg.order || []).filter(k => byKey[k]);
  fields.forEach(f => { if (!order.includes(f.key)) order.push(f.key); });
  const hidden = new Set(cfg.hidden || []);
  return order.filter(k => includeHidden || !hidden.has(k)).map(k => byKey[k]);
}
function cellText(f, row) {
  if (f.text) return f.text(row);
  const v = row[f.key];
  switch (f.type) {
    case 'datetime': return L.fmtDT(v);
    case 'date': return L.fmtD(v);
    case 'int': return v === '' || v == null ? '' : String(L.toInt(v));
    default: return v == null ? '' : String(v);
  }
}
const cellColor = (f, row) => (f.color ? f.color(row) : null);

function sortVal(f, row) {
  if (f.sortVal) return f.sortVal(row);
  const v = row[f.key];
  if (f.type === 'int') return L.toInt(v);
  if (v == null) return '';
  if (f.type === 'date' || f.type === 'datetime') return String(v);
  return String(v).toLowerCase();
}
function cmpVals(a, b) {
  const ea = a === '' || a == null, eb = b === '' || b == null;
  if (ea || eb) return ea === eb ? 0 : (ea ? 1 : -1);   // vacíos siempre al final (se maneja fuera)
  if (typeof a === 'number' && typeof b === 'number') return a - b;
  return String(a).localeCompare(String(b), 'es', { numeric: true });
}
function sortedRows(tab, rows) {
  const t = TABS[tab];
  const s = App.ui.sort[tab] || t.defaultSort;
  const fields = allFields(tab);
  const f = fields.find(x => x.key === s.key) || fields[0];
  const df = fields.find(x => x.key === t.defaultSort.key);
  const dir = s.dir === 'asc' ? 1 : -1;
  return rows.slice().sort((r1, r2) => {
    const a = sortVal(f, r1), b = sortVal(f, r2);
    const ea = a === '' || a == null, eb = b === '' || b == null;
    if (ea !== eb) return ea ? 1 : -1;
    let c = cmpVals(a, b) * dir;
    if (c === 0 && df) c = cmpVals(sortVal(df, r1), sortVal(df, r2)) * (t.defaultSort.dir === 'asc' ? 1 : -1);
    return c;
  });
}
function filteredRows(tab) {
  const t = TABS[tab];
  const fl = App.ui.filters[tab];
  let rows = rowsOf(tab);
  t.filters.forEach(flt => { const v = fl[flt.id]; if (v != null) rows = rows.filter(r => flt.get(r) === v); });
  const q = App.ui.q[tab];
  if (q && q.trim()) {
    const fields = allFields(tab);
    rows = rows.filter(r => L.matchQuery(q, fields.map(f => cellText(f, r))));
  }
  return sortedRows(tab, rows);
}

// ============================ Navegación / vistas ============================
function renderNav() {
  const items = TAB_ORDER.map(id => ({ id, label: `${TABS[id].icon} ${TABS[id].title}` }))
    .concat([{ sep: true }, { id: 'listas', label: '🗂 Listas' }, { id: 'campos', label: '🧩 Campos' }, { id: 'ajustes', label: '💾 Ajustes y respaldo' }]);
  $('#topNav').innerHTML = items.map(i => i.sep ? '<span class="sep-v"></span>'
    : `<button class="nav-btn ${App.view === i.id ? 'active' : ''}" data-view="${i.id}">${i.label}</button>`).join('');
}
function setView(v) {
  App.view = v;
  $$('.view').forEach(s => s.classList.remove('active'));
  const id = isDataView() ? 'view-data' : 'view-' + v;
  $('#' + id).classList.add('active');
  $('#sidebar').classList.toggle('hidden', !isDataView());
  $('#btnNew').classList.toggle('hidden', !isDataView());
  $('#searchInput').classList.toggle('hidden', !isDataView());
  renderAll();
}
function renderAll() {
  renderNav();
  if (isDataView()) {
    const t = TABS[curTab()];
    $('#btnNew').textContent = t.newLabel;
    const si = $('#searchInput');
    if (document.activeElement !== si) si.value = App.ui.q[curTab()];
    renderSidebar(); renderTable();
  } else if (App.view === 'listas') renderListas();
  else if (App.view === 'campos') renderCampos();
  else if (App.view === 'ajustes') renderAjustes();
}

// ============================ Sidebar ============================
function renderSidebar() {
  const tab = curTab(), t = TABS[tab], rows = rowsOf(tab), fl = App.ui.filters[tab];
  let html = '';
  t.filters.forEach(flt => {
    const counts = {};
    rows.forEach(r => { const v = flt.get(r); if (v !== '' && v != null) counts[v] = (counts[v] || 0) + 1; });
    let values = flt.values ? flt.values().slice() : [];
    Object.keys(counts).forEach(v => { if (!values.includes(v)) values.push(v); });
    if (!flt.values) values.sort((a, b) => (flt.desc ? b.localeCompare(a) : a.localeCompare(b)));
    html += `<div class="sidebar-section"><h4>Filtrar por ${esc(flt.label)}</h4><div class="filter-list">` +
      (values.length ? values.map(v => {
        const c = flt.color ? flt.color(v) : null;
        return `<div class="filter-chip ${fl[flt.id] === v ? 'active' : ''}" data-flt="${flt.id}" data-val="${esc(v)}">
          <span class="filter-chip-label">${c ? `<span class="dot" style="background:${c.bg};border-color:${c.color}"></span>` : ''}${esc(v)}</span>
          <span class="count">${counts[v] || 0}</span></div>`;
      }).join('') : '<span class="muted">Sin datos</span>') + '</div></div>';
  });
  $('#filterBox').innerHTML = html;
}

// ============================ Tabla ============================
function renderCell(tab, f, row) {
  const text = cellText(f, row);
  const col = cellColor(f, row);
  const k = esc(f.key);
  if (f.type === 'yn' && f.inline) {
    const v = row[f.key] === 'SI' ? 'SI' : 'NO';
    return `<td class="center"><span class="pill yn ${v === 'SI' ? 'yn-si' : 'yn-no'}" data-act="toggleYN" data-key="${k}" title="Clic para cambiar">${v}</span></td>`;
  }
  if (f.inline === 'toggle') {
    const st = col ? `background:${col.bg};color:${col.color}` : '';
    return `<td class="center"><span class="pill clickable" style="${st}" data-act="toggleSel" data-key="${k}" title="Clic para cambiar">${esc(text)}</span></td>`;
  }
  if (f.type === 'select' && f.inline === true) {
    let opts = f.optionsFn();
    if (row[f.key] && !opts.includes(row[f.key])) opts = opts.concat([row[f.key]]);
    const st = col ? `background:${col.bg};color:${col.color}` : '';
    return `<td><select class="inline-select" data-key="${k}" style="${st}"><option value=""></option>${opts.map(o => `<option ${o === row[f.key] ? 'selected' : ''}>${esc(o)}</option>`).join('')}</select></td>`;
  }
  if (f.pill) {
    const st = col ? `background:${col.bg};color:${col.color}` : '';
    return `<td class="center"><span class="pill" style="${st}">${esc(text)}</span></td>`;
  }
  const cls = (f.type === 'int' || (f.type === 'computed' && /^[-\d,.:%]+$/.test(text))) ? 'num mono' : (f.type === 'datetime' || f.type === 'date' || f.type === 'ref' ? 'mono' : '');
  return `<td class="${cls}" title="${esc(text)}">${esc(text)}</td>`;
}
function renderTable() {
  const tab = curTab(), t = TABS[tab];
  const cols = colsFor(tab);
  const rows = filteredRows(tab);
  const sort = App.ui.sort[tab] || t.defaultSort;
  const limit = App.ui.limit[tab];
  const sel = App.ui.sel[tab];

  $('#tHead').innerHTML = '<tr><th class="col-chk"></th>' + cols.map(f => {
    const active = sort.key === f.key;
    const cls = (f.type === 'int' ? 'num ' : '') + (active ? 'sort-active' : '');
    return `<th class="sortable ${cls}" data-sort="${esc(f.key)}">${esc(f.label)}<span class="sort-arrow">${active ? (sort.dir === 'asc' ? '▲' : '▼') : '▲▼'}</span></th>`;
  }).join('') + '<th class="col-act">Acciones</th></tr>';

  const shown = rows.slice(0, limit);
  App.ui.viewIds = rows.map(r => r.id);
  $('#tBody').innerHTML = shown.length ? shown.map(r => `<tr data-id="${r.id}" class="${sel.has(r.id) ? 'selected' : ''}">
      <td class="col-chk"><input type="checkbox" class="rowchk" ${sel.has(r.id) ? 'checked' : ''}></td>
      ${cols.map(f => renderCell(tab, f, r)).join('')}
      <td class="col-act"><div class="row-actions" style="justify-content:center">
        <button class="icon-btn" data-act="edit" title="Editar">✏️</button>
        ${tab !== 'diff' ? '<button class="icon-btn" data-act="dup" title="Duplicar">⧉</button>' : ''}
        <button class="icon-btn" data-act="del" title="Eliminar">🗑</button></div></td></tr>`).join('')
    : `<tr class="empty-row"><td colspan="${cols.length + 2}">${rowsOf(tab).length ? 'Ningún registro coincide con la búsqueda o los filtros.' : `Aún no hay ${t.unit}. Usa “${t.newLabel.replace('＋ ', '')}” o importa un CSV / Excel.`}</td></tr>`;

  $('#pager').classList.toggle('hidden', rows.length <= limit);
  $('#btnMore').textContent = `Mostrar más filas (${Math.min(limit, rows.length)} de ${rows.length})`;
  $('#statTotal').textContent = rows.length;
  $('#statLabel').textContent = t.unit;
  $('#statSub').textContent = rows.length !== rowsOf(tab).length ? `de ${rowsOf(tab).length} en total` : '';
  updateSelectionUI(rows);
}
function updateSelectionUI(rows) {
  const tab = curTab(), sel = App.ui.sel[tab];
  rows = rows || filteredRows(tab);
  const n = sel.size;
  $('#selectionCount').textContent = n ? `${n} seleccionada${n > 1 ? 's' : ''}` : '';
  ['btnCopyMail', 'btnMailCols', 'btnBulkDelete'].forEach(id => $('#' + id).classList.toggle('hidden', !n));
  const all = rows.length > 0 && rows.every(r => sel.has(r.id));
  $('#selectAll').checked = all;
}

// ============================ Cambios en línea ============================
function findRow(tab, id) { return rowsOf(tab).find(r => r.id === id); }
function inlineSet(tab, id, key, val) {
  const row = findRow(tab, id); if (!row) return;
  const prev = row[key];
  row[key] = val;
  const t = TABS[tab];
  if (t.onChange) t.onChange(row, key, { prev, touched: { autorizo: true } });
  persist(); renderAll();
  if (tab === 'accesos' && key === 'enviada' && val === 'SI') toast(`Gestión registrada: ${L.fmtDT(row.gestion)}`);
  if (tab === 'accesos' && key === 'reingreso' && val === 'SI') { toast('Indica la fecha de reingreso', 'success'); openRowModal(tab, id); }
}

// ============================ Eventos de tabla ============================
function bindTable() {
  $('#tHead').addEventListener('click', (e) => {
    const th = e.target.closest('th[data-sort]'); if (!th) return;
    const tab = curTab(), key = th.dataset.sort;
    const cur = App.ui.sort[tab] || TABS[tab].defaultSort;
    App.ui.sort[tab] = { key, dir: cur.key === key && cur.dir === 'asc' ? 'desc' : 'asc' };
    renderTable();
  });
  const body = $('#tBody');
  body.addEventListener('click', (e) => {
    const tr = e.target.closest('tr[data-id]'); if (!tr) return;
    const tab = curTab(), id = tr.dataset.id, sel = App.ui.sel[tab];
    if (e.target.classList.contains('rowchk')) {
      const ids = App.ui.viewIds, idx = ids.indexOf(id);
      if (e.shiftKey && App.ui.lastIdx != null) {
        const [a, b] = [Math.min(idx, App.ui.lastIdx), Math.max(idx, App.ui.lastIdx)];
        for (let i = a; i <= b; i++) sel.add(ids[i]);
        renderTable();
      } else {
        if (e.target.checked) sel.add(id); else sel.delete(id);
        tr.classList.toggle('selected', e.target.checked);
        updateSelectionUI();
      }
      App.ui.lastIdx = idx;
      return;
    }
    const act = e.target.closest('[data-act]');
    if (!act) return;
    const a = act.dataset.act;
    if (a === 'edit') openRowModal(tab, id);
    else if (a === 'dup') duplicateRow(tab, id);
    else if (a === 'del') deleteRows(tab, [id]);
    else if (a === 'toggleYN') { const r = findRow(tab, id); inlineSet(tab, id, act.dataset.key, r[act.dataset.key] === 'SI' ? 'NO' : 'SI'); }
    else if (a === 'toggleSel') { const r = findRow(tab, id); inlineSet(tab, id, act.dataset.key, r[act.dataset.key] === 'Autorizado' ? 'Autorizar' : 'Autorizado'); }
  });
  body.addEventListener('change', (e) => {
    if (e.target.classList.contains('inline-select')) {
      const tr = e.target.closest('tr[data-id]');
      inlineSet(curTab(), tr.dataset.id, e.target.dataset.key, e.target.value);
    }
  });
  body.addEventListener('dblclick', (e) => {
    if (e.target.closest('input,select,[data-act]')) return;
    const tr = e.target.closest('tr[data-id]'); if (tr) openRowModal(curTab(), tr.dataset.id);
  });
}

async function deleteRows(tab, ids) {
  const t = TABS[tab];
  if (ids.length === 1) {
    if (!await confirmBox(`¿Eliminar este ${t.singular}? No se puede deshacer.`, 'Eliminar')) return;
  } else {
    if (!await confirmBox(`¿Eliminar ${ids.length} ${t.unit}? No se puede deshacer.`, 'Continuar')) return;
    if (!await typedConfirm(`Se eliminarán ${ids.length} ${t.unit} de forma definitiva.`)) return;
  }
  const set = new Set(ids);
  App.db.tables[tab] = rowsOf(tab).filter(r => !set.has(r.id));
  ids.forEach(i => App.ui.sel[tab].delete(i));
  persist(); renderAll();
  toast(`${ids.length} ${ids.length > 1 ? t.unit : t.singular} eliminad${ids.length > 1 ? 'os' : 'o'}`);
}

function duplicateRow(tab, id) {
  const src = findRow(tab, id); if (!src) return;
  const d = clone(src); delete d.id;
  const fresh = TABS[tab].newRow(rowsOf(tab));
  if (d.referencia !== undefined) d.referencia = fresh.referencia;
  ['gestion', 'solicitud', 'ingreso', 'autorizo'].forEach(k => { if (k in fresh) d[k] = fresh[k]; });
  if (tab === 'accesos') { d.enviada = 'NO'; d.gestion = ''; d.estado = fresh.estado; }
  openRowModal(tab, null, d);
}

// ============================ Formulario de fila ============================
function smartParse(raw, kind) {
  raw = String(raw || '').trim();
  if (!raw) return '';
  let r = L.parseDT(raw);
  if (!r) {
    const m = /^(\d{2})(\d{2})(\d{4})(?:\s?(\d{2})(\d{2}))?$/.exec(raw);
    if (m) r = L.parseDT(`${m[1]}-${m[2]}-${m[3]}${m[4] ? ` ${m[4]}:${m[5]}` : ''}`);
  }
  if (!r) return null;
  return kind === 'date' ? r.slice(0, 10) : r;
}
function ensureCustomDefaults(tab, row) {
  (App.db.customFields[tab] || []).forEach(cf => {
    if (row[cf.key] == null) row[cf.key] = cf.type === 'yn' ? 'NO' : (cf.type === 'int' ? 0 : '');
  });
}

function openRowModal(tab, id, preset) {
  const t = TABS[tab], rows = rowsOf(tab);
  const orig = id ? findRow(tab, id) : null;
  const draft = orig ? clone(orig) : (preset ? Object.assign(t.newRow(rows), preset) : t.newRow(rows));
  ensureCustomDefaults(tab, draft);
  const touched = { autorizo: orig ? orig.autorizo !== TabHelpers.autorizoText(orig.solicitud) : !!(preset && preset.autorizo && false) };
  const invalid = new Set(), raw = {};
  const fields = allFields(tab).filter(f => f.type !== 'computed');

  const fieldHtml = (f) => {
    const k = esc(f.key), full = (f.type === 'textarea') ? ' full' : '';
    let input;
    if (f.type === 'textarea') input = `<textarea data-key="${k}" rows="2" style="margin-top:0"></textarea>`;
    else if (f.type === 'yn') input = `<select data-key="${k}"><option>NO</option><option>SI</option></select>`;
    else if (f.type === 'select') input = `<select data-key="${k}"></select>`;
    else if (f.type === 'date' || f.type === 'datetime') {
      input = `<div class="input-with-btn"><input type="text" data-key="${k}" data-kind="${f.type}" autocomplete="off" placeholder="${f.type === 'date' ? 'dd-mm-aaaa' : 'dd-mm-aaaa hh:mm'}">
        <button type="button" class="mini-btn" data-pick="${k}" title="Calendario">📅</button>
        <button type="button" class="mini-btn" data-now="${k}">${f.type === 'date' ? 'Hoy' : 'Ahora'}</button></div>`;
    } else if (f.auto) input = `<input type="text" data-key="${k}" readonly>`;
    else if (f.type === 'int') input = `<input type="text" inputmode="numeric" data-key="${k}" autocomplete="off">`;
    else input = `<input type="text" data-key="${k}" autocomplete="off">`;
    const hint = f.auto ? '<span class="hint">Se registra automáticamente al guardar.</span>'
      : (f.type === 'int' ? '<span class="hint">Número entero, sin separadores.</span>' : '');
    return `<div class="field-group${full}${f.auto ? ' readonly' : ''}" data-wrap="${k}"><label>${esc(f.label)}</label>${input}${hint}<span class="err"></span></div>`;
  };

  const m = openModal({
    title: orig ? `Editar ${t.singular}` : (tab === 'accesos' ? 'Nueva solicitud' : 'Nuevo registro'),
    cls: 'modal-large',
    body: `<div class="device-form-grid">${fields.map(fieldHtml).join('')}<div class="calc-box" id="calcBox"></div></div>`,
    footer: `<div>${orig ? `<button class="btn btn-danger btn-small" data-del>🗑 Eliminar</button> ${tab !== 'diff' ? '<button class="btn btn-secondary btn-small" data-dup>⧉ Duplicar</button>' : ''}` : ''}</div>
             <div class="modal-actions"><button class="btn btn-ghost" data-cancel>Cancelar</button><button class="btn btn-primary" data-save>Guardar</button></div>`
  });

  const get = (k) => $(`[data-key="${k}"]`, m.el);
  function sync() {
    fields.forEach(f => {
      const el = get(f.key), wrap = $(`[data-wrap="${f.key}"]`, m.el);
      if (!el) return;
      if (f.visible) wrap.classList.toggle('hidden', !f.visible(draft));
      const focused = document.activeElement === el;
      if (f.type === 'select') {
        let opts = f.optionsFn();
        const cur = draft[f.key] || '';
        if (cur && !opts.includes(cur)) opts = opts.concat([cur]);
        const sig = opts.join('\u0001') + '|' + cur;
        if (el.dataset.sig !== sig) {
          el.innerHTML = '<option value=""></option>' + opts.map(o => `<option ${o === cur ? 'selected' : ''}>${esc(o)}</option>`).join('');
          el.value = cur; el.dataset.sig = sig;
        }
      } else if (f.type === 'yn') el.value = draft[f.key] === 'SI' ? 'SI' : 'NO';
      else if (!focused) {
        if (f.type === 'date') el.value = invalid.has(f.key) ? raw[f.key] : L.fmtD(draft[f.key]);
        else if (f.type === 'datetime') el.value = invalid.has(f.key) ? raw[f.key] : L.fmtDT(draft[f.key]);
        else if (f.auto) el.value = draft[f.key] ? L.fmtDT(draft[f.key]) : '(al guardar)';
        else el.value = draft[f.key] == null ? '' : draft[f.key];
      }
      if (!focused) el.classList.toggle('invalid', invalid.has(f.key));
    });
    $('#calcBox', m.el).innerHTML = t.preview ? t.preview(draft) : '';
  }
  function handle(e, final) {
    const el = e.target.closest('[data-key]'); if (!el) return;
    const k = el.dataset.key, f = fields.find(x => x.key === k); if (!f) return;
    const prev = draft[k];
    let v = el.value;
    if (f.type === 'date' || f.type === 'datetime') {
      raw[k] = v;
      const p = smartParse(v, f.type);
      if (p === null) { invalid.add(k); v = ''; } else { invalid.delete(k); v = p; }
    } else if (f.type === 'int') {
      const clean = v.replace(/\D/g, '');
      if (clean !== v) { el.value = clean; }
      v = clean === '' ? 0 : parseInt(clean, 10);
    }
    draft[k] = v;
    if (t.onChange) t.onChange(draft, k, { prev, touched });
    if (final && el.dataset.kind) { /* normaliza el texto al salir */ el.blur && 0; }
    sync();
  }
  m.el.addEventListener('input', (e) => handle(e, false));
  m.el.addEventListener('change', (e) => { handle(e, true); if (e.target.dataset && e.target.dataset.kind) { const k = e.target.dataset.key; if (!invalid.has(k)) e.target.value = e.target.dataset.kind === 'date' ? L.fmtD(draft[k]) : L.fmtDT(draft[k]); e.target.classList.toggle('invalid', invalid.has(k)); } });
  m.el.addEventListener('click', (e) => {
    const now = e.target.closest('[data-now]');
    if (now) {
      const k = now.dataset.now, f = fields.find(x => x.key === k);
      const el = get(k); el.value = f.type === 'date' ? L.fmtD(L.todayISO()) : L.fmtDT(L.nowISO());
      handle({ target: el }, true); return;
    }
    const pick = e.target.closest('[data-pick]');
    if (pick) {
      const k = pick.dataset.pick, f = fields.find(x => x.key === k);
      const tmp = document.createElement('input');
      tmp.type = f.type === 'date' ? 'date' : 'datetime-local';
      tmp.style.cssText = 'position:absolute;opacity:0;pointer-events:none;width:1px;height:1px';
      pick.parentNode.appendChild(tmp);
      if (draft[k]) tmp.value = f.type === 'date' ? draft[k].slice(0, 10) : draft[k].slice(0, 16);
      tmp.addEventListener('change', () => {
        if (tmp.value) { const el = get(k); el.value = f.type === 'date' ? L.fmtD(tmp.value) : L.fmtDT(tmp.value); handle({ target: el }, true); }
        tmp.remove();
      });
      tmp.addEventListener('blur', () => setTimeout(() => tmp.remove(), 300));
      try { tmp.showPicker(); } catch (x) { tmp.focus(); }
    }
  });

  async function save() {
    $$('.err', m.el).forEach(x => { x.textContent = ''; });
    $$('.invalid', m.el).forEach(x => x.classList.remove('invalid'));
    const errs = [];
    invalid.forEach(k => errs.push([k, 'Formato de fecha inválido (dd-mm-aaaa' + (fields.find(f => f.key === k).type === 'datetime' ? ' hh:mm' : '') + ').']));
    if (!errs.length) t.validate(draft, rows, orig && orig.id, invalid).forEach(e => errs.push(e));
    if (errs.length) {
      errs.forEach(([k, msg]) => {
        const w = $(`[data-wrap="${k}"] .err`, m.el); if (w) w.textContent = msg;
        const el = get(k); if (el) el.classList.add('invalid');
      });
      toast(errs[0][1], 'error', 4500);
      const first = get(errs[0][0]); if (first) first.focus();
      return;
    }
    if (t.softWarn) { const w = t.softWarn(draft, rows, orig && orig.id); if (w && !await confirmBox(w, 'Guardar', false)) return; }
    if (t.beforeSave) t.beforeSave(draft);
    (App.db.customFields[tab] || []).forEach(cf => { if (cf.type === 'int') draft[cf.key] = L.toInt(draft[cf.key]); });
    if (orig) Object.assign(orig, draft);
    else { draft.id = uid(); rows.unshift(draft); }
    persist(); m.close(); renderAll();
    toast(orig ? 'Cambios guardados' : (tab === 'accesos' ? 'Solicitud creada' : 'Registro creado'));
  }
  $('[data-save]', m.el).onclick = save;
  $('[data-cancel]', m.el).onclick = () => m.close();
  const del = $('[data-del]', m.el); if (del) del.onclick = async () => { await deleteRows(tab, [orig.id]); if (!findRow(tab, orig.id)) m.close(); };
  const dup = $('[data-dup]', m.el); if (dup) dup.onclick = () => { m.close(); duplicateRow(tab, orig.id); };
  m.el.addEventListener('keydown', (e) => { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) save(); });
  sync();
  const first = m.el.querySelector('input:not([readonly]),select'); if (first) first.focus();
}

// ============================ Selector de columnas reutilizable ============================
function columnChecklist(fields, checkedKeys, withArrows) {
  return `<div class="config-field-list" id="ckList">${fields.map((f, i) => `
    <div class="config-field-row" data-key="${esc(f.key)}">
      <label><input type="checkbox" ${checkedKeys.includes(f.key) ? 'checked' : ''}> ${esc(f.label)}</label>
      ${withArrows ? `<div class="cf-arrows"><button data-up ${i === 0 ? 'disabled' : ''}>↑</button><button data-down ${i === fields.length - 1 ? 'disabled' : ''}>↓</button></div>` : ''}
    </div>`).join('')}</div>`;
}
function bindChecklist(root, withArrows) {
  const list = $('#ckList', root);
  list.addEventListener('click', (e) => {
    if (!withArrows) return;
    const row = e.target.closest('.config-field-row'); if (!row) return;
    if (e.target.hasAttribute('data-up') && row.previousElementSibling) row.parentNode.insertBefore(row, row.previousElementSibling);
    else if (e.target.hasAttribute('data-down') && row.nextElementSibling) row.parentNode.insertBefore(row.nextElementSibling, row);
    else return;
    $$('.config-field-row', list).forEach((r, i, a) => {
      $('[data-up]', r).disabled = i === 0; $('[data-down]', r).disabled = i === a.length - 1;
    });
  });
  return () => $$('.config-field-row', list).map(r => ({ key: r.dataset.key, on: $('input', r).checked }));
}

function openColumnConfig() {
  const tab = curTab();
  const all = colsFor(tab, true);
  const hidden = new Set((App.db.settings.columns[tab] || {}).hidden || []);
  const m = openModal({
    title: `Columnas — ${esc(TABS[tab].title)}`, cls: 'modal-small config-modal',
    body: `<p class="muted" style="margin-top:0">Marca las columnas visibles y ordénalas con las flechas.</p>${columnChecklist(all, all.filter(f => !hidden.has(f.key)).map(f => f.key), true)}`,
    footer: `<button class="btn btn-ghost" data-reset>Restablecer</button><button class="btn btn-primary" data-apply>Aplicar</button>`
  });
  const read = bindChecklist(m.el, true);
  $('[data-apply]', m.el).onclick = () => {
    const r = read();
    App.db.settings.columns[tab] = { order: r.map(x => x.key), hidden: r.filter(x => !x.on).map(x => x.key) };
    persist(); m.close(); renderAll();
  };
  $('[data-reset]', m.el).onclick = () => { delete App.db.settings.columns[tab]; persist(); m.close(); renderAll(); };
}

// ============================ Copiar a correo ============================
const MAIL_DEFAULTS = {
  accesos: ['referencia', 'documento', 'nombreUsuario', 'acceso', 'solicitud', 'estado', 'observacion'],
  diff: ['fecha', 'total', 'sinAcceso', 'ingresos', 'pIng', 'egresos', 'pEgr', 'accion', 'autorizacion'],
  tui: ['referencia', 'ingreso', 'solicitante', 'documento', 'usuario', 'tuiLeida', 'tuiSistema']
};
function savedMailCols(tab) {
  const saved = App.db.settings.emailCols[tab];
  if (!saved) return null;
  const keys = new Set(allFields(tab).map(f => f.key));
  const ok = saved.filter(k => keys.has(k));
  return ok.length ? ok : null;
}
function openMailCols(thenCopy) {
  const tab = curTab();
  const fields = colsFor(tab, true);
  const checked = savedMailCols(tab) || MAIL_DEFAULTS[tab].filter(k => fields.some(f => f.key === k));
  const m = openModal({
    title: '✉ Columnas a copiar en el correo', cls: 'modal-small config-modal',
    body: `<p class="muted" style="margin-top:0">Esta selección se recuerda hasta que la vuelvas a editar. Al pegar en el correo irán los encabezados y las filas seleccionadas.</p>
      <div class="form-row" style="margin-bottom:8px"><button class="btn btn-ghost btn-small" data-all>Marcar todas</button><button class="btn btn-ghost btn-small" data-none>Desmarcar todas</button></div>
      ${columnChecklist(fields, checked, false)}`,
    footer: `<span></span><div class="modal-actions"><button class="btn btn-ghost" data-cancel>Cancelar</button><button class="btn btn-primary" data-ok>${thenCopy ? 'Guardar y copiar' : 'Guardar selección'}</button></div>`
  });
  const read = bindChecklist(m.el, false);
  $('[data-all]', m.el).onclick = () => $$('#ckList input', m.el).forEach(i => { i.checked = true; });
  $('[data-none]', m.el).onclick = () => $$('#ckList input', m.el).forEach(i => { i.checked = false; });
  $('[data-cancel]', m.el).onclick = () => m.close();
  $('[data-ok]', m.el).onclick = () => {
    const keys = read().filter(x => x.on).map(x => x.key);
    if (!keys.length) { toast('Elige al menos una columna', 'error'); return; }
    App.db.settings.emailCols[tab] = keys; persist(); m.close();
    toast(`Columnas del correo guardadas (${keys.length})`);
    if (thenCopy) copyToMail();
  };
}
function mailTable(tab, cols, rows) {
  const th = 'border:1px solid #7f8c99;background:#0a3d62;color:#ffffff;padding:4px 8px;text-align:left;font-weight:bold;white-space:nowrap';
  const html = `<table border="1" cellspacing="0" cellpadding="4" style="border-collapse:collapse;font-family:Calibri,Arial,sans-serif;font-size:11pt"><thead><tr>` +
    cols.map(f => `<th style="${th}">${esc(f.label)}</th>`).join('') + '</tr></thead><tbody>' +
    rows.map(r => '<tr>' + cols.map(f => {
      const c = cellColor(f, r);
      const st = 'border:1px solid #7f8c99;padding:4px 8px;white-space:nowrap' + (c ? `;background:${c.bg};color:${c.color};font-weight:bold` : '');
      return `<td style="${st}">${esc(cellText(f, r))}</td>`;
    }).join('') + '</tr>').join('') + '</tbody></table>';
  const text = [cols.map(f => f.label).join('\t')].concat(rows.map(r => cols.map(f => cellText(f, r).replace(/[\t\r\n]+/g, ' ')).join('\t'))).join('\r\n');
  return { html, text };
}
async function copyToMail() {
  const tab = curTab(), sel = App.ui.sel[tab];
  if (!sel.size) { toast('Selecciona al menos una fila', 'error'); return; }
  const keys = savedMailCols(tab);
  if (!keys) { openMailCols(true); return; }
  const order = colsFor(tab, true);
  const cols = order.filter(f => keys.includes(f.key));
  const rows = sortedRows(tab, rowsOf(tab)).filter(r => sel.has(r.id));
  const { html, text } = mailTable(tab, cols, rows);
  await window.accesosApi.copyHtml(html, text);
  toast(`Tabla copiada: ${rows.length} fila${rows.length > 1 ? 's' : ''} × ${cols.length} columnas. Pégala en el correo con Ctrl+V.`, 'success', 5000);
}

// ============================ Exportar ============================
function matrixFor(tab, cols, rows, forXlsx) {
  const headers = cols.map(f => f.label);
  const data = rows.map(r => cols.map(f => (forXlsx && f.type === 'int' ? L.toInt(r[f.key]) : cellText(f, r))));
  const colors = rows.map(r => cols.map(f => cellColor(f, r)));
  return { headers, rows: data, colors };
}
function fileStamp(d = new Date()) {
  const p = L.pad;
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
}
function openExport() {
  const tab = curTab(), t = TABS[tab];
  const visible = new Set(colsFor(tab).map(f => f.key));
  const fields = colsFor(tab, true);
  const nSel = App.ui.sel[tab].size, nFil = filteredRows(tab).length, nAll = rowsOf(tab).length;
  const m = openModal({
    title: `⬇ Exportar — ${esc(t.title)}`, cls: 'modal-small config-modal',
    body: `<b style="font-size:12px">Formato</b>
      <div class="radio-row"><label><input type="radio" name="xf" value="xlsx" checked> Excel (.xlsx)</label><label><input type="radio" name="xf" value="csv"> CSV (.csv)</label></div>
      <b style="font-size:12px">Filas</b>
      <div class="radio-row" style="flex-direction:column;gap:4px">
        <label><input type="radio" name="xs" value="all" ${nSel ? '' : 'checked'}> Todas (${nAll})</label>
        <label><input type="radio" name="xs" value="filtered"> Las que se ven con los filtros/búsqueda (${nFil})</label>
        <label><input type="radio" name="xs" value="selected" ${nSel ? 'checked' : 'disabled'}> Solo las seleccionadas (${nSel})</label></div>
      <b style="font-size:12px">Columnas</b>
      <div class="form-row" style="margin:6px 0"><button class="btn btn-ghost btn-small" data-all>Todas</button><button class="btn btn-ghost btn-small" data-none>Ninguna</button></div>
      ${columnChecklist(fields, fields.filter(f => visible.has(f.key)).map(f => f.key), false)}`,
    footer: `<span></span><div class="modal-actions"><button class="btn btn-ghost" data-cancel>Cancelar</button><button class="btn btn-primary" data-ok>Exportar</button></div>`
  });
  const read = bindChecklist(m.el, false);
  $('[data-all]', m.el).onclick = () => $$('#ckList input', m.el).forEach(i => { i.checked = true; });
  $('[data-none]', m.el).onclick = () => $$('#ckList input', m.el).forEach(i => { i.checked = false; });
  $('[data-cancel]', m.el).onclick = () => m.close();
  $('[data-ok]', m.el).onclick = async () => {
    const keys = read().filter(x => x.on).map(x => x.key);
    if (!keys.length) { toast('Elige al menos una columna', 'error'); return; }
    const fmt = $('input[name=xf]:checked', m.el).value, scope = $('input[name=xs]:checked', m.el).value;
    let rows = scope === 'filtered' ? filteredRows(tab) : sortedRows(tab, rowsOf(tab));
    if (scope === 'selected') rows = rows.filter(r => App.ui.sel[tab].has(r.id));
    const cols = fields.filter(f => keys.includes(f.key));
    const mx = matrixFor(tab, cols, rows, fmt === 'xlsx');
    const res = await window.accesosApi.exportFile({
      format: fmt, defaultName: `${t.title.replace(/\s+/g, '-')}-${fileStamp()}.${fmt}`,
      sheets: [{ name: t.title, headers: mx.headers, rows: mx.rows, colors: mx.colors }]
    });
    if (res.ok) { m.close(); toast(`Exportado: ${res.path}`, 'success', 6000); }
    else if (res.error) toast('Error al exportar: ' + res.error, 'error', 6000);
  };
}

// ============================ Importar ============================
function importableFields(tab) {
  return allFields(tab).filter(f => f.type !== 'computed' && !f.noImport);
}
function convertValue(f, raw) {
  const s = String(raw == null ? '' : raw).trim();
  switch (f.type) {
    case 'ref': { if (!s) return { v: '' }; const r = L.normRef(s); return r ? { v: r } : { v: s, warn: true }; }
    case 'yn': return { v: L.parseYN(s) };
    case 'date': { if (!s) return { v: '' }; const p = L.parseD(s); return p ? { v: p } : { v: '', warn: true }; }
    case 'datetime': { if (!s) return { v: '' }; const p = L.parseDT(s); return p ? { v: p } : { v: '', warn: true }; }
    case 'int': return { v: L.toInt(s) };
    default: return { v: s };
  }
}
function planImport(tab, matrix, withCustom) {
  const t = TABS[tab];
  const headers = matrix[0].map(h => String(h || '').trim());
  const fields = importableFields(tab);
  const map = {};
  const newCustom = [];
  const unmapped = [];
  headers.forEach((h, i) => {
    if (!h) return;
    const n = L.normHeader(h);
    const f = fields.find(x => L.normHeader(x.label) === n) || fields.find(x => x.key.toLowerCase() === n || (x.aliases || []).includes(n));
    if (f && !Object.values(map).includes(f)) map[i] = f;
    else if (allFields(tab).some(x => x.type === 'computed' && (L.normHeader(x.label) === n))) { /* calculado: se ignora */ }
    else unmapped.push({ i, h });
  });
  if (withCustom) unmapped.forEach(u => {
    const cf = { key: 'cf_' + L.normHeader(u.h).slice(0, 20) + '_' + Math.random().toString(36).slice(2, 5), label: u.h, type: 'text' };
    newCustom.push(cf); map[u.i] = { key: cf.key, label: cf.label, type: 'text' };
  });
  const objs = [], errors = [];
  let warnings = 0;
  matrix.slice(1).forEach((cells, ri) => {
    const o = {};
    Object.keys(map).forEach(i => {
      const r = convertValue(map[i], cells[i]);
      if (r.warn) warnings++;
      o[map[i].key] = r.v;
    });
    if (tab === 'diff') {
      if (!o.fecha) { errors.push(`Fila ${ri + 2}: sin FECHA válida`); return; }
    }
    objs.push({ o, line: ri + 2 });
  });
  const keyField = t.matchKey;
  const working = new Map();
  rowsOf(tab).forEach(r => working.set(keyField === 'referencia' ? L.normRef(r.referencia) : r.fecha, r));
  const creates = [], updates = [];
  const seenNew = new Map();
  objs.forEach(({ o }) => {
    const k = keyField === 'referencia' ? (o.referencia && L.normRef(o.referencia)) : o.fecha;
    if (k && working.has(k)) {
      const patch = {};
      Object.keys(o).forEach(f => { if (o[f] !== '' && o[f] != null) patch[f] = o[f]; });
      updates.push({ row: working.get(k), patch });
    } else if (k && seenNew.has(k)) {
      Object.assign(creates[seenNew.get(k)], o);   // duplicado dentro del archivo: gana el último
    } else {
      if (k) seenNew.set(k, creates.length);
      creates.push(o);
    }
  });
  if (!matrix.length || headers.every(h => !h) || !Object.keys(map).length) errors.unshift('No se reconoció ninguna columna. Revisa que la primera fila tenga los encabezados.');
  return { creates, updates, errors, warnings, unmapped, newCustom, mapped: Object.keys(map).length, withCustom };
}
function applyImport(tab, plan) {
  const t = TABS[tab], rows = rowsOf(tab);
  plan.newCustom.forEach(cf => App.db.customFields[tab].push(cf));
  plan.updates.forEach(u => Object.assign(u.row, u.patch));
  const newVals = { accesos: new Set(), estados: new Set() };
  const created = [];
  plan.creates.forEach(o => {
    const base = t.newRow(rows.concat(created));
    ensureCustomDefaults(tab, base);
    const row = Object.assign(base, o);
    if (t.matchKey === 'referencia' && !o.referencia) {
      const y = parseInt(((row.solicitud || row.ingreso || '').slice(0, 4)), 10) || new Date().getFullYear();
      row.referencia = L.nextRef(rows.concat(created), y);
    }
    if (tab === 'diff') ['total', 'sinAcceso', 'ingresos'].forEach(k => { row[k] = L.toInt(row[k]); });
    if (!('autorizo' in o) && tab === 'accesos') row.autorizo = TabHelpers.autorizoText(row.solicitud);
    row.id = uid();
    created.push(row);
    if (tab === 'accesos') { if (row.acceso) newVals.accesos.add(row.acceso); if (row.estado) newVals.estados.add(row.estado); }
  });
  plan.updates.forEach(u => { if (tab === 'accesos') { if (u.row.acceso) newVals.accesos.add(u.row.acceso); if (u.row.estado) newVals.estados.add(u.row.estado); } });
  App.db.tables[tab] = created.reverse().concat(rows);
  let added = 0;
  newVals.accesos.forEach(v => { if (!App.db.lists.accesos.some(o => o.value === v)) { App.db.lists.accesos.push({ value: v }); added++; } });
  newVals.estados.forEach(v => { if (!App.db.lists.estados.some(o => o.value === v)) { App.db.lists.estados.push({ value: v, bg: '#e6edf3', color: '#6b7684' }); added++; } });
  persist(); renderAll();
  return added;
}
async function doImport() {
  const tab = curTab();
  const res = await window.accesosApi.pickImport();
  if (!res) return;
  if (!res.ok) { toast('No se pudo leer el archivo: ' + res.error, 'error', 6000); return; }
  if (!res.matrix.length) { toast('El archivo está vacío', 'error'); return; }
  const m = openModal({
    title: `⬆ Importar — ${esc(TABS[tab].title)}`, cls: 'modal-small config-modal',
    body: `<p class="muted" style="margin-top:0">${esc(res.file)}</p>
      <div class="import-summary"><div class="import-stat import-stat-create"><span id="iNew">0</span><label>Nuevos</label></div>
        <div class="import-stat import-stat-update"><span id="iUpd">0</span><label>Actualizados</label></div>
        <div class="import-stat import-stat-error"><span id="iErr">0</span><label>Con error</label></div></div>
      <p class="muted">Se emparejan por <b>${tab === 'diff' ? 'FECHA' : 'REFERENCIA'}</b>: si existe se actualiza (solo con los datos no vacíos del archivo); si no, se crea. ${tab === 'diff' ? '' : 'Las filas sin referencia reciben la siguiente correlativa.'} Las columnas calculadas se ignoran porque se recalculan.</p>
      <div id="iInfo" class="muted"></div>
      <label class="checkbox-label" id="iCustomWrap" style="margin-top:8px"><input type="checkbox" id="iCustom"> Crear campos nuevos para las columnas no reconocidas</label>
      <div class="import-errors-list" id="iErrs"></div>`,
    footer: `<span></span><div class="modal-actions"><button class="btn btn-ghost" data-cancel>Cancelar</button><button class="btn btn-primary" data-ok>Confirmar importación</button></div>`
  });
  let plan;
  const refresh = () => {
    plan = planImport(tab, res.matrix, $('#iCustom', m.el).checked);
    $('#iNew', m.el).textContent = plan.creates.length;
    $('#iUpd', m.el).textContent = plan.updates.length;
    $('#iErr', m.el).textContent = plan.errors.length;
    $('#iInfo', m.el).innerHTML = `Columnas reconocidas: <b>${plan.mapped}</b>` +
      (plan.unmapped.length && !plan.withCustom ? `<br>No reconocidas (se omiten): ${plan.unmapped.map(u => esc(u.h)).join(', ')}` : '') +
      (plan.warnings ? `<br>Fechas con formato no válido (quedan vacías): ${plan.warnings}` : '');
    $('#iCustomWrap', m.el).classList.toggle('hidden', !plan.unmapped.length);
    $('#iErrs', m.el).innerHTML = plan.errors.slice(0, 50).map(e => `<div>${esc(e)}</div>`).join('');
    $('[data-ok]', m.el).disabled = !plan.creates.length && !plan.updates.length;
  };
  $('#iCustom', m.el).onchange = refresh;
  refresh();
  $('[data-cancel]', m.el).onclick = () => m.close();
  $('[data-ok]', m.el).onclick = () => {
    const added = applyImport(tab, plan);
    m.close();
    toast(`Importación lista: ${plan.creates.length} nuevos, ${plan.updates.length} actualizados${added ? `, ${added} valores agregados a Listas` : ''}`, 'success', 6000);
  };
}

// ============================ Vista: Listas ============================
function renameCascade(field, oldV, newV) {
  rowsOf('accesos').forEach(r => { if (r[field] === oldV) r[field] = newV; });
}
function usageCount(field, v) { return rowsOf('accesos').filter(r => r[field] === v).length; }
function renderListas() {
  const L1 = App.db.lists.accesos, L2 = App.db.lists.estados;
  const arrows = (i, n) => `<div class="arrow-btns"><button data-up ${i === 0 ? 'disabled' : ''}>↑</button><button data-down ${i === n - 1 ? 'disabled' : ''}>↓</button></div>`;
  $('#listAccesos').innerHTML = L1.length ? L1.map((o, i) => `<div class="opt-row" data-i="${i}">
      <input class="opt-input" value="${esc(o.value)}">${arrows(i, L1.length)}<button class="icon-btn" data-del title="Eliminar">🗑</button></div>`).join('') : '<p class="muted">Sin elementos.</p>';
  $('#listEstados').innerHTML = L2.length ? L2.map((o, i) => `<div class="opt-row" data-i="${i}">
      <span class="pill opt-preview" style="background:${o.bg};color:${o.color}">${esc(o.value)}</span>
      <input class="opt-input" value="${esc(o.value)}">
      <label class="color-pick-label">Fondo <input type="color" data-bg value="${o.bg}"></label>
      <label class="color-pick-label">Texto <input type="color" data-fg value="${o.color}"></label>
      ${arrows(i, L2.length)}<button class="icon-btn" data-del title="Eliminar">🗑</button></div>`).join('') : '<p class="muted">Sin elementos.</p>';
}
function bindListas() {
  const wire = (boxId, name, field) => {
    const box = $(boxId);
    const arr = () => App.db.lists[name];
    box.addEventListener('change', (e) => {
      const row = e.target.closest('.opt-row'); if (!row) return;
      const i = +row.dataset.i, o = arr()[i];
      if (e.target.classList.contains('opt-input')) {
        const nv = e.target.value.trim();
        if (!nv) { e.target.value = o.value; return; }
        if (arr().some((x, j) => j !== i && x.value === nv)) { toast('Ese valor ya existe en la lista', 'error'); e.target.value = o.value; return; }
        renameCascade(field, o.value, nv); o.value = nv;
      } else if (e.target.hasAttribute('data-bg')) o.bg = e.target.value;
      else if (e.target.hasAttribute('data-fg')) o.color = e.target.value;
      persist(); renderListas();
    });
    box.addEventListener('click', async (e) => {
      const row = e.target.closest('.opt-row'); if (!row) return;
      const i = +row.dataset.i, a = arr();
      if (e.target.hasAttribute('data-up') && i > 0) { [a[i - 1], a[i]] = [a[i], a[i - 1]]; }
      else if (e.target.hasAttribute('data-down') && i < a.length - 1) { [a[i + 1], a[i]] = [a[i], a[i + 1]]; }
      else if (e.target.hasAttribute('data-del')) {
        const n = usageCount(field, a[i].value);
        if (!await confirmBox(`¿Eliminar “${a[i].value}” de la lista?` + (n ? `\nLo usan ${n} solicitud(es); conservarán el texto pero sin color/lista.` : ''), 'Eliminar')) return;
        a.splice(i, 1);
      } else return;
      persist(); renderListas();
    });
  };
  wire('#listAccesos', 'accesos', 'acceso');
  wire('#listEstados', 'estados', 'estado');
  const add = (inputId, name, extra) => {
    const inp = $(inputId), v = inp.value.trim();
    if (!v) return;
    if (App.db.lists[name].some(o => o.value === v)) { toast('Ese valor ya existe en la lista', 'error'); return; }
    App.db.lists[name].push(Object.assign({ value: v }, extra || {}));
    inp.value = ''; persist(); renderListas();
  };
  $('#btnAddAcceso').onclick = () => add('#newAcceso', 'accesos');
  $('#btnAddEstado').onclick = () => add('#newEstado', 'estados', { bg: '#e6edf3', color: '#3c4858' });
  $('#newAcceso').onkeydown = (e) => { if (e.key === 'Enter') $('#btnAddAcceso').click(); };
  $('#newEstado').onkeydown = (e) => { if (e.key === 'Enter') $('#btnAddEstado').click(); };
}

// ============================ Vista: Campos ============================
const TYPE_NAMES = { text: 'Texto', textarea: 'Texto largo', int: 'Número entero', date: 'Fecha', datetime: 'Fecha y hora', yn: 'SI / NO', select: 'Lista', ref: 'Referencia', computed: 'Calculado' };
let fieldsTab = 'accesos';
function renderCampos() {
  const sel = $('#fieldsTab');
  if (!sel.options.length) sel.innerHTML = TAB_ORDER.map(id => `<option value="${id}">${TABS[id].title}</option>`).join('');
  sel.value = fieldsTab;
  $('#fieldsList').innerHTML = allFields(fieldsTab).map(f => `<div class="field-row" data-key="${esc(f.key)}">
      <div><span class="f-name">${esc(f.label)}</span>
        <span class="f-base-tag">${f.custom ? 'personalizado' : 'base'}</span>
        <span class="f-meta"> · ${TYPE_NAMES[f.type] || f.type}${f.type === 'select' && f.custom ? ': ' + esc((f.optionsFn() || []).join(', ')) : ''}</span></div>
      <div class="f-actions"><button class="icon-btn" data-ren title="Renombrar">✏️</button>
        ${f.custom && f.type === 'select' ? '<button class="icon-btn" data-opts title="Editar opciones">☰</button>' : ''}
        ${f.custom ? '<button class="icon-btn" data-del title="Eliminar">🗑</button>' : ''}</div></div>`).join('');
}
function bindCampos() {
  $('#fieldsTab').onchange = (e) => { fieldsTab = e.target.value; renderCampos(); };
  $('#newFieldType').onchange = (e) => { $('#newFieldOptions').style.display = e.target.value === 'select' ? 'block' : 'none'; };
  $('#btnAddField').onclick = () => {
    const label = $('#newFieldLabel').value.trim(), type = $('#newFieldType').value;
    if (!label) { toast('Escribe el nombre del campo', 'error'); return; }
    if (allFields(fieldsTab).some(f => L.normHeader(f.label) === L.normHeader(label))) { toast('Ya existe un campo con ese nombre', 'error'); return; }
    const cf = { key: 'cf_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 4), label, type };
    if (type === 'select') {
      cf.options = $('#newFieldOptions').value.split(',').map(s => s.trim()).filter(Boolean);
      if (!cf.options.length) { toast('Indica las opciones separadas por coma', 'error'); return; }
    }
    App.db.customFields[fieldsTab].push(cf);
    $('#newFieldLabel').value = ''; $('#newFieldOptions').value = '';
    persist(); renderCampos(); toast('Campo agregado');
  };
  $('#fieldsList').addEventListener('click', async (e) => {
    const row = e.target.closest('.field-row'); if (!row) return;
    const key = row.dataset.key, f = allFields(fieldsTab).find(x => x.key === key);
    if (e.target.closest('[data-ren]')) {
      const nv = await inputBox('Renombrar campo', 'Nuevo nombre de la columna:', f.label);
      if (!nv) return;
      if (f.custom) App.db.customFields[fieldsTab].find(c => c.key === key).label = nv;
      else { App.db.settings.labels[fieldsTab] = App.db.settings.labels[fieldsTab] || {}; App.db.settings.labels[fieldsTab][key] = nv; }
      persist(); renderCampos();
    } else if (e.target.closest('[data-opts]')) {
      const cf = App.db.customFields[fieldsTab].find(c => c.key === key);
      const nv = await inputBox('Opciones de la lista', 'Opciones separadas por coma:', (cf.options || []).join(', '));
      if (nv == null) return;
      cf.options = nv.split(',').map(s => s.trim()).filter(Boolean); persist(); renderCampos();
    } else if (e.target.closest('[data-del]')) {
      if (!await confirmBox(`¿Eliminar el campo “${f.label}”? Se perderán sus datos en todas las filas.`, 'Eliminar')) return;
      App.db.customFields[fieldsTab] = App.db.customFields[fieldsTab].filter(c => c.key !== key);
      rowsOf(fieldsTab).forEach(r => { delete r[key]; });
      const c = App.db.settings.columns[fieldsTab]; if (c) { c.order = (c.order || []).filter(k => k !== key); c.hidden = (c.hidden || []).filter(k => k !== key); }
      const em = App.db.settings.emailCols[fieldsTab]; if (em) App.db.settings.emailCols[fieldsTab] = em.filter(k => k !== key);
      persist(); renderCampos(); toast('Campo eliminado');
    }
  });
}

// ============================ Vista: Ajustes y respaldo ============================
function renderAjustes() {
  const s = App.db.settings;
  $('#setAutoriza').value = s.autorizaNombre; $('#setGestiono').value = s.gestionoDefault; $('#setHora').value = s.horaInicio;
  $('#backupEnabled').checked = !!s.backup.enabled; $('#backupTime').value = s.backup.time || '18:00';
  $('#dataDirPath').textContent = App.dataDir || '—';
  $('#backupStatus').textContent = s.backup.lastBackupDate ? `Último respaldo: ${L.fmtD(s.backup.lastBackupDate)}` : 'Aún no se ha generado ningún respaldo.';
}
function backupSheets() {
  return TAB_ORDER.map(tab => {
    const cols = colsFor(tab, true);
    const mx = matrixFor(tab, cols, sortedRows(tab, rowsOf(tab)), true);
    return { name: TABS[tab].title, headers: mx.headers, rows: mx.rows, colors: mx.colors };
  });
}
async function runBackup(manual) {
  const res = await window.accesosApi.writeBackup(fileStamp(), JSON.stringify(App.db), backupSheets());
  if (res.ok) {
    App.db.settings.backup.lastBackupDate = L.todayISO(); App.db.settings.backup.lastBackupFile = res.path;
    persist(); if (App.view === 'ajustes') renderAjustes();
    if (manual) toast('Respaldo generado en la carpeta Backups', 'success', 5000);
  } else toast('Error en el respaldo: ' + res.error, 'error', 6000);
}
function checkScheduledBackup() {
  try {
    const b = App.db.settings.backup;
    if (!b.enabled) return;
    const now = new Date(), [h, mi] = String(b.time || '18:00').split(':').map(Number);
    const sched = new Date(now.getFullYear(), now.getMonth(), now.getDate(), h || 0, mi || 0);
    if (b.lastBackupDate !== L.todayISO(now) && now >= sched) runBackup(false);
  } catch (e) { console.error(e); }
}
function bindAjustes() {
  $('#btnSaveSettings').onclick = () => {
    const s = App.db.settings;
    s.autorizaNombre = $('#setAutoriza').value.trim() || 'Raúl Segovia';
    s.gestionoDefault = $('#setGestiono').value.trim() || 'DASR';
    s.horaInicio = $('#setHora').value || '10:00';
    persist(); toast('Ajustes guardados');
  };
  $('#btnSaveBackup').onclick = () => {
    const b = App.db.settings.backup; b.enabled = $('#backupEnabled').checked; b.time = $('#backupTime').value || '18:00';
    persist(); toast('Configuración de respaldo guardada'); checkScheduledBackup();
  };
  $('#btnBackupNow').onclick = () => runBackup(true);
  $('#btnOpenFolder').onclick = () => window.accesosApi.openFolder('data');
  $('#btnRestore').onclick = async () => {
    const res = await window.accesosApi.pickRestore();
    if (!res) return;
    if (!res.ok || !res.db || !res.db.tables) { toast('El archivo no es un respaldo válido', 'error'); return; }
    if (!await confirmBox(`Se reemplazarán TODOS los datos actuales por los del respaldo “${res.file}”.\n¿Continuar?`, 'Restaurar')) return;
    App.db = migrate(res.db);
    TAB_ORDER.forEach(t => App.ui.sel[t].clear());
    await flushSave(); renderAll(); toast('Datos restaurados');
  };
}

// ============================ Inicio ============================
function bindGlobal() {
  $('#topNav').addEventListener('click', (e) => { const b = e.target.closest('[data-view]'); if (b) setView(b.dataset.view); });
  let qt;
  $('#searchInput').addEventListener('input', (e) => {
    clearTimeout(qt);
    qt = setTimeout(() => { App.ui.q[curTab()] = e.target.value; App.ui.limit[curTab()] = 300; renderTable(); renderSidebar(); }, 120);
  });
  $('#btnNew').onclick = () => openRowModal(curTab());
  $('#sidebar').addEventListener('click', (e) => {
    const chip = e.target.closest('.filter-chip'); if (!chip) return;
    const fl = App.ui.filters[curTab()], id = chip.dataset.flt, v = chip.dataset.val;
    if (fl[id] === v) delete fl[id]; else fl[id] = v;
    App.ui.limit[curTab()] = 300;
    renderSidebar(); renderTable();
  });
  $('#btnClearFilters').onclick = () => {
    App.ui.filters[curTab()] = {}; App.ui.q[curTab()] = ''; $('#searchInput').value = '';
    renderSidebar(); renderTable();
  };
  $('#selectAll').onchange = (e) => {
    const sel = App.ui.sel[curTab()];
    filteredRows(curTab()).forEach(r => { if (e.target.checked) sel.add(r.id); else sel.delete(r.id); });
    renderTable();
  };
  $('#btnMore').onclick = () => { App.ui.limit[curTab()] += 300; renderTable(); };
  $('#btnColumnConfig').onclick = openColumnConfig;
  $('#btnImport').onclick = doImport;
  $('#btnExport').onclick = openExport;
  $('#btnCopyMail').onclick = copyToMail;
  $('#btnMailCols').onclick = () => openMailCols(false);
  $('#btnBulkDelete').onclick = () => deleteRows(curTab(), Array.from(App.ui.sel[curTab()]));
}

async function init() {
  const r = await window.accesosApi.loadDb();
  App.dataDir = r.dataDir; App.backupDir = r.backupDir;
  App.db = migrate(r.db);
  if (!r.db) await flushSave();
  bindGlobal(); bindTable(); bindListas(); bindCampos(); bindAjustes();
  setView('accesos');
  checkScheduledBackup();
  setInterval(checkScheduledBackup, 60 * 1000);
}
init().catch(err => { document.body.insertAdjacentHTML('afterbegin', `<pre style="color:#c0392b;padding:20px">Error al iniciar: ${esc(err.stack || err)}</pre>`); });
