/* Lógica pura (sin DOM): fechas, búsqueda, cálculos de negocio. Funciona en navegador y en Node (tests). */
(function (root) {
  const pad = (n, l = 2) => String(n).padStart(l, '0');
  const MESES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
  const DIAS = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];

  // ---------- Fechas ----------
  // Se guardan como 'YYYY-MM-DDTHH:mm' (fecha-hora local) y 'YYYY-MM-DD' (solo fecha)
  function nowISO(d = new Date()) {
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
  }
  function todayISO(d = new Date()) { return nowISO(d).slice(0, 10); }
  function validYMD(y, m, d) {
    if (m < 1 || m > 12 || d < 1) return false;
    const dt = new Date(y, m - 1, d);
    return dt.getFullYear() === y && dt.getMonth() === m - 1 && dt.getDate() === d;
  }
  // 'YYYY-MM-DD[THH:mm]' -> 'dd-mm-yyyy'
  function fmtD(iso) {
    const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso || '');
    return m ? `${m[3]}-${m[2]}-${m[1]}` : '';
  }
  // 'YYYY-MM-DDTHH:mm' -> 'dd-mm-yyyy hh:mm'
  function fmtDT(iso) {
    const m = /^(\d{4})-(\d{2})-(\d{2})(?:T(\d{2}):(\d{2}))?/.exec(iso || '');
    if (!m) return '';
    return `${m[3]}-${m[2]}-${m[1]} ${m[4] || '00'}:${m[5] || '00'}`;
  }
  // Interpreta texto en varios formatos. Devuelve ISO ('YYYY-MM-DDTHH:mm') o null.
  function parseDT(str) {
    if (str == null) return null;
    const s = String(str).trim();
    if (!s) return null;
    let m = /^(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})(?:[ T,]+(\d{1,2}):(\d{2})(?::\d{2})?)?$/.exec(s);
    if (m) {
      const d = +m[1], mo = +m[2], y = +m[3], h = m[4] ? +m[4] : 0, mi = m[5] ? +m[5] : 0;
      if (!validYMD(y, mo, d) || h > 23 || mi > 59) return null;
      return `${y}-${pad(mo)}-${pad(d)}T${pad(h)}:${pad(mi)}`;
    }
    m = /^(\d{4})-(\d{1,2})-(\d{1,2})(?:[ T]+(\d{1,2}):(\d{2})(?::\d{2}(?:\.\d+)?)?Z?)?$/.exec(s);
    if (m) {
      const y = +m[1], mo = +m[2], d = +m[3], h = m[4] ? +m[4] : 0, mi = m[5] ? +m[5] : 0;
      if (!validYMD(y, mo, d) || h > 23 || mi > 59) return null;
      return `${y}-${pad(mo)}-${pad(d)}T${pad(h)}:${pad(mi)}`;
    }
    m = /(\d{1,2})\s+de\s+([A-Za-zÁÉÍÓÚáéíóú]+)\s+de\s+(\d{4})/i.exec(s);
    if (m) {
      const mo = MESES.indexOf(m[2].toLowerCase()) + 1;
      const d = +m[1], y = +m[3];
      if (!mo || !validYMD(y, mo, d)) return null;
      return `${y}-${pad(mo)}-${pad(d)}T00:00`;
    }
    return null;
  }
  function parseD(str) { const r = parseDT(str); return r ? r.slice(0, 10) : null; }
  function toDate(iso) {
    const m = /^(\d{4})-(\d{2})-(\d{2})(?:T(\d{2}):(\d{2}))?/.exec(iso || '');
    if (!m) return null;
    return new Date(+m[1], +m[2] - 1, +m[3], m[4] ? +m[4] : 0, m[5] ? +m[5] : 0);
  }
  // 'YYYY-MM-DD' -> 'Jueves, 1 de octubre de 2026'
  function fmtLong(iso) {
    const d = toDate(iso);
    if (!d) return '';
    return `${DIAS[d.getDay()]}, ${d.getDate()} de ${MESES[d.getMonth()]} de ${d.getFullYear()}`;
  }

  // ---------- Búsqueda ----------
  // Ignora mayúsculas, tildes y los separadores . - , _ /  => "16.759.565-0" == "167595650"
  function normCell(s) {
    return String(s == null ? '' : s).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[.\-,_/]/g, '');
  }
  function matchQuery(query, cells) {
    const tokens = String(query || '').trim().split(/\s+/).map(normCell).filter(Boolean);
    if (!tokens.length) return true;
    const hay = cells.map(normCell).join(' ');
    return tokens.every(t => hay.includes(t));
  }
  function normHeader(s) {
    return String(s == null ? '' : s).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]/g, '');
  }

  // ---------- Referencias yyyy-xxxx ----------
  function parseRef(ref) {
    const m = /^\s*(\d{4})\s*-\s*(\d+)\s*$/.exec(ref || '');
    return m ? { y: +m[1], n: +m[2] } : null;
  }
  function fmtRef(y, n) { return `${y}-${pad(n, 4)}`; }
  function normRef(ref) { const p = parseRef(ref); return p ? fmtRef(p.y, p.n) : null; }
  function refSortVal(ref) { const p = parseRef(ref); return p ? p.y * 1e7 + p.n : -1; }
  function nextRef(rows, year) {
    let max = 0;
    rows.forEach(r => { const p = parseRef(r.referencia); if (p && p.y === year && p.n > max) max = p.n; });
    return fmtRef(year, max + 1);
  }

  // ---------- Si / No ----------
  function parseYN(v) {
    const s = normHeader(v);
    if (['si', 's', '1', 'true', 'x', 'yes', 'y', 'verdadero'].includes(s)) return 'SI';
    return 'NO';
  }

  // ---------- Gestión de Accesos: tiempo de ejecución ----------
  // Minutos entre inicio y gestión.
  //  - Inicio = Solicitud (o Fecha de reingreso si REINGRESO = SI)
  //  - Si FUERA DE HORARIO = SI: inicio = día de la gestión a las 10:00 (configurable)
  //  - Mínimo 0
  function tiempoEjecucionMin(row, horaInicio = '10:00') {
    if (!row || !row.gestion) return null;
    const g = toDate(row.gestion);
    if (!g) return null;
    let s;
    if (row.fueraHorario === 'SI') {
      const hm = /^(\d{1,2}):(\d{2})$/.exec(horaInicio) || ['', '10', '00'];
      s = new Date(g.getFullYear(), g.getMonth(), g.getDate(), +hm[1], +hm[2]);
    } else {
      s = toDate(row.reingreso === 'SI' && row.fechaReingreso ? row.fechaReingreso : row.solicitud);
    }
    if (!s) return null;
    return Math.max(0, Math.round((g - s) / 60000));
  }
  function fmtHM(min) {
    if (min == null) return '';
    return `${pad(Math.floor(min / 60))}:${pad(min % 60)}`;
  }

  // ---------- Registro DIFF ----------
  const toInt = (v) => { const n = parseInt(String(v == null ? '' : v).replace(/[^\d-]/g, ''), 10); return isNaN(n) ? 0 : n; };
  function calcDiff(row) {
    const total = toInt(row.total), sin = toInt(row.sinAcceso), ing = toInt(row.ingresos);
    const egr = total - sin - ing;
    const pIng = total ? ing / total * 100 : 0;
    const pEgr = total ? egr / total * 100 : 0;
    let accion = 'Importar';
    if (sin !== 0) accion = 'Consultar';
    else if (total > 100 && egr > 0 && egr >= 2 * ing) accion = 'Consultar';
    return { total, sin, ing, egr, pIng, pEgr, accion };
  }
  function fmtPct(p) {
    const r = Math.round(p * 10) / 10;
    return String(r).replace('.', ',') + '%';
  }

  const api = {
    pad, MESES, DIAS, nowISO, todayISO, validYMD, fmtD, fmtDT, parseDT, parseD, toDate, fmtLong,
    normCell, matchQuery, normHeader, parseRef, fmtRef, normRef, refSortVal, nextRef, parseYN,
    tiempoEjecucionMin, fmtHM, toInt, calcDiff, fmtPct
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.Logic = api;
})(typeof window !== 'undefined' ? window : globalThis);
