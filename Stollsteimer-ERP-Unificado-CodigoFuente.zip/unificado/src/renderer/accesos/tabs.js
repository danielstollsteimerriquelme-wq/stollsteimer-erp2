/* Definición de las 3 pestañas de datos: columnas, reglas de negocio, filtros. */
(function (root) {
  const L = root.Logic;

  // ---- helpers de listas (se alimentan de db.lists) ----
  function listValues(name) { return (App.db.lists[name] || []).map(o => o.value); }
  function estadoColor(value) {
    const o = (App.db.lists.estados || []).find(x => x.value === value);
    return o ? { bg: o.bg, color: o.color } : (value ? { bg: '#e6edf3', color: '#6b7684' } : null);
  }
  function autorizoText(solicitudISO) {
    const nombre = App.db.settings.autorizaNombre || 'Raúl Segovia';
    const f = L.fmtD(solicitudISO || L.nowISO());
    return `Autoriza ${nombre}, ${f}`;
  }
  const ACCION_COLORS = {
    Importar: { bg: '#e2f4e6', color: '#1b5e20' },
    Consultar: { bg: '#fbe3e0', color: '#c0392b' }
  };
  const PURPLE = '#7b1fa2';

  // ===================== 1. GESTIÓN DE ACCESOS =====================
  const accesos = {
    id: 'accesos', title: 'Gestión de Accesos', icon: '📋', unit: 'solicitudes',
    newLabel: '＋ Nueva solicitud', singular: 'solicitud',
    defaultSort: { key: 'referencia', dir: 'desc' },
    matchKey: 'referencia',
    fields: [
      { key: 'referencia', label: 'REFERENCIA', type: 'ref', aliases: ['ref', 'referencia'], sortVal: r => L.refSortVal(r.referencia) },
      { key: 'enviada', label: 'RESPUESTA ENVIADA', type: 'yn', inline: true, aliases: ['respuestaenviada', 'enviada'] },
      { key: 'documento', label: 'N° DOCUMENTO', type: 'text', aliases: ['ndocumento', 'ndedocumento', 'numerodocumento', 'numerodedocumento', 'documento', 'rut', 'run'] },
      { key: 'nombreUsuario', label: 'NOMBRE DE USUARIO', type: 'text', aliases: ['nombredeusuario', 'nombreusuario', 'usuario', 'nombre'] },
      { key: 'acceso', label: 'ACCESO SOLICITADO', type: 'select', optionsFn: () => listValues('accesos'), aliases: ['accesosolicitado', 'acceso'] },
      { key: 'solicitud', label: 'SOLICITUD', type: 'datetime', aliases: ['solicitud', 'fechasolicitud'] },
      { key: 'expiracion', label: 'EXPIRACIÓN', type: 'date', aliases: ['expiracion', 'vencimiento', 'fechaexpiracion'] },
      { key: 'autorizo', label: 'AUTORIZÓ', type: 'text', aliases: ['autorizo', 'autoriza', 'autorizacion'] },
      { key: 'estado', label: 'ESTADO', type: 'select', inline: true, optionsFn: () => listValues('estados'), color: r => estadoColor(r.estado), aliases: ['estado'] },
      { key: 'gestion', label: 'GESTIÓN', type: 'datetime', aliases: ['gestion', 'fechagestion'] },
      { key: 'observacion', label: 'OBSERVACIÓN', type: 'textarea', aliases: ['observacion', 'observaciones'] },
      { key: 'gestiono', label: 'GESTIONÓ', type: 'text', aliases: ['gestiono', 'gestionadopor'] },
      { key: 'obsInterna', label: 'OBSERVACIÓN INTERNA', type: 'textarea', aliases: ['observacioninterna', 'obsinterna'] },
      { key: 'fueraHorario', label: 'FUERA DE HORARIO LABORAL', type: 'yn', inline: true, aliases: ['fueradehorariolaboral', 'fueradehorario', 'horariolaboral', 'laboral'] },
      { key: 'reingreso', label: 'REINGRESO', type: 'yn', inline: true, aliases: ['reingreso'] },
      { key: 'fechaReingreso', label: 'FECHA REINGRESO', type: 'datetime', aliases: ['fechareingreso', 'fechadereingreso'],
        visible: d => d.reingreso === 'SI' },
      { key: 'tiempo', label: 'TIEMPO DE EJECUCIÓN', type: 'computed', aliases: ['tiempodeejecucion', 'tiempoejecucion'],
        text: r => L.fmtHM(L.tiempoEjecucionMin(r, App.db.settings.horaInicio)),
        sortVal: r => { const m = L.tiempoEjecucionMin(r, App.db.settings.horaInicio); return m == null ? '' : m; } }
    ],
    filters: [
      { id: 'estado', label: 'Estado', get: r => r.estado, values: () => listValues('estados'), color: v => estadoColor(v) },
      { id: 'acceso', label: 'Acceso solicitado', get: r => r.acceso, values: () => listValues('accesos') },
      { id: 'enviada', label: 'Respuesta enviada', get: r => r.enviada, values: () => ['SI', 'NO'] },
      { id: 'anio', label: 'Año', get: r => { const p = L.parseRef(r.referencia); return p ? String(p.y) : ''; }, values: null, desc: true }
    ],
    newRow(rows) {
      const now = new Date(), y = now.getFullYear();
      const est = listValues('estados')[0] || '';
      return {
        referencia: L.nextRef(rows, y), enviada: 'NO', documento: '', nombreUsuario: '', acceso: '',
        solicitud: L.nowISO(now), expiracion: `${y}-12-31`, autorizo: autorizoText(L.nowISO(now)),
        estado: est, gestion: '', observacion: '', gestiono: App.db.settings.gestionoDefault || 'DASR',
        obsInterna: '', fueraHorario: 'NO', reingreso: 'NO', fechaReingreso: ''
      };
    },
    // Reglas encadenadas: se ejecutan al cambiar un campo (en el formulario o en la tabla)
    onChange(d, key, ctx) {
      if (key === 'enviada') {
        if (d.enviada === 'SI' && ctx.prev !== 'SI') d.gestion = L.nowISO();   // NO -> SI : gestión automática
        if (d.enviada === 'NO') d.gestion = '';
      }
      if (key === 'solicitud' && !(ctx.touched && ctx.touched.autorizo)) d.autorizo = autorizoText(d.solicitud);
      if (key === 'autorizo' && ctx.touched) ctx.touched.autorizo = d.autorizo !== autorizoText(d.solicitud);
      if (key === 'reingreso' && d.reingreso === 'SI' && !d.fechaReingreso) d.fechaReingreso = L.nowISO();
    },
    validate(d, rows, id, invalid) {
      const errs = [];
      if (!L.parseRef(d.referencia)) errs.push(['referencia', 'La referencia debe tener formato aaaa-xxxx (ej: 2026-0001).']);
      else if (rows.some(r => r.id !== id && L.normRef(r.referencia) === L.normRef(d.referencia))) errs.push(['referencia', `La referencia ${d.referencia} ya existe.`]);
      if (!d.solicitud) errs.push(['solicitud', 'Indica la fecha y hora de la solicitud (dd-mm-aaaa hh:mm).']);
      if (d.reingreso === 'SI' && !d.fechaReingreso) errs.push(['fechaReingreso', 'Con REINGRESO = SI debes indicar la fecha de reingreso.']);
      return errs;
    },
    beforeSave(d) { if (d.enviada === 'SI' && !d.gestion) d.gestion = L.nowISO(); d.referencia = L.normRef(d.referencia); },
    preview(d) {
      const m = L.tiempoEjecucionMin(d, App.db.settings.horaInicio);
      const base = d.fueraHorario === 'SI' ? `día de gestión a las ${App.db.settings.horaInicio || '10:00'}`
        : (d.reingreso === 'SI' ? 'fecha de reingreso' : 'fecha de solicitud');
      return `<div class="calc-line"><span>TIEMPO DE EJECUCIÓN</span><b>${m == null ? '—' : L.fmtHM(m) + ' h'}</b></div>
              <div class="calc-note">Gestión − ${base} (mínimo 00:00)</div>`;
    }
  };

  // ===================== 2. REGISTRO DIFF =====================
  const calc = (r) => L.calcDiff(r);
  function accionOf(r) {
    const a = calc(r).accion;
    const base = ACCION_COLORS[a];
    return { text: a, bg: base.bg, color: r.autorizacion === 'Autorizado' ? PURPLE : base.color };
  }
  const diff = {
    id: 'diff', title: 'Registro DIFF', icon: '📊', unit: 'registros',
    newLabel: '＋ Nuevo registro', singular: 'registro',
    defaultSort: { key: 'fecha', dir: 'desc' },
    matchKey: 'fecha',
    fields: [
      { key: 'fecha', label: 'FECHA', type: 'date', text: r => L.fmtLong(r.fecha), aliases: ['fecha'] },
      { key: 'total', label: 'TOTAL', type: 'int', aliases: ['total'] },
      { key: 'sinAcceso', label: 'SIN ACCESO', type: 'int', aliases: ['sinacceso'] },
      { key: 'ingresos', label: 'INGRESOS', type: 'int', aliases: ['ingresos'] },
      { key: 'pIng', label: '% INGRESOS', type: 'computed', text: r => L.fmtPct(calc(r).pIng), sortVal: r => calc(r).pIng, noImport: true },
      { key: 'egresos', label: 'EGRESOS', type: 'computed', text: r => String(calc(r).egr), sortVal: r => calc(r).egr, noImport: true },
      { key: 'pEgr', label: '% EGRESOS', type: 'computed', text: r => L.fmtPct(calc(r).pEgr), sortVal: r => calc(r).pEgr, noImport: true },
      { key: 'accion', label: 'ACCIÓN', type: 'computed', pill: true, text: r => accionOf(r).text, color: r => { const a = accionOf(r); return { bg: a.bg, color: a.color }; }, sortVal: r => accionOf(r).text, aliases: ['accion'], noImport: true },
      { key: 'autorizacion', label: 'AUTORIZACIÓN', type: 'select', inline: 'toggle', optionsFn: () => ['Autorizar', 'Autorizado'],
        color: r => r.autorizacion === 'Autorizado' ? { bg: '#efe1f7', color: PURPLE } : { bg: '#eef2f6', color: '#3c4858' }, aliases: ['autorizacion'] },
      { key: 'observacion', label: 'OBSERVACIÓN', type: 'textarea', aliases: ['observacion', 'observaciones'] }
    ],
    filters: [
      { id: 'accion', label: 'Acción', get: r => accionOf(r).text, values: () => ['Importar', 'Consultar'], color: v => ACCION_COLORS[v] },
      { id: 'autorizacion', label: 'Autorización', get: r => r.autorizacion, values: () => ['Autorizar', 'Autorizado'] },
      { id: 'anio', label: 'Año', get: r => (r.fecha || '').slice(0, 4), values: null, desc: true }
    ],
    newRow() {
      return { fecha: L.todayISO(), total: 0, sinAcceso: 0, ingresos: 0, autorizacion: 'Autorizar', observacion: '' };
    },
    onChange() {},
    validate(d, rows, id) {
      const errs = [];
      if (!d.fecha) errs.push(['fecha', 'Indica la fecha (dd-mm-aaaa).']);
      return errs;
    },
    softWarn(d, rows, id) {
      if (d.fecha && rows.some(r => r.id !== id && r.fecha === d.fecha)) return `Ya existe un registro DIFF para el ${L.fmtLong(d.fecha)}. ¿Guardar de todos modos?`;
      return null;
    },
    beforeSave(d) { ['total', 'sinAcceso', 'ingresos'].forEach(k => { d[k] = L.toInt(d[k]); }); },
    preview(d) {
      const c = calc(d), a = accionOf(d);
      return `<div class="calc-line"><span>EGRESOS (TOTAL − SIN ACCESO − INGRESOS)</span><b>${c.egr}</b></div>
              <div class="calc-line"><span>% INGRESOS</span><b>${L.fmtPct(c.pIng)}</b></div>
              <div class="calc-line"><span>% EGRESOS</span><b>${L.fmtPct(c.pEgr)}</b></div>
              <div class="calc-line"><span>ACCIÓN</span><b class="pill" style="background:${a.bg};color:${a.color}">${a.text}</b></div>`;
    }
  };

  // ===================== 3. REGISTRO TUI =====================
  const tui = {
    id: 'tui', title: 'Registro TUI', icon: '🧾', unit: 'registros',
    newLabel: '＋ Nuevo registro', singular: 'registro',
    defaultSort: { key: 'referencia', dir: 'desc' },
    matchKey: 'referencia',
    fields: [
      { key: 'referencia', label: 'REFERENCIA', type: 'ref', aliases: ['ref', 'referencia'], sortVal: r => L.refSortVal(r.referencia) },
      { key: 'ingreso', label: 'INGRESO', type: 'datetime', aliases: ['ingreso', 'fechaingreso'] },
      { key: 'gestion', label: 'GESTIÓN', type: 'datetime', auto: true, aliases: ['gestion'] },
      { key: 'solicitante', label: 'SOLICITANTE', type: 'text', aliases: ['solicitante'] },
      { key: 'documento', label: 'NÚMERO DE DOCUMENTO', type: 'text', aliases: ['numerodedocumento', 'numerodocumento', 'ndocumento', 'ndedocumento', 'documento', 'rut', 'run'] },
      { key: 'usuario', label: 'USUARIO', type: 'text', aliases: ['usuario'] },
      { key: 'tuiLeida', label: 'TUI LEÍDA', type: 'text', aliases: ['tuileida'] },
      { key: 'tuiSistema', label: 'TUI SISTEMA', type: 'text', aliases: ['tuisistema'] },
      { key: 'observacion', label: 'OBSERVACIÓN', type: 'textarea', aliases: ['observacion', 'observaciones'] }
    ],
    filters: [
      { id: 'anio', label: 'Año', get: r => { const p = L.parseRef(r.referencia); return p ? String(p.y) : ''; }, values: null, desc: true }
    ],
    newRow(rows) {
      const now = new Date();
      return { referencia: L.nextRef(rows, now.getFullYear()), ingreso: L.nowISO(now), gestion: '', solicitante: '', documento: '', usuario: '', tuiLeida: '', tuiSistema: '', observacion: '' };
    },
    onChange() {},
    validate(d, rows, id) {
      const errs = [];
      if (!L.parseRef(d.referencia)) errs.push(['referencia', 'La referencia debe tener formato aaaa-xxxx (ej: 2026-0001).']);
      else if (rows.some(r => r.id !== id && L.normRef(r.referencia) === L.normRef(d.referencia))) errs.push(['referencia', `La referencia ${d.referencia} ya existe.`]);
      if (!d.ingreso) errs.push(['ingreso', 'Indica la fecha y hora de ingreso (dd-mm-aaaa hh:mm).']);
      return errs;
    },
    // GESTIÓN se completa sola al terminar de editar la fila (al guardar)
    beforeSave(d) { d.gestion = L.nowISO(); d.referencia = L.normRef(d.referencia); },
    preview(d) { return `<div class="calc-note">GESTIÓN se registra automáticamente al guardar la fila.</div>`; }
  };

  root.TABS = { accesos, diff, tui };
  root.TAB_ORDER = ['accesos', 'diff', 'tui'];
  root.TabHelpers = { listValues, estadoColor, autorizoText };
})(window);
