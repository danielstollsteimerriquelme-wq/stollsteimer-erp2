// Cuando el módulo corre dentro de la ventana principal, el logo lo muestra la barra superior.
if (/[?&]embedded=1/.test(location.search)) document.documentElement.classList.add('embedded');
