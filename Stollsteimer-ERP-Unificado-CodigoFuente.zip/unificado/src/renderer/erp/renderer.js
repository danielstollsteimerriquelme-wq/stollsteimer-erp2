// ================= Estado global =================
let devices = [];
let schema = [];
let settings = { columnOrder: [], formOrder: [] };
let selectedIds = new Set();
let activeFilters = { tipo: null, estado: null };
let searchTerm = '';
let currentDeviceId = null;
let confirmCallback = null;
let sortState = { key: null, dir: null }; // dir: 'asc' | 'desc' | null
let configContext = null; // 'table' | 'form'
let configWorking = [];
let optionsFieldKey = null;
let exportPending = null; // { type: 'csv'|'pdf', scope, ids }
let importPending = null; // { toCreate, toUpdate }
let mailThenCopy = false; // true si el modal de columnas se abrió desde "Copiar a correo"

// ---------- utilidades de fecha (siempre 24 horas) ----------
function pad2(n) { return String(n).padStart(2, '0'); }
function fmtDateTime(isoString) {
  const d = new Date(isoString);
  if (isNaN(d.getTime())) return '';
  return `${pad2(d.getDate())}-${pad2(d.getMonth() + 1)}-${d.getFullYear()}, ${pad2(d.getHours())}:${pad2(d.getMinutes())}:${pad2(d.getSeconds())}`;
}
function fmtDateOnly(dateStr) {
  const d = new Date(dateStr + 'T00:00:00');
  if (isNaN(d.getTime())) return '';
  return `${pad2(d.getDate())}-${pad2(d.getMonth() + 1)}-${d.getFullYear()}`;
}

// ================= Inicialización =================
async function init() {
  schema = await window.api.getSchema();
  settings = await window.api.getSettings();
  devices = await window.api.getAll();
  renderFilters();
  renderTable();
  bindStaticEvents();
}
init();

function toast(msg, type = '') {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.className = 'toast ' + type;
  setTimeout(() => { el.classList.add('hidden'); }, 2800);
}

// ================= Navegación superior =================
function bindStaticEvents() {
  document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const view = btn.dataset.view;
      document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
      document.getElementById('view-' + view).classList.add('active');
      if (view === 'campos') renderFieldsView();
      if (view === 'gantt') renderGantt();
      if (view === 'respaldo') renderBackupView();
    });
  });

  document.getElementById('ganttRange').addEventListener('change', renderGantt);

  document.getElementById('searchInput').addEventListener('input', (e) => {
    searchTerm = e.target.value.toLowerCase();
    renderTable();
  });

  document.getElementById('btnAddDevice').addEventListener('click', createNewDevice);
  document.getElementById('btnClearFilters').addEventListener('click', () => {
    activeFilters = { tipo: null, estado: null };
    renderFilters();
    renderTable();
  });

  document.getElementById('selectAll').addEventListener('change', (e) => {
    const visibleRows = getFilteredDevices();
    if (e.target.checked) visibleRows.forEach(d => selectedIds.add(d.id));
    else visibleRows.forEach(d => selectedIds.delete(d.id));
    renderTable();
  });

  document.getElementById('btnExportCSV').addEventListener('click', () => doExport('csv'));
  document.getElementById('btnExportPDF').addEventListener('click', () => doExport('pdf'));
  document.getElementById('btnImportCSV').addEventListener('click', startImportCSV);
  document.getElementById('closeImportPreviewModal').addEventListener('click', closeImportPreview);
  document.getElementById('importPreviewModal').addEventListener('click', (e) => {
    if (e.target.id === 'importPreviewModal') closeImportPreview();
  });
  document.getElementById('importCancel').addEventListener('click', closeImportPreview);
  document.getElementById('importConfirm').addEventListener('click', confirmImportCSV);
  document.getElementById('btnBulkDelete').addEventListener('click', startBulkDelete);

  document.getElementById('btnCopyMail').addEventListener('click', copyToMail);
  document.getElementById('btnMailCols').addEventListener('click', () => openMailColsModal(false));
  document.getElementById('closeMailColsModal').addEventListener('click', closeMailColsModal);
  document.getElementById('mailColsModal').addEventListener('click', (e) => {
    if (e.target.id === 'mailColsModal') closeMailColsModal();
  });
  document.getElementById('mailColsConfirm').addEventListener('click', confirmMailCols);
  document.getElementById('mailColsSelectAll').addEventListener('click', () => selectAllMailCols(true));
  document.getElementById('mailColsSelectNone').addEventListener('click', () => selectAllMailCols(false));

  document.getElementById('doubleConfirmInput').addEventListener('input', (e) => {
    const ok = e.target.value.trim().toUpperCase() === 'ELIMINAR';
    document.getElementById('doubleConfirmOk').disabled = !ok;
  });
  document.getElementById('doubleConfirmCancel').addEventListener('click', closeDoubleConfirm);
  document.getElementById('doubleConfirmModal').addEventListener('click', (e) => {
    if (e.target.id === 'doubleConfirmModal') closeDoubleConfirm();
  });
  document.getElementById('doubleConfirmOk').addEventListener('click', executeBulkDelete);

  document.getElementById('btnSaveBackupConfig').addEventListener('click', saveBackupConfig);
  document.getElementById('btnRunBackupNow').addEventListener('click', runBackupNowFromUI);
  document.getElementById('btnRestoreBackup').addEventListener('click', restoreBackupFromUI);

  document.getElementById('inputModalCancel').addEventListener('click', closeInputModal);
  document.getElementById('inputModalOk').addEventListener('click', submitInputModal);
  document.getElementById('inputModal').addEventListener('click', (e) => {
    if (e.target.id === 'inputModal') closeInputModal();
  });
  document.getElementById('inputModalField').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') submitInputModal();
    if (e.key === 'Escape') closeInputModal();
  });

  document.getElementById('btnColumnConfig').addEventListener('click', () => openConfigModal('table'));
  document.getElementById('btnFieldConfig').addEventListener('click', () => openConfigModal('form'));
  document.getElementById('closeConfigModal').addEventListener('click', closeConfigModal);
  document.getElementById('configModal').addEventListener('click', (e) => {
    if (e.target.id === 'configModal') closeConfigModal();
  });
  document.getElementById('configApply').addEventListener('click', applyConfigModal);
  document.getElementById('configReset').addEventListener('click', resetConfigModal);

  document.getElementById('closeOptionsModal').addEventListener('click', closeOptionsModal);
  document.getElementById('optionsModal').addEventListener('click', (e) => {
    if (e.target.id === 'optionsModal') closeOptionsModal();
  });
  document.getElementById('btnAddOption').addEventListener('click', addOptionToField);
  document.getElementById('newOptionValue').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') addOptionToField();
  });

  document.getElementById('closeExportFieldsModal').addEventListener('click', closeExportFieldsModal);
  document.getElementById('exportFieldsModal').addEventListener('click', (e) => {
    if (e.target.id === 'exportFieldsModal') closeExportFieldsModal();
  });
  document.getElementById('exportFieldsConfirm').addEventListener('click', confirmExportFields);
  document.getElementById('exportFieldsSelectAll').addEventListener('click', () => selectAllExportFields(true));
  document.getElementById('exportFieldsSelectNone').addEventListener('click', () => selectAllExportFields(false));

  // Modal dispositivo
  document.getElementById('closeModal').addEventListener('click', closeDeviceModal);
  document.getElementById('deviceModal').addEventListener('click', (e) => {
    if (e.target.id === 'deviceModal') closeDeviceModal();
  });
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById('tab-' + btn.dataset.tab).classList.add('active');
    });
  });

  document.getElementById('btnDeleteDevice').addEventListener('click', () => {
    askConfirm('¿Eliminar este dispositivo y todo su historial? Esta acción no se puede deshacer.', async () => {
      await window.api.deleteDevice(currentDeviceId);
      devices = await window.api.getAll();
      closeDeviceModal();
      renderTable();
      toast('Dispositivo eliminado', 'success');
    });
  });
  document.getElementById('btnDuplicateDevice').addEventListener('click', async () => {
    const copy = await window.api.duplicateDevice(currentDeviceId);
    devices = await window.api.getAll();
    renderTable();
    toast('Dispositivo duplicado como ' + copy.codigo, 'success');
    openDeviceModal(copy.id);
  });
  document.getElementById('btnExportIndividualPDF').addEventListener('click', async () => {
    const res = await window.api.exportPDF('individual', [currentDeviceId]);
    if (res && res.ok) toast('Ficha exportada: ' + res.path, 'success');
  });

  document.getElementById('btnAddMaint').addEventListener('click', addMaintenanceEntry);
  document.getElementById('btnAddImages').addEventListener('click', addImages);
  document.getElementById('btnSaveSchedule').addEventListener('click', saveScheduleDate);
  document.getElementById('maintMarkDone').addEventListener('change', (e) => {
    document.getElementById('nextDateRow').style.display = e.target.checked ? 'flex' : 'none';
  });

  // Campos personalizados
  document.getElementById('newFieldType').addEventListener('change', (e) => {
    document.getElementById('newFieldOptions').style.display = e.target.value === 'select' ? 'block' : 'none';
  });
  document.getElementById('btnAddField').addEventListener('click', addCustomField);

  // Confirm modal
  document.getElementById('confirmCancel').addEventListener('click', () => {
    document.getElementById('confirmModal').classList.add('hidden');
  });
  document.getElementById('confirmOk').addEventListener('click', () => {
    document.getElementById('confirmModal').classList.add('hidden');
    if (confirmCallback) confirmCallback();
  });
}

function askConfirm(text, cb) {
  document.getElementById('confirmText').textContent = text;
  confirmCallback = cb;
  document.getElementById('confirmModal').classList.remove('hidden');
}

// Reemplazo de window.prompt (Electron no lo soporta): muestra un modal y
// entrega el valor ingresado mediante callback (null si se cancela).
let inputCallback = null;
function askInput(title, label, defaultValue, cb) {
  document.getElementById('inputModalTitle').textContent = title;
  document.getElementById('inputModalLabel').textContent = label || '';
  const field = document.getElementById('inputModalField');
  field.value = defaultValue || '';
  inputCallback = cb;
  document.getElementById('inputModal').classList.remove('hidden');
  setTimeout(() => { field.focus(); field.select(); }, 50);
}

function closeInputModal() {
  document.getElementById('inputModal').classList.add('hidden');
  inputCallback = null;
}

function submitInputModal() {
  const value = document.getElementById('inputModalField').value;
  const cb = inputCallback;
  closeInputModal();
  if (cb) cb(value);
}

// ================= Filtros laterales =================
function renderFilters() {
  const tipoField = schema.find(f => f.key === 'tipo');
  const tipos = {};
  (tipoField && tipoField.options || []).forEach(opt => { tipos[opt] = 0; });
  const estados = {};
  devices.forEach(d => {
    tipos[d.tipo || 'Sin definir'] = (tipos[d.tipo || 'Sin definir'] || 0) + 1;
    estados[d.estado || 'Sin estado'] = (estados[d.estado || 'Sin estado'] || 0) + 1;
  });

  const tipoContainer = document.getElementById('filterTipo');
  tipoContainer.innerHTML = '';
  Object.keys(tipos).sort().forEach(t => {
    const chip = document.createElement('div');
    chip.className = 'filter-chip' + (activeFilters.tipo === t ? ' active' : '');
    const isRealOption = tipoField && (tipoField.options || []).includes(t);
    chip.innerHTML = `
      <span class="filter-chip-label">${t}</span>
      <span class="filter-chip-actions">
        <span class="count">${tipos[t]}</span>
        ${isRealOption ? `
          <button class="chip-icon-btn chip-edit" data-value="${escapeHtml(t)}" title="Editar tipo">✏</button>
          <button class="chip-icon-btn chip-del" data-value="${escapeHtml(t)}" title="Eliminar tipo">×</button>
        ` : ''}
      </span>`;
    chip.querySelector('.filter-chip-label').addEventListener('click', () => {
      activeFilters.tipo = activeFilters.tipo === t ? null : t;
      renderFilters();
      renderTable();
    });
    const editBtn = chip.querySelector('.chip-edit');
    if (editBtn) editBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      openInlineRename('tipo', t);
    });
    const delBtn = chip.querySelector('.chip-del');
    if (delBtn) delBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      askConfirm(`¿Eliminar el tipo "${t}"? Los dispositivos que ya lo tengan lo conservarán como valor libre.`, async () => {
        schema = await window.api.deleteFieldOption('tipo', t);
        if (activeFilters.tipo === t) activeFilters.tipo = null;
        renderFilters();
        renderTable();
        toast('Tipo eliminado', 'success');
      });
    });
    tipoContainer.appendChild(chip);
  });

  const estadoContainer = document.getElementById('filterEstado');
  estadoContainer.innerHTML = '';
  Object.keys(estados).sort().forEach(es => {
    const chip = document.createElement('div');
    chip.className = 'filter-chip' + (activeFilters.estado === es ? ' active' : '');
    chip.innerHTML = `<span>${es}</span><span class="count">${estados[es]}</span>`;
    chip.addEventListener('click', () => {
      activeFilters.estado = activeFilters.estado === es ? null : es;
      renderFilters();
      renderTable();
    });
    estadoContainer.appendChild(chip);
  });
}

function openInlineRename(fieldKey, oldValue) {
  const field = schema.find(f => f.key === fieldKey);
  const fieldLabel = field ? field.label : fieldKey;
  askInput('Editar valor', `Nuevo valor para "${oldValue}" en ${fieldLabel}:`, oldValue, (newValue) => {
    if (newValue === null) return;
    const trimmed = String(newValue).trim();
    if (!trimmed || trimmed === oldValue) return;
    window.api.renameFieldOption(fieldKey, oldValue, trimmed).then(async (s) => {
      schema = s;
      devices = await window.api.getAll();
      if (activeFilters[fieldKey] === oldValue) activeFilters[fieldKey] = trimmed;
      renderFilters();
      renderTable();
      toast('Actualizado', 'success');
    }).catch(err => toast(err.message, 'error'));
  });
}

function getFilteredDevices() {
  let list = devices.filter(d => {
    if (activeFilters.tipo && (d.tipo || 'Sin definir') !== activeFilters.tipo) return false;
    if (activeFilters.estado && (d.estado || 'Sin estado') !== activeFilters.estado) return false;
    if (searchTerm) {
      const hay = schema.some(f => String(d[f.key] || '').toLowerCase().includes(searchTerm));
      if (!hay) return false;
    }
    return true;
  });

  if (sortState.key && sortState.dir) {
    const key = sortState.key;
    const dir = sortState.dir === 'asc' ? 1 : -1;
    list = [...list].sort((a, b) => {
      const va = a[key], vb = b[key];
      const na = va === '' || va === null || va === undefined ? null : Number(va);
      const nb = vb === '' || vb === null || vb === undefined ? null : Number(vb);
      // si ambos valores son numericos validos, comparar como numero
      if (na !== null && nb !== null && !isNaN(na) && !isNaN(nb) && String(va).trim() !== '' && String(vb).trim() !== '') {
        return (na - nb) * dir;
      }
      return String(va || '').localeCompare(String(vb || ''), 'es', { sensitivity: 'base', numeric: true }) * dir;
    });
  }

  return list;
}

// Determina qué columnas se muestran en la vista general y en qué orden.
// La primera columna es siempre "Detalle" (solo ícono) y la segunda siempre "Código".
function getVisibleTableColumns() {
  const rest = settings.columnOrder
    .filter(c => c.visible)
    .map(c => schema.find(f => f.key === c.key))
    .filter(Boolean);
  return rest;
}

// ================= Semáforo de mantenimiento =================
// Calcula el estado de proximidad del mantenimiento programado de un dispositivo.
function getMaintStatus(d) {
  const dateStr = d.proximoMantenimiento;
  if (!dateStr) return { color: 'white', label: 'Sin mantenimiento programado', days: null };
  const target = new Date(dateStr + 'T00:00:00');
  if (isNaN(target.getTime())) return { color: 'white', label: 'Sin mantenimiento programado', days: null };
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const diffDays = Math.round((target - today) / (1000 * 60 * 60 * 24));

  let color, label;
  if (diffDays < 0) { color = 'red'; label = `Vencido hace ${Math.abs(diffDays)} día(s)`; }
  else if (diffDays <= 15) { color = 'red'; label = `Faltan ${diffDays} día(s)`; }
  else if (diffDays <= 30) { color = 'yellow'; label = `Faltan ${diffDays} día(s)`; }
  else if (diffDays <= 45) { color = 'green'; label = `Faltan ${diffDays} día(s)`; }
  else { color = 'green'; label = `Faltan ${diffDays} día(s)`; }
  return { color, label, days: diffDays };
}

function semaforoDot(status) {
  return `<span class="semaforo-dot semaforo-${status.color}" title="${escapeHtml(status.label)}"></span>`;
}

// ================= Tabla principal =================
function badgeClass(estado) {
  if (!estado) return 'badge-def';
  if (/operativa|disponible|en uso/i.test(estado)) return 'badge-op';
  if (/mantenimiento|reservada|instalar/i.test(estado)) return 'badge-mant';
  if (/no operativa/i.test(estado)) return 'badge-noop';
  return 'badge-def';
}

function sortArrow(key) {
  if (sortState.key !== key || !sortState.dir) return '<span class="sort-arrow">⇅</span>';
  return sortState.dir === 'asc' ? '<span class="sort-arrow">▲</span>' : '<span class="sort-arrow">▼</span>';
}

function renderTable() {
  const list = getFilteredDevices();
  document.getElementById('statTotal').textContent = devices.length;
  document.getElementById('selectionCount').textContent = selectedIds.size > 0 ? `${selectedIds.size} seleccionados` : '';
  document.getElementById('btnBulkDelete').classList.toggle('hidden', selectedIds.size === 0);
  document.getElementById('btnBulkDelete').textContent = `🗑 Eliminar seleccionados (${selectedIds.size})`;
  document.getElementById('btnCopyMail').classList.toggle('hidden', selectedIds.size === 0);
  document.getElementById('btnMailCols').classList.toggle('hidden', selectedIds.size === 0);

  const codigoField = schema.find(f => f.key === 'codigo');
  const extraCols = getVisibleTableColumns();
  const cols = [codigoField, ...extraCols].filter(Boolean);

  const head = document.getElementById('tableHead');
  head.innerHTML =
    `<th style="width:30px;"></th>` +
    `<th class="col-detalle">🔍</th>` +
    `<th class="col-semaforo" title="Estado del próximo mantenimiento programado">🚦</th>` +
    cols.map(c => {
      const active = sortState.key === c.key ? ' sort-active' : '';
      return `<th class="sortable${active}" data-sort-key="${c.key}">${c.label}${sortArrow(c.key)}</th>`;
    }).join('') +
    `<th>Acciones</th>`;

  document.querySelectorAll('#tableHead th.sortable').forEach(th => {
    th.addEventListener('click', () => {
      const key = th.dataset.sortKey;
      if (sortState.key !== key) { sortState = { key, dir: 'asc' }; }
      else if (sortState.dir === 'asc') { sortState.dir = 'desc'; }
      else if (sortState.dir === 'desc') { sortState = { key: null, dir: null }; }
      else { sortState = { key, dir: 'asc' }; }
      renderTable();
    });
  });

  const body = document.getElementById('tableBody');
  body.innerHTML = '';
  list.forEach(d => {
    const tr = document.createElement('tr');
    if (selectedIds.has(d.id)) tr.classList.add('selected');
    const checkboxCell = `<td><input type="checkbox" class="rowcheck" data-id="${d.id}" ${selectedIds.has(d.id) ? 'checked' : ''}></td>`;
    const detalleCell = `<td class="col-detalle"><button class="icon-btn btn-detail" data-id="${d.id}" title="Ver ficha completa">🔍</button></td>`;
    const semaforoCell = `<td class="col-semaforo">${semaforoDot(getMaintStatus(d))}</td>`;
    const cells = cols.map(c => {
      let val = d[c.key] || '';
      if (c.key === 'estado') {
        const field = schema.find(f => f.key === 'estado');
        const colorInfo = field && field.colors && field.colors[val];
        if (colorInfo && (colorInfo.bg || colorInfo.text)) {
          const style = `background:${colorInfo.bg || '#e6edf3'}; color:${colorInfo.text || '#3c4858'};`;
          return `<td><span class="badge" style="${style}">${escapeHtml(val)}</span></td>`;
        }
        return `<td><span class="badge ${badgeClass(val)}">${escapeHtml(val)}</span></td>`;
      }
      if (c.key === 'actualizacion' && val) {
        try { val = fmtDateTime(val); } catch (e) {}
      }
      return `<td>${escapeHtml(val)}</td>`;
    }).join('');
    const actions = `<td class="row-actions">
        <button class="icon-btn btn-del" data-id="${d.id}" title="Eliminar">🗑</button>
      </td>`;
    tr.innerHTML = checkboxCell + detalleCell + semaforoCell + cells + actions;
    body.appendChild(tr);
  });

  document.querySelectorAll('.rowcheck').forEach(cb => {
    cb.addEventListener('change', (e) => {
      const id = e.target.dataset.id;
      if (e.target.checked) selectedIds.add(id); else selectedIds.delete(id);
      renderTable();
    });
  });
  document.querySelectorAll('.btn-detail').forEach(b => {
    b.addEventListener('click', () => openDeviceModal(b.dataset.id));
  });
  document.querySelectorAll('.btn-del').forEach(b => {
    b.addEventListener('click', () => {
      askConfirm('¿Eliminar este dispositivo?', async () => {
        await window.api.deleteDevice(b.dataset.id);
        devices = await window.api.getAll();
        selectedIds.delete(b.dataset.id);
        renderFilters();
        renderTable();
        toast('Dispositivo eliminado', 'success');
      });
    });
  });
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}

function toHexColor(val) {
  return /^#[0-9a-fA-F]{6}$/.test(val) ? val : '#e6edf3';
}

// ================= Crear dispositivo =================
async function createNewDevice() {
  const base = {};
  schema.forEach(f => { base[f.key] = ''; });
  base.codigo = 'NUEVO-' + Date.now().toString().slice(-5);
  base.estado = schema.find(f => f.key === 'estado')?.options?.[0] || '';
  const newDevice = await window.api.addDevice(base);
  devices = await window.api.getAll();
  renderFilters();
  renderTable();
  openDeviceModal(newDevice.id);
}

// ================= Modal de dispositivo =================
function openDeviceModal(id) {
  currentDeviceId = id;
  const d = devices.find(x => x.id === id);
  if (!d) return;
  document.getElementById('modalTitle').textContent = `Dispositivo — ${d.codigo || d.id}`;
  renderDeviceForm(d);
  renderScheduleCard(d);
  renderMaintHistory(d);
  renderSerialHistory(d);
  renderImageGallery(d);
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
  document.querySelector('.tab-btn[data-tab="datos"]').classList.add('active');
  document.getElementById('tab-datos').classList.add('active');
  document.getElementById('deviceModal').classList.remove('hidden');
}
function closeDeviceModal() {
  document.getElementById('deviceModal').classList.add('hidden');
  currentDeviceId = null;
}

function getOrderedFormFields() {
  return settings.formOrder
    .filter(c => c.visible)
    .map(c => schema.find(f => f.key === c.key))
    .filter(Boolean);
}

function renderDeviceForm(d) {
  const container = document.getElementById('deviceFormFields');
  container.innerHTML = '';
  const orderedFields = getOrderedFormFields();
  orderedFields.forEach(f => {
    const group = document.createElement('div');
    group.className = 'field-group' + (f.type === 'textarea' ? ' full' : '');
    const label = document.createElement('label');
    label.textContent = f.label;
    group.appendChild(label);

    let input;
    if (f.type === 'textarea') {
      input = document.createElement('textarea');
      input.rows = 3;
      input.value = d[f.key] || '';
    } else if (f.type === 'select') {
      input = document.createElement('select');
      (f.options || []).forEach(opt => {
        const o = document.createElement('option');
        o.value = opt; o.textContent = opt;
        if (d[f.key] === opt) o.selected = true;
        input.appendChild(o);
      });
    } else {
      input = document.createElement('input');
      input.type = f.type === 'number' ? 'number' : (f.type === 'date' ? 'date' : 'text');
      input.value = f.type === 'datetime' && d[f.key] ? fmtDateTime(d[f.key]) : (d[f.key] || '');
      if (f.type === 'datetime') input.disabled = true;
    }
    input.dataset.key = f.key;
    input.addEventListener('change', async () => {
      const patch = {};
      patch[f.key] = input.value;
      await window.api.updateDevice(d.id, patch);
      devices = await window.api.getAll();
      renderFilters();
      renderTable();
      if (f.key === 'serie') renderSerialHistory(devices.find(x => x.id === d.id));
      toast('Guardado', 'success');
    });
    group.appendChild(input);
    container.appendChild(group);
  });
}

// ================= Historial de mantenimiento =================
// ================= Historial de N° de Serie =================
function renderSerialHistory(d) {
  const container = document.getElementById('serialHistoryList');
  const hist = d.historialSerie || [];
  if (hist.length === 0) {
    container.innerHTML = '<p class="muted">Sin cambios de N° de serie registrados.</p>';
    return;
  }
  container.innerHTML = '';
  hist.forEach(h => {
    const div = document.createElement('div');
    div.className = 'history-item';
    const fecha = h.fecha ? fmtDateTime(h.fecha) : '';
    div.innerHTML = `
      <div class="h-top"><span>${escapeHtml(h.anterior)} → ${escapeHtml(h.nuevo)}</span><span>${fecha}</span></div>
    `;
    container.appendChild(div);
  });
}

function renderMaintHistory(d) {
  const container = document.getElementById('maintHistoryList');
  const hist = d.mantenimientos || [];
  container.innerHTML = hist.length === 0
    ? '<p class="muted">Sin registros de mantenimiento aún.</p>'
    : '';
  hist.forEach(m => {
    const div = document.createElement('div');
    div.className = 'history-item';
    const fecha = m.fecha ? fmtDateTime(m.fecha) : '';
    div.innerHTML = `
      <div class="h-top"><span>${m.tipo} — ${m.estado}</span><span>${fecha}</span></div>
      <div class="h-meta">Técnico: ${escapeHtml(m.tecnico || '-')} ${m.costo ? '· Costo: ' + escapeHtml(m.costo) : ''}</div>
      <div class="h-desc">${escapeHtml(m.descripcion || '')}</div>
      <div class="h-actions"><button class="icon-btn btn-del-maint" data-id="${m.id}">🗑 Eliminar registro</button></div>
    `;
    container.appendChild(div);
  });
  container.querySelectorAll('.btn-del-maint').forEach(btn => {
    btn.addEventListener('click', async () => {
      await window.api.deleteMaint(currentDeviceId, btn.dataset.id);
      devices = await window.api.getAll();
      renderMaintHistory(devices.find(x => x.id === currentDeviceId));
      toast('Registro eliminado', 'success');
    });
  });
}

async function addMaintenanceEntry() {
  const markDone = document.getElementById('maintMarkDone').checked;
  const nextDate = document.getElementById('maintNextDate').value;
  const entry = {
    tipo: document.getElementById('maintTipo').value,
    estado: document.getElementById('maintEstado').value,
    tecnico: document.getElementById('maintTecnico').value,
    costo: document.getElementById('maintCosto').value,
    descripcion: document.getElementById('maintDescripcion').value
  };
  await window.api.addMaint(currentDeviceId, entry);

  // si el mantenimiento se realizó, se puede anotar la nueva fecha programada
  if (markDone && nextDate) {
    await window.api.updateDevice(currentDeviceId, { proximoMantenimiento: nextDate });
  }

  devices = await window.api.getAll();
  const d = devices.find(x => x.id === currentDeviceId);
  renderMaintHistory(d);
  renderScheduleCard(d);
  document.getElementById('maintTecnico').value = '';
  document.getElementById('maintCosto').value = '';
  document.getElementById('maintDescripcion').value = '';
  document.getElementById('maintNextDate').value = '';
  renderFilters();
  renderTable();
  toast('Registro agregado al historial', 'success');
}

// ================= Programar mantenimiento =================
function renderScheduleCard(d) {
  const status = getMaintStatus(d);
  document.getElementById('scheduleDate').value = d.proximoMantenimiento || '';
  const el = document.getElementById('scheduleStatusText');
  el.innerHTML = `${semaforoDot(status)} ${escapeHtml(status.label)}`;
}

async function saveScheduleDate() {
  const val = document.getElementById('scheduleDate').value;
  await window.api.updateDevice(currentDeviceId, { proximoMantenimiento: val });
  devices = await window.api.getAll();
  const d = devices.find(x => x.id === currentDeviceId);
  renderScheduleCard(d);
  renderFilters();
  renderTable();
  toast('Fecha de mantenimiento guardada', 'success');
}

// ================= Imágenes =================
async function renderImageGallery(d) {
  const gallery = document.getElementById('imageGallery');
  gallery.innerHTML = '';
  const imgs = d.imagenes || [];
  if (imgs.length === 0) {
    gallery.innerHTML = '<p class="muted">Sin imágenes agregadas.</p>';
    return;
  }
  for (const img of imgs) {
    const filePath = await window.api.getImagePath(img.filename);
    const tile = document.createElement('div');
    tile.className = 'image-tile';
    tile.innerHTML = `<img src="file://${filePath}" /><button class="remove-img" data-id="${img.id}">✕</button>`;
    gallery.appendChild(tile);
  }
  gallery.querySelectorAll('.remove-img').forEach(btn => {
    btn.addEventListener('click', async () => {
      await window.api.removeImage(currentDeviceId, btn.dataset.id);
      devices = await window.api.getAll();
      renderImageGallery(devices.find(x => x.id === currentDeviceId));
      toast('Imagen eliminada', 'success');
    });
  });
}

async function addImages() {
  const result = await window.api.pickImages(currentDeviceId);
  if (!result) return;
  devices = await window.api.getAll();
  renderImageGallery(devices.find(x => x.id === currentDeviceId));
  toast(`${result.length} imagen(es) agregada(s)`, 'success');
}

// ================= Exportación =================
async function doExport(type) {
  const scope = selectedIds.size > 0 ? 'seleccion' : 'all';
  const ids = Array.from(selectedIds);
  openExportFieldsModal(type, scope, ids);
}

// ================= Gestión de campos =================
function renderFieldsView() {
  const container = document.getElementById('fieldsList');
  container.innerHTML = '';
  schema.forEach(f => {
    const row = document.createElement('div');
    row.className = 'field-row';
    row.innerHTML = `
      <div><span class="f-name">${f.label}</span> <span class="f-meta">(${f.key} · ${f.type})</span>
        ${f.base ? '<span class="f-base-tag">Campo base</span>' : ''}
      </div>
      <div style="display:flex; gap:6px;">
        <button class="btn btn-secondary btn-small" data-rename-key="${f.key}">✏ Renombrar</button>
        ${f.type === 'select' ? `<button class="btn btn-secondary btn-small" data-opts-key="${f.key}">⚙ Opciones</button>` : ''}
        ${f.base ? '' : `<button class="btn btn-danger btn-small" data-key="${f.key}">Eliminar</button>`}
      </div>
    `;
    container.appendChild(row);
  });
  container.querySelectorAll('button[data-rename-key]').forEach(btn => {
    btn.addEventListener('click', () => renameFieldPrompt(btn.dataset.renameKey));
  });
  container.querySelectorAll('button[data-opts-key]').forEach(btn => {
    btn.addEventListener('click', () => openOptionsModal(btn.dataset.optsKey));
  });
  container.querySelectorAll('button[data-key]').forEach(btn => {
    btn.addEventListener('click', () => {
      askConfirm(`¿Eliminar el campo "${btn.dataset.key}"? Se borrará de todos los dispositivos.`, async () => {
        try {
          schema = await window.api.removeField(btn.dataset.key);
          devices = await window.api.getAll();
          settings = await window.api.getSettings();
          renderFieldsView();
          renderTable();
          toast('Campo eliminado', 'success');
        } catch (err) {
          toast(err.message, 'error');
        }
      });
    });
  });
}

async function addCustomField() {
  const label = document.getElementById('newFieldLabel').value.trim();
  let key = document.getElementById('newFieldKey').value.trim();
  const type = document.getElementById('newFieldType').value;
  const optionsRaw = document.getElementById('newFieldOptions').value.trim();

  if (!label) { toast('Ingresa un nombre para el campo', 'error'); return; }
  if (!key) key = label.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '_');

  const field = { key, label, type };
  if (type === 'select') field.options = optionsRaw.split(',').map(s => s.trim()).filter(Boolean);

  try {
    schema = await window.api.addField(field);
    devices = await window.api.getAll();
    settings = await window.api.getSettings();
    document.getElementById('newFieldLabel').value = '';
    document.getElementById('newFieldKey').value = '';
    document.getElementById('newFieldOptions').value = '';
    renderFieldsView();
    renderTable();
    toast('Campo agregado', 'success');
  } catch (err) {
    toast(err.message, 'error');
  }
}

// ================= Modal de personalización (columnas / campos) =================
function openConfigModal(context) {
  configContext = context;
  const title = context === 'table'
    ? 'Personalizar columnas — Vista General'
    : 'Personalizar campos — Ficha del Dispositivo';
  document.getElementById('configModalTitle').textContent = title;

  const order = context === 'table' ? settings.columnOrder : settings.formOrder;
  const excludeKeys = context === 'table' ? ['codigo'] : [];

  configWorking = order
    .filter(c => !excludeKeys.includes(c.key))
    .map(c => {
      const field = schema.find(f => f.key === c.key);
      return field ? { key: c.key, label: field.label, visible: c.visible } : null;
    })
    .filter(Boolean);

  renderConfigList();
  document.getElementById('configModal').classList.remove('hidden');
}

function closeConfigModal() {
  document.getElementById('configModal').classList.add('hidden');
  configContext = null;
}

function renderConfigList() {
  const container = document.getElementById('configFieldList');
  container.innerHTML = '';
  configWorking.forEach((item, idx) => {
    const row = document.createElement('div');
    row.className = 'config-field-row';
    row.innerHTML = `
      <label>
        <input type="checkbox" class="cf-visible" data-idx="${idx}" ${item.visible ? 'checked' : ''}>
        ${escapeHtml(item.label)}
      </label>
      <div class="cf-arrows">
        <button class="cf-up" data-idx="${idx}" ${idx === 0 ? 'disabled' : ''} title="Subir">▲</button>
        <button class="cf-down" data-idx="${idx}" ${idx === configWorking.length - 1 ? 'disabled' : ''} title="Bajar">▼</button>
      </div>
    `;
    container.appendChild(row);
  });

  container.querySelectorAll('.cf-visible').forEach(cb => {
    cb.addEventListener('change', (e) => {
      configWorking[Number(e.target.dataset.idx)].visible = e.target.checked;
    });
  });
  container.querySelectorAll('.cf-up').forEach(btn => {
    btn.addEventListener('click', () => {
      const i = Number(btn.dataset.idx);
      if (i > 0) {
        [configWorking[i - 1], configWorking[i]] = [configWorking[i], configWorking[i - 1]];
        renderConfigList();
      }
    });
  });
  container.querySelectorAll('.cf-down').forEach(btn => {
    btn.addEventListener('click', () => {
      const i = Number(btn.dataset.idx);
      if (i < configWorking.length - 1) {
        [configWorking[i + 1], configWorking[i]] = [configWorking[i], configWorking[i + 1]];
        renderConfigList();
      }
    });
  });
}

async function applyConfigModal() {
  const ctx = configContext; // capturar ANTES de cerrar el modal (que resetea configContext)
  const newOrder = configWorking.map(c => ({ key: c.key, visible: c.visible }));
  if (ctx === 'table') {
    settings.columnOrder = newOrder;
  } else {
    settings.formOrder = newOrder;
  }
  await window.api.saveSettings(settings);
  closeConfigModal();
  if (ctx === 'table') {
    renderTable();
    toast('Columnas actualizadas', 'success');
  } else {
    const d = devices.find(x => x.id === currentDeviceId);
    if (d) renderDeviceForm(d);
    toast('Campos actualizados', 'success');
  }
}

function resetConfigModal() {
  const excludeKeys = configContext === 'table' ? ['codigo'] : [];
  configWorking = schema
    .filter(f => !excludeKeys.includes(f.key))
    .map(f => ({ key: f.key, label: f.label, visible: true }));
  renderConfigList();
}

// ================= Carta Gantt =================
function renderGantt() {
  const container = document.getElementById('ganttContainer');
  const rangeDays = Number(document.getElementById('ganttRange').value || 45);

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const rangeStart = new Date(today);
  const rangeEnd = new Date(today);
  rangeEnd.setDate(rangeEnd.getDate() + rangeDays);

  // dispositivos con mantenimiento programado dentro (o antes, si esta vencido) del rango
  const scheduled = devices
    .filter(d => d.proximoMantenimiento)
    .map(d => ({ device: d, date: new Date(d.proximoMantenimiento + 'T00:00:00'), status: getMaintStatus(d) }))
    .filter(x => !isNaN(x.date.getTime()) && x.date <= rangeEnd)
    .sort((a, b) => a.date - b.date);

  if (scheduled.length === 0) {
    container.innerHTML = `<div class="gantt-empty">No hay mantenimientos programados dentro de los próximos ${rangeDays} días.<br>Agrega una fecha en la ficha de cada dispositivo, pestaña "Hoja de Vida / Mantenimiento".</div>`;
    return;
  }

  const totalDays = Math.max(rangeDays, 1);
  const dayWidth = Math.max(18, Math.floor(900 / totalDays));
  const trackWidth = dayWidth * totalDays;

  // encabezado: una marca cada 5 dias (o cada dia si el rango es corto)
  const step = rangeDays <= 30 ? 1 : (rangeDays <= 45 ? 3 : (rangeDays <= 90 ? 7 : 14));
  let headerHtml = `<div class="gantt-row-label" style="border-right:1px solid var(--border); font-weight:600;">Dispositivo</div><div class="gantt-track" style="position:relative; width:${trackWidth}px; display:flex;">`;
  for (let i = 0; i <= totalDays; i += step) {
    const d = new Date(rangeStart);
    d.setDate(d.getDate() + i);
    const label = `${pad2(d.getDate())}-${pad2(d.getMonth() + 1)}`;
    headerHtml += `<div class="gantt-day-label" style="width:${dayWidth * step}px;">${label}</div>`;
  }
  headerHtml += `</div>`;

  let rowsHtml = '';
  scheduled.forEach(({ device, date, status }) => {
    const dayOffset = Math.round((date - rangeStart) / (1000 * 60 * 60 * 24));
    const clampedOffset = Math.max(0, Math.min(dayOffset, totalDays));
    const markerLeft = clampedOffset * dayWidth;
    const barLeft = Math.min(markerLeft, dayOffset >= 0 ? markerLeft : 0);
    const barWidth = Math.abs(markerLeft - (0));
    rowsHtml += `
      <div class="gantt-row">
        <div class="gantt-row-label" title="${escapeHtml(device.codigo)} — ${escapeHtml(device.tipo || '')}">${escapeHtml(device.codigo)} <span class="muted">(${escapeHtml(device.tipo || 'Sin definir')})</span></div>
        <div class="gantt-track" style="width:${trackWidth}px;">
          <div class="gantt-bar" style="left:0; width:${markerLeft}px;"></div>
          <div class="gantt-marker semaforo-${status.color}" style="left:${markerLeft}px;" title="${escapeHtml(device.codigo)} — ${fmtDateOnly(device.proximoMantenimiento)} — ${escapeHtml(status.label)}"></div>
        </div>
      </div>`;
  });

  container.innerHTML = `
    <div class="gantt-header">${headerHtml}</div>
    <div style="position:relative;">${rowsHtml}</div>
  `;

  container.querySelectorAll('.gantt-marker').forEach((marker, idx) => {
    marker.addEventListener('click', () => openDeviceModal(scheduled[idx].device.id));
  });
}

// ================= Editor de opciones (campos tipo lista) =================
function openOptionsModal(fieldKey) {
  optionsFieldKey = fieldKey;
  const field = schema.find(f => f.key === fieldKey);
  if (!field) return;
  document.getElementById('optionsModalTitle').textContent = `Opciones — ${field.label}`;
  renderOptionsList();
  document.getElementById('optionsModal').classList.remove('hidden');
}

function closeOptionsModal() {
  document.getElementById('optionsModal').classList.add('hidden');
  optionsFieldKey = null;
}

function renderOptionsList() {
  const field = schema.find(f => f.key === optionsFieldKey);
  const container = document.getElementById('optionsList');
  container.innerHTML = '';
  (field.options || []).forEach(opt => {
    const colorInfo = (field.colors && field.colors[opt]) || {};
    const bg = colorInfo.bg || '#e6edf3';
    const textColor = colorInfo.text || '#3c4858';
    const row = document.createElement('div');
    row.className = 'config-field-row option-row';
    row.innerHTML = `
      <span class="option-preview" style="background:${bg}; color:${textColor};">${escapeHtml(opt)}</span>
      <input type="text" class="opt-input" value="${escapeHtml(opt)}" data-original="${escapeHtml(opt)}">
      <label class="color-pick-label" title="Color de fondo">Fondo
        <input type="color" class="opt-color-bg" value="${toHexColor(bg)}" data-value="${escapeHtml(opt)}">
      </label>
      <label class="color-pick-label" title="Color de letra">Letra
        <input type="color" class="opt-color-text" value="${toHexColor(textColor)}" data-value="${escapeHtml(opt)}">
      </label>
      <button class="icon-btn opt-reset-color" data-value="${escapeHtml(opt)}" title="Restablecer color">↺</button>
      <button class="icon-btn opt-delete" data-value="${escapeHtml(opt)}" title="Eliminar opción">🗑</button>
    `;
    container.appendChild(row);
  });

  container.querySelectorAll('.opt-input').forEach(input => {
    input.addEventListener('change', async () => {
      const oldVal = input.dataset.original;
      const newVal = input.value.trim();
      if (!newVal || newVal === oldVal) { input.value = oldVal; return; }
      try {
        schema = await window.api.renameFieldOption(optionsFieldKey, oldVal, newVal);
        devices = await window.api.getAll();
        renderOptionsList();
        renderFilters();
        renderTable();
        toast('Opción actualizada', 'success');
      } catch (err) {
        toast(err.message, 'error');
        input.value = oldVal;
      }
    });
  });
  container.querySelectorAll('.opt-color-bg, .opt-color-text').forEach(input => {
    input.addEventListener('input', async () => {
      const row = input.closest('.option-row');
      const bgVal = row.querySelector('.opt-color-bg').value;
      const textVal = row.querySelector('.opt-color-text').value;
      row.querySelector('.option-preview').style.background = bgVal;
      row.querySelector('.option-preview').style.color = textVal;
      schema = await window.api.setOptionColor(optionsFieldKey, input.dataset.value, bgVal, textVal);
      renderTable();
    });
  });
  container.querySelectorAll('.opt-reset-color').forEach(btn => {
    btn.addEventListener('click', async () => {
      schema = await window.api.resetOptionColor(optionsFieldKey, btn.dataset.value);
      renderOptionsList();
      renderTable();
      toast('Color restablecido', 'success');
    });
  });
  container.querySelectorAll('.opt-delete').forEach(btn => {
    btn.addEventListener('click', () => {
      askConfirm(`¿Eliminar la opción "${btn.dataset.value}"? Los dispositivos que ya la tengan asignada la conservarán como valor libre.`, async () => {
        schema = await window.api.deleteFieldOption(optionsFieldKey, btn.dataset.value);
        renderOptionsList();
        renderFilters();
        renderTable();
        toast('Opción eliminada', 'success');
      });
    });
  });
}

async function addOptionToField() {
  const input = document.getElementById('newOptionValue');
  const value = input.value.trim();
  if (!value) return;
  try {
    schema = await window.api.addFieldOption(optionsFieldKey, value);
    input.value = '';
    renderOptionsList();
    renderFilters();
    renderTable();
    toast('Opción agregada', 'success');
  } catch (err) {
    toast(err.message, 'error');
  }
}

// ================= Selector de campos a exportar =================
function openExportFieldsModal(type, scope, ids) {
  exportPending = { type, scope, ids };
  const container = document.getElementById('exportFieldsList');
  container.innerHTML = '';
  schema.forEach(f => {
    const row = document.createElement('label');
    row.className = 'config-field-row';
    row.innerHTML = `<span style="flex:1; display:flex; align-items:center; gap:8px;">
      <input type="checkbox" class="exp-field-check" value="${f.key}" checked> ${escapeHtml(f.label)}
    </span>`;
    container.appendChild(row);
  });
  document.getElementById('exportFieldsModal').classList.remove('hidden');
}

function closeExportFieldsModal() {
  document.getElementById('exportFieldsModal').classList.add('hidden');
  exportPending = null;
}

async function confirmExportFields() {
  if (!exportPending) return;
  const checks = document.querySelectorAll('.exp-field-check');
  const fields = Array.from(checks).filter(c => c.checked).map(c => c.value);
  if (fields.length === 0) { toast('Selecciona al menos un campo', 'error'); return; }
  const { type, scope, ids } = exportPending;
  closeExportFieldsModal();
  const res = type === 'csv'
    ? await window.api.exportCSV(scope, ids, fields)
    : await window.api.exportPDF(scope, ids, fields);
  if (res && res.ok) toast('Exportado: ' + res.path, 'success');
}

function selectAllExportFields(value) {
  document.querySelectorAll('.exp-field-check').forEach(c => { c.checked = value; });
}


// ================= Copiar a correo =================
// Copia los dispositivos seleccionados como una tabla HTML (con colores del
// campo Estado) para pegarla con Ctrl+V en Outlook / Gmail, más una versión
// en texto separado por tabulaciones para editores que no admiten HTML.

// Todas las columnas que se pueden elegir, en el mismo orden de la tabla
// (Código primero, luego el orden configurado en "⚙ Columnas").
function getMailCandidateFields() {
  const codigo = schema.find(f => f.key === 'codigo');
  const rest = (settings.columnOrder || []).map(c => schema.find(f => f.key === c.key)).filter(Boolean);
  const seen = new Set();
  return [codigo, ...rest, ...schema].filter(f => f && !seen.has(f.key) && seen.add(f.key));
}

// Selección guardada (solo claves que aún existen) o null si no hay.
function getSavedMailCols() {
  const saved = settings.emailCols;
  if (!Array.isArray(saved)) return null;
  const valid = new Set(schema.map(f => f.key));
  const ok = saved.filter(k => valid.has(k));
  return ok.length ? ok : null;
}

// Por defecto: las columnas visibles en la tabla.
function getDefaultMailCols() {
  return ['codigo', ...getVisibleTableColumns().map(f => f.key)].filter((k, i, a) => a.indexOf(k) === i);
}

function openMailColsModal(thenCopy) {
  mailThenCopy = !!thenCopy;
  const checked = new Set(getSavedMailCols() || getDefaultMailCols());
  const container = document.getElementById('mailColsList');
  container.innerHTML = '';
  getMailCandidateFields().forEach(f => {
    const row = document.createElement('label');
    row.className = 'config-field-row';
    row.innerHTML = `<span style="flex:1; display:flex; align-items:center; gap:8px;">
      <input type="checkbox" class="mail-col-check" value="${f.key}" ${checked.has(f.key) ? 'checked' : ''}> ${escapeHtml(f.label)}
    </span>`;
    container.appendChild(row);
  });
  document.getElementById('mailColsConfirm').textContent = mailThenCopy ? 'Guardar y copiar' : 'Guardar selección';
  document.getElementById('mailColsModal').classList.remove('hidden');
}

function closeMailColsModal() {
  document.getElementById('mailColsModal').classList.add('hidden');
  mailThenCopy = false;
}

function selectAllMailCols(value) {
  document.querySelectorAll('.mail-col-check').forEach(c => { c.checked = value; });
}

async function confirmMailCols() {
  const keys = Array.from(document.querySelectorAll('.mail-col-check')).filter(c => c.checked).map(c => c.value);
  if (keys.length === 0) { toast('Elige al menos una columna', 'error'); return; }
  const thenCopy = mailThenCopy;
  settings.emailCols = keys;
  await window.api.saveSettings(settings);
  closeMailColsModal();
  toast(`Columnas del correo guardadas (${keys.length})`, 'success');
  if (thenCopy) await copyToMail();
}

// Texto visible de una celda, con el mismo formato que la tabla.
function mailCellText(f, d) {
  const val = d[f.key];
  if (val === null || val === undefined || val === '') return '';
  if (f.type === 'datetime') return fmtDateTime(val) || String(val);
  if (f.type === 'date') return fmtDateOnly(val) || String(val);
  return String(val);
}

// Colores de celda (solo campos de lista con colores definidos, o Estado con los colores por defecto).
function mailCellColor(f, d) {
  const val = d[f.key];
  if (!val) return null;
  const info = f.colors && f.colors[val];
  if (info && (info.bg || info.text)) return { bg: info.bg || '#e6edf3', color: info.text || '#3c4858' };
  if (f.key === 'estado') {
    const cls = badgeClass(val);
    if (cls === 'badge-op') return { bg: '#e2f4e6', color: '#2e7d32' };
    if (cls === 'badge-mant') return { bg: '#fdf1d6', color: '#b8860b' };
    if (cls === 'badge-noop') return { bg: '#fbe3e0', color: '#c0392b' };
    return { bg: '#e6edf3', color: '#6b7684' };
  }
  return null;
}

function buildMailTable(cols, rows) {
  const th = 'border:1px solid #7f8c99;background:#0a3d62;color:#ffffff;padding:4px 8px;text-align:left;font-weight:bold;white-space:nowrap';
  const html = `<table border="1" cellspacing="0" cellpadding="4" style="border-collapse:collapse;font-family:Calibri,Arial,sans-serif;font-size:11pt"><thead><tr>` +
    cols.map(f => `<th style="${th}">${escapeHtml(f.label)}</th>`).join('') + '</tr></thead><tbody>' +
    rows.map(d => '<tr>' + cols.map(f => {
      const c = mailCellColor(f, d);
      const st = 'border:1px solid #7f8c99;padding:4px 8px' + (f.type === 'textarea' ? '' : ';white-space:nowrap') +
        (c ? `;background:${c.bg};color:${c.color};font-weight:bold` : '');
      return `<td style="${st}">${escapeHtml(mailCellText(f, d)).replace(/\r?\n/g, '<br>')}</td>`;
    }).join('') + '</tr>').join('') + '</tbody></table>';
  const text = [cols.map(f => f.label).join('\t')]
    .concat(rows.map(d => cols.map(f => mailCellText(f, d).replace(/[\t\r\n]+/g, ' ')).join('\t')))
    .join('\r\n');
  return { html, text };
}

async function copyToMail() {
  if (selectedIds.size === 0) { toast('Selecciona al menos un dispositivo', 'error'); return; }
  const keys = getSavedMailCols();
  if (!keys) { openMailColsModal(true); return; }
  const cols = getMailCandidateFields().filter(f => keys.includes(f.key));
  const rows = getFilteredDevices().filter(d => selectedIds.has(d.id));
  // Seleccionados que quedaron ocultos por un filtro o búsqueda también se copian
  const hidden = devices.filter(d => selectedIds.has(d.id) && !rows.includes(d));
  const all = rows.concat(hidden);
  const { html, text } = buildMailTable(cols, all);
  await window.api.copyHtml(html, text);
  toast(`Tabla copiada: ${all.length} fila${all.length > 1 ? 's' : ''} × ${cols.length} columnas. Pégala en el correo con Ctrl+V.`, 'success');
}

// ================= Eliminación masiva con doble confirmación =================
function startBulkDelete() {
  const count = selectedIds.size;
  if (count === 0) return;
  askConfirm(
    `¿Eliminar los ${count} dispositivo(s) seleccionado(s)? Se borrará también su historial de mantenimiento e imágenes. Esta acción no se puede deshacer.`,
    openDoubleConfirm
  );
}

function openDoubleConfirm() {
  document.getElementById('doubleConfirmText').textContent =
    `Estás a punto de eliminar ${selectedIds.size} dispositivo(s) de forma permanente.`;
  document.getElementById('doubleConfirmInput').value = '';
  document.getElementById('doubleConfirmOk').disabled = true;
  document.getElementById('doubleConfirmModal').classList.remove('hidden');
}

function closeDoubleConfirm() {
  document.getElementById('doubleConfirmModal').classList.add('hidden');
  document.getElementById('doubleConfirmInput').value = '';
}

async function executeBulkDelete() {
  const ids = Array.from(selectedIds);
  closeDoubleConfirm();
  for (const id of ids) {
    await window.api.deleteDevice(id);
  }
  selectedIds.clear();
  devices = await window.api.getAll();
  renderFilters();
  renderTable();
  toast(`${ids.length} dispositivo(s) eliminado(s)`, 'success');
}

// ================= Importación CSV =================
async function startImportCSV() {
  const result = await window.api.pickImportCSV();
  if (!result) return; // el usuario canceló el diálogo de archivo

  if (result.error) {
    toast(result.error, 'error');
    return;
  }

  importPending = { toCreate: result.toCreate, toUpdate: result.toUpdate };

  document.getElementById('importFileName').textContent = `Archivo: ${result.fileName}`;
  document.getElementById('importCreateCount').textContent = result.toCreate.length;
  document.getElementById('importUpdateCount').textContent = result.toUpdate.length;
  document.getElementById('importErrorCount').textContent = result.errors.length;

  const errorsList = document.getElementById('importErrorsList');
  errorsList.innerHTML = result.errors.map(e => `<div>Fila ${e.row}: ${escapeHtml(e.message)}</div>`).join('');

  const unmatchedNote = document.getElementById('importUnmatchedNote');
  if (result.unmatchedHeaders && result.unmatchedHeaders.length > 0) {
    unmatchedNote.textContent = `Columnas del archivo no reconocidas (se ignorarán): ${result.unmatchedHeaders.join(', ')}`;
  } else {
    unmatchedNote.textContent = '';
  }

  const confirmBtn = document.getElementById('importConfirm');
  const nothingToImport = result.toCreate.length === 0 && result.toUpdate.length === 0;
  confirmBtn.disabled = nothingToImport;

  document.getElementById('importPreviewModal').classList.remove('hidden');
}

function closeImportPreview() {
  document.getElementById('importPreviewModal').classList.add('hidden');
  importPending = null;
}

async function confirmImportCSV() {
  if (!importPending) return;
  const { toCreate, toUpdate } = importPending;
  closeImportPreview();
  const res = await window.api.commitImportCSV(toCreate, toUpdate);
  schema = await window.api.getSchema();
  settings = await window.api.getSettings();
  devices = await window.api.getAll();
  renderFilters();
  renderTable();
  toast(`Importación completa: ${res.created} nuevo(s), ${res.updated} actualizado(s)`, 'success');
}

// ================= Renombrar campo =================
async function renameFieldPrompt(key) {
  const field = schema.find(f => f.key === key);
  if (!field) return;
  askInput('Renombrar campo', `Nuevo nombre para el campo "${field.label}":`, field.label, async (newLabel) => {
    if (newLabel === null) return;
    const trimmed = String(newLabel).trim();
    if (!trimmed || trimmed === field.label) return;
    try {
      schema = await window.api.renameField(key, trimmed);
      settings = await window.api.getSettings();
      renderFieldsView();
      renderTable();
      if (currentDeviceId) {
        const d = devices.find(x => x.id === currentDeviceId);
        if (d) renderDeviceForm(d);
      }
      toast('Campo renombrado', 'success');
    } catch (err) {
      toast(err.message, 'error');
    }
  });
}

// ================= Respaldo automático =================
async function renderBackupView() {
  const backup = await window.api.getBackupConfig();
  const folder = await window.api.getBackupFolder();
  document.getElementById('backupEnabled').checked = !!backup.enabled;
  document.getElementById('backupTime').value = backup.time || '18:00';
  document.getElementById('backupFolderPath').textContent = folder;

  const statusEl = document.getElementById('backupStatusText');
  if (backup.lastBackupDate) {
    statusEl.textContent = `Último respaldo automático: ${backup.lastBackupDate}${backup.lastBackupFile ? ' — ' + backup.lastBackupFile : ''}`;
  } else {
    statusEl.textContent = 'Todavía no se ha generado ningún respaldo automático.';
  }
}

async function saveBackupConfig() {
  const enabled = document.getElementById('backupEnabled').checked;
  const time = document.getElementById('backupTime').value || '18:00';
  await window.api.saveBackupConfig({ enabled, time });
  toast('Configuración de respaldo guardada', 'success');
  renderBackupView();
}

async function runBackupNowFromUI() {
  const res = await window.api.runBackupNow();
  if (res && res.ok) {
    toast('Respaldo generado (CSV + JSON de configuración)', 'success');
    renderBackupView();
  } else {
    toast((res && res.error) || 'No se pudo generar el respaldo', 'error');
  }
}

async function restoreBackupFromUI() {
  const res = await window.api.restoreBackup();
  if (!res) return; // canceló el diálogo de archivo
  if (!res.ok) {
    toast(res.error || 'No se pudo restaurar el respaldo', 'error');
    return;
  }
  // recargar todo el estado desde los datos restaurados
  schema = await window.api.getSchema();
  settings = await window.api.getSettings();
  devices = await window.api.getAll();
  renderFilters();
  renderTable();
  renderBackupView();
  toast(`Respaldo restaurado: ${res.devices} dispositivo(s) desde ${res.file}`, 'success');
}
