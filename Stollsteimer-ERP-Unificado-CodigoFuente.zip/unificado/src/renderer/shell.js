// Selector de módulos. Ambos iframes se cargan al iniciar (así los respaldos
// automáticos de cada módulo siguen corriendo aunque no esté a la vista).
const buttons = document.querySelectorAll('.mod-btn');

function showModule(mod) {
  buttons.forEach(b => b.classList.toggle('active', b.dataset.mod === mod));
  document.querySelectorAll('.frame').forEach(f => f.classList.toggle('active', f.id === 'frame-' + mod));
  const fr = document.getElementById('frame-' + mod);
  try { fr.contentWindow.focus(); } catch (e) { /* no-op */ }
  try { localStorage.setItem('modulo', mod); } catch (e) { /* no-op */ }
}

buttons.forEach(b => b.addEventListener('click', () => showModule(b.dataset.mod)));
document.addEventListener('keydown', (e) => {
  if (e.altKey && e.key === '1') showModule('erp');
  if (e.altKey && e.key === '2') showModule('accesos');
});
try { const last = localStorage.getItem('modulo'); if (last === 'accesos') showModule('accesos'); } catch (e) { /* no-op */ }

// Los módulos se cargan uno tras otro (primero el ERP, luego Accesos). Cargarlos
// en paralelo podía dejar al segundo sin su API en algunos equipos.
const frameErp = document.getElementById('frame-erp');
const frameAcc = document.getElementById('frame-accesos');
let accLoading = false;
function loadAccesos() {
  if (accLoading) return;
  accLoading = true;
  frameAcc.src = frameAcc.dataset.src;
}
frameErp.addEventListener('load', () => setTimeout(loadAccesos, 300), { once: true });
setTimeout(loadAccesos, 8000); // respaldo por si el evento load no llega
