const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

let DATA_DIR = null;
let IMAGES_DIR = null;
let DEVICES_FILE = null;
let SCHEMA_FILE = null;
let SETTINGS_FILE = null;

// Solo "codigo" es un campo base protegido (no se puede eliminar).
// El resto son campos sugeridos precargados: aparecen listos para usar
// pero el usuario los puede quitar como cualquier campo personalizado.
const DEFAULT_SCHEMA = [
  { key: 'codigo', label: 'Código', type: 'text', required: true, base: true },
  { key: 'estado', label: 'Estado', type: 'select', base: false,
    options: ['31 - Disponible', '11 - Operativa', '30 - En uso', '10 - No Operativa', '02 - En Mantenimiento', '20 - Reservada', '21 - Para instalar'] },
  { key: 'tipo', label: 'Tipo', type: 'select', base: false,
    options: ['Cámara', 'Servidor', 'PC', 'Router', 'DHCP', 'NVR', 'Disco', 'Usuario', 'IDRAC', 'Otros'] },
  { key: 'ip', label: 'IP', type: 'text', base: false },
  { key: 'serie', label: 'N° de Serie', type: 'text', base: false },
  { key: 'proximoMantenimiento', label: 'Próximo Mantenimiento Programado', type: 'date', base: false },
  { key: 'actualizacion', label: 'Última Actualización', type: 'datetime', base: false },
  { key: 'ubicacion', label: 'Ubicación', type: 'text', base: false },
  { key: 'marca', label: 'Marca', type: 'text', base: false },
  { key: 'modelo', label: 'Modelo', type: 'text', base: false },
  { key: 'responsable', label: 'Responsable', type: 'text', base: false },
  { key: 'notas', label: 'Notas', type: 'textarea', base: false }
];

function nowISO() { return new Date().toISOString(); }
function uid(prefix) { return `${prefix}-${crypto.randomUUID()}`; }

function readJSON(file, fallback) {
  try {
    if (!fs.existsSync(file)) return fallback;
    return JSON.parse(fs.readFileSync(file, 'utf-8'));
  } catch (err) {
    console.error('Error leyendo', file, err);
    return fallback;
  }
}
function writeJSON(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2), 'utf-8');
}

function init(dataDir, imagesDir) {
  DATA_DIR = dataDir;
  IMAGES_DIR = imagesDir;
  DEVICES_FILE = path.join(DATA_DIR, 'devices.json');
  SCHEMA_FILE = path.join(DATA_DIR, 'schema.json');
  SETTINGS_FILE = path.join(DATA_DIR, 'settings.json');

  if (!fs.existsSync(SCHEMA_FILE)) {
    writeJSON(SCHEMA_FILE, DEFAULT_SCHEMA);
  } else {
    // Migración: agrega campos base nuevos (ej: proximoMantenimiento) a instalaciones existentes
    const current = readJSON(SCHEMA_FILE, DEFAULT_SCHEMA);
    const currentKeys = new Set(current.map(f => f.key));
    let changed = false;
    DEFAULT_SCHEMA.forEach((f, idx) => {
      if (!currentKeys.has(f.key)) {
        // insertar en la misma posicion relativa que en DEFAULT_SCHEMA
        const insertAfterKey = idx > 0 ? DEFAULT_SCHEMA[idx - 1].key : null;
        const insertIdx = insertAfterKey ? current.findIndex(cf => cf.key === insertAfterKey) + 1 : 0;
        current.splice(insertIdx === 0 && insertAfterKey ? current.length : insertIdx, 0, f);
        changed = true;
      }
    });

    // Migración: sincroniza el flag "base" con la definición actual (solo "codigo"
    // queda protegido; el resto pasa a ser un campo sugerido pero eliminable).
    current.forEach(cf => {
      const def = DEFAULT_SCHEMA.find(f => f.key === cf.key);
      if (def && cf.base !== def.base) {
        cf.base = def.base;
        changed = true;
      }
    });

    if (changed) writeJSON(SCHEMA_FILE, current);

    // asegurar que los dispositivos existentes tengan las claves de los campos base nuevos
    if (fs.existsSync(DEVICES_FILE)) {
      const list = readJSON(DEVICES_FILE, []);
      let devicesChanged = false;
      DEFAULT_SCHEMA.forEach(f => {
        list.forEach(d => {
          if (!(f.key in d)) { d[f.key] = ''; devicesChanged = true; }
        });
      });
      if (devicesChanged) writeJSON(DEVICES_FILE, list);
    }
  }

  // asegurar que todos los dispositivos tengan los arreglos internos (imagenes,
  // mantenimientos, historial de N° de serie), sin importar si el schema cambio o no
  if (fs.existsSync(DEVICES_FILE)) {
    const list = readJSON(DEVICES_FILE, []);
    let changed = false;
    list.forEach(d => {
      if (!Array.isArray(d.imagenes)) { d.imagenes = []; changed = true; }
      if (!Array.isArray(d.mantenimientos)) { d.mantenimientos = []; changed = true; }
      if (!Array.isArray(d.historialSerie)) { d.historialSerie = []; changed = true; }
    });
    if (changed) writeJSON(DEVICES_FILE, list);
  }
  if (!fs.existsSync(SETTINGS_FILE)) {
    writeJSON(SETTINGS_FILE, { columnOrder: [], formOrder: [] });
  }

  if (!fs.existsSync(DEVICES_FILE)) {
    // Semilla inicial desde data/devices.seed.json empaquetado con la app
    const seedPath = path.join(__dirname, '..', 'data', 'devices.seed.json');
    const altSeedPath = path.join(process.resourcesPath || '', 'data', 'devices.seed.json');
    let seed = [];
    if (fs.existsSync(seedPath)) seed = readJSON(seedPath, []);
    else if (fs.existsSync(altSeedPath)) seed = readJSON(altSeedPath, []);
    writeJSON(DEVICES_FILE, seed);
  }
}

function getImagesDir() { return IMAGES_DIR; }

function getAll() { return readJSON(DEVICES_FILE, []); }
function saveAll(list) { writeJSON(DEVICES_FILE, list); }

function getSchema() { return readJSON(SCHEMA_FILE, DEFAULT_SCHEMA); }
function saveSchema(s) { writeJSON(SCHEMA_FILE, s); }

// ---------- configuracion de columnas/campos (orden y visibilidad) ----------
// reconcilia una lista guardada [{key, visible}] contra las claves validas actuales
// (agrega las nuevas al final visibles, quita las que ya no existen)
function reconcileOrder(saved, validKeys, excludeKeys = []) {
  const excl = new Set(excludeKeys);
  const valid = validKeys.filter(k => !excl.has(k));
  const savedList = Array.isArray(saved) ? saved.filter(s => valid.includes(s.key)) : [];
  const savedKeys = new Set(savedList.map(s => s.key));
  const missing = valid.filter(k => !savedKeys.has(k)).map(k => ({ key: k, visible: true }));
  return [...savedList, ...missing];
}

function getSettings() {
  const raw = readJSON(SETTINGS_FILE, { columnOrder: [], formOrder: [] });
  const schema = getSchema();
  const allKeys = schema.map(f => f.key);
  const columnOrder = reconcileOrder(raw.columnOrder, allKeys, ['codigo']);
  const formOrder = reconcileOrder(raw.formOrder, allKeys, []);
  const backup = Object.assign({
    enabled: false,
    time: '18:00',
    lastBackupDate: null,   // 'YYYY-MM-DD' del ultimo respaldo automatico realizado
    lastBackupFile: null
  }, raw.backup || {});
  // conservar otras secciones guardadas (ej: emailCols, columnas del correo)
  const settings = Object.assign({}, raw, { columnOrder, formOrder, backup });
  writeJSON(SETTINGS_FILE, settings);
  return settings;
}

function saveSettings(settings) {
  // preservar secciones que el llamador no haya incluido (ej: el renderer
  // guarda solo columnOrder/formOrder y no debe borrar la config de respaldo)
  const current = readJSON(SETTINGS_FILE, {});
  const merged = Object.assign({}, current, settings);
  if (!settings.backup && current.backup) merged.backup = current.backup;
  writeJSON(SETTINGS_FILE, merged);
  return merged;
}

function saveBackupConfig(backupPatch) {
  const settings = getSettings();
  settings.backup = Object.assign({}, settings.backup, backupPatch);
  writeJSON(SETTINGS_FILE, settings);
  return settings;
}

function addDevice(device) {
  const list = getAll();
  const newDevice = Object.assign({
    id: uid('dev'),
    imagenes: [],
    mantenimientos: [],
    historialSerie: [],
    actualizacion: nowISO()
  }, device);
  list.push(newDevice);
  saveAll(list);
  return newDevice;
}

function updateDevice(id, patch) {
  const list = getAll();
  const idx = list.findIndex(d => d.id === id);
  if (idx === -1) return null;
  const prev = list[idx];

  // si cambia el N° de serie, dejar registro historico del cambio con fecha
  if (Object.prototype.hasOwnProperty.call(patch, 'serie') && patch.serie !== prev.serie) {
    if (!Array.isArray(prev.historialSerie)) prev.historialSerie = [];
    prev.historialSerie.unshift({
      id: uid('hs'),
      fecha: nowISO(),
      anterior: prev.serie || '(sin serie)',
      nuevo: patch.serie || '(sin serie)'
    });
  }

  list[idx] = Object.assign({}, prev, patch, {
    actualizacion: nowISO(),
    historialSerie: prev.historialSerie || []
  });
  saveAll(list);
  return list[idx];
}

function deleteDevice(id) {
  const list = getAll();
  const target = list.find(d => d.id === id);
  if (target && Array.isArray(target.imagenes)) {
    target.imagenes.forEach(img => {
      const p = path.join(IMAGES_DIR, img.filename);
      if (fs.existsSync(p)) { try { fs.unlinkSync(p); } catch (e) {} }
    });
  }
  const filtered = list.filter(d => d.id !== id);
  saveAll(filtered);
  return true;
}

function duplicateDevice(id) {
  const list = getAll();
  const original = list.find(d => d.id === id);
  if (!original) return null;
  const copy = Object.assign({}, original, {
    id: uid('dev'),
    codigo: original.codigo + '-COPIA',
    imagenes: [],
    actualizacion: nowISO()
  });
  list.push(copy);
  saveAll(list);
  return copy;
}

// ---------- campos personalizados ----------
function addField(field) {
  const schema = getSchema();
  if (schema.some(f => f.key === field.key)) throw new Error('Ya existe un campo con esa clave');
  schema.push(Object.assign({ base: false }, field));
  saveSchema(schema);

  // agregar el campo vacio a todos los dispositivos existentes
  const list = getAll();
  list.forEach(d => { if (!(field.key in d)) d[field.key] = ''; });
  saveAll(list);
  return schema;
}

function removeField(key) {
  let schema = getSchema();
  const target = schema.find(f => f.key === key);
  if (target && target.base) throw new Error('No se pueden eliminar campos base del sistema');
  schema = schema.filter(f => f.key !== key);
  saveSchema(schema);

  const list = getAll();
  list.forEach(d => { delete d[key]; });
  saveAll(list);
  return schema;
}

function renameField(key, newLabel) {
  const schema = getSchema();
  const field = schema.find(f => f.key === key);
  if (!field) throw new Error('Campo no encontrado');
  const label = String(newLabel).trim();
  if (!label) throw new Error('El nombre no puede estar vacío');
  field.label = label;
  saveSchema(schema);
  return schema;
}

// ---------- opciones de campos tipo lista (select), ej: Tipo, Estado ----------
function addFieldOption(key, value) {
  const schema = getSchema();
  const field = schema.find(f => f.key === key);
  if (!field) throw new Error('Campo no encontrado');
  if (field.type !== 'select') throw new Error('Este campo no admite opciones');
  field.options = field.options || [];
  const val = String(value).trim();
  if (!val) throw new Error('La opción no puede estar vacía');
  if (field.options.includes(val)) throw new Error('Esa opción ya existe');
  field.options.push(val);
  saveSchema(schema);
  return schema;
}

function renameFieldOption(key, oldValue, newValue) {
  const schema = getSchema();
  const field = schema.find(f => f.key === key);
  if (!field) throw new Error('Campo no encontrado');
  const idx = (field.options || []).indexOf(oldValue);
  if (idx === -1) throw new Error('Opción no encontrada');
  const val = String(newValue).trim();
  if (!val) throw new Error('La opción no puede estar vacía');
  field.options[idx] = val;

  // conservar el color asignado al renombrar
  if (field.colors && field.colors[oldValue] && oldValue !== val) {
    field.colors[val] = field.colors[oldValue];
    delete field.colors[oldValue];
  }
  saveSchema(schema);

  // migrar dispositivos que usaban el valor anterior
  const list = getAll();
  let changed = false;
  list.forEach(d => { if (d[key] === oldValue) { d[key] = val; changed = true; } });
  if (changed) saveAll(list);
  return schema;
}

function deleteFieldOption(key, value) {
  const schema = getSchema();
  const field = schema.find(f => f.key === key);
  if (!field) throw new Error('Campo no encontrado');
  field.options = (field.options || []).filter(o => o !== value);
  if (field.colors) delete field.colors[value];
  saveSchema(schema);
  // los dispositivos que ya tenian ese valor lo conservan (queda como valor libre/huerfano)
  return schema;
}

// ---------- color de fondo/texto por opcion (campos tipo lista) ----------
function setOptionColor(key, value, bg, textColor) {
  const schema = getSchema();
  const field = schema.find(f => f.key === key);
  if (!field) throw new Error('Campo no encontrado');
  if (!field.colors) field.colors = {};
  field.colors[value] = { bg: bg || null, text: textColor || null };
  saveSchema(schema);
  return schema;
}

function resetOptionColor(key, value) {
  const schema = getSchema();
  const field = schema.find(f => f.key === key);
  if (!field) throw new Error('Campo no encontrado');
  if (field.colors) delete field.colors[value];
  saveSchema(schema);
  return schema;
}

// ---------- mantenimientos (hoja de vida) ----------
function addMaintenance(deviceId, entry) {
  const list = getAll();
  const device = list.find(d => d.id === deviceId);
  if (!device) return null;
  if (!Array.isArray(device.mantenimientos)) device.mantenimientos = [];
  const newEntry = Object.assign({
    id: uid('mnt'),
    fecha: nowISO(),
    tipo: 'Preventivo',
    descripcion: '',
    tecnico: '',
    estado: 'Completado',
    costo: ''
  }, entry);
  device.mantenimientos.unshift(newEntry);
  device.actualizacion = nowISO();
  saveAll(list);
  return newEntry;
}

function updateMaintenance(deviceId, entryId, patch) {
  const list = getAll();
  const device = list.find(d => d.id === deviceId);
  if (!device) return null;
  const idx = (device.mantenimientos || []).findIndex(m => m.id === entryId);
  if (idx === -1) return null;
  device.mantenimientos[idx] = Object.assign({}, device.mantenimientos[idx], patch);
  saveAll(list);
  return device.mantenimientos[idx];
}

function deleteMaintenance(deviceId, entryId) {
  const list = getAll();
  const device = list.find(d => d.id === deviceId);
  if (!device) return false;
  device.mantenimientos = (device.mantenimientos || []).filter(m => m.id !== entryId);
  saveAll(list);
  return true;
}

// ---------- imagenes ----------
function addImages(deviceId, filePaths) {
  const list = getAll();
  const device = list.find(d => d.id === deviceId);
  if (!device) return null;
  if (!Array.isArray(device.imagenes)) device.imagenes = [];

  const added = [];
  filePaths.forEach(fp => {
    const ext = path.extname(fp);
    const filename = `${uid('img')}${ext}`;
    fs.copyFileSync(fp, path.join(IMAGES_DIR, filename));
    const record = { id: uid('img'), filename, originalName: path.basename(fp), addedAt: nowISO() };
    device.imagenes.push(record);
    added.push(record);
  });
  saveAll(list);
  return added;
}

function removeImage(deviceId, imageId) {
  const list = getAll();
  const device = list.find(d => d.id === deviceId);
  if (!device) return false;
  const img = (device.imagenes || []).find(i => i.id === imageId);
  if (img) {
    const p = path.join(IMAGES_DIR, img.filename);
    if (fs.existsSync(p)) { try { fs.unlinkSync(p); } catch (e) {} }
  }
  device.imagenes = (device.imagenes || []).filter(i => i.id !== imageId);
  saveAll(list);
  return true;
}

module.exports = {
  init, getAll, saveAll, getSchema, saveSchema,
  getSettings, saveSettings, saveBackupConfig,
  addDevice, updateDevice, deleteDevice, duplicateDevice,
  addField, removeField, renameField,
  addFieldOption, renameFieldOption, deleteFieldOption,
  setOptionColor, resetOptionColor,
  addMaintenance, updateMaintenance, deleteMaintenance,
  addImages, removeImage, getImagesDir
};
